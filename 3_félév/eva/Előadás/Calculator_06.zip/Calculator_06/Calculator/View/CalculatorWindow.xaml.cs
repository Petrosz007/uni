﻿using System.Windows;

namespace ELTE.Windows.Calculator.View
{
    public partial class CalculatorWindow : Window
    {
        public CalculatorWindow()
        {
            InitializeComponent();
        }
    }
}
