#include "buildingdelegate.h"
#include <QStyleOptionViewItem>
#include <QByteArray>
#include <QVector>
#include <QtGui>
#include "featureeditorlistwidget.h"

BuildingDelegate::BuildingDelegate(QObject *parent) :
        QSqlRelationalDelegate(parent)
{
}


void BuildingDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option,const QModelIndex &index) const
{
    switch (index.column())
    {
    case 4: // tengerpart távolság oszlop
        {
            QString text;

            int shoreDistance = index.data().toInt(); // adat lekérdezése

            if (shoreDistance == 1)
                text = trUtf8("közvetlen");
            else
                text = QString::number(shoreDistance) + " m"; // kiírás módosítása

            QStyleOptionViewItem optionViewItem = option;	// kiírás módjának beállítása
            optionViewItem.displayAlignment = Qt::AlignRight | Qt::AlignVCenter; // jobbra tagolt, vizszíntesen középen lévõ

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text); // adat kirajzolása
            drawFocus(painter, optionViewItem, optionViewItem.rect); // fókusz kirajzolása
        }
        break;
    case 5: // tengerpart típus oszlop
        {
            QString text = shoreList().at(index.data().toInt()); // a szöveget a listából kérdezzük le

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignLeft | Qt::AlignVCenter; // balra tagolt, vizszíntesen középen lévõ

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    case 6: // jellemzők oszlop
        {
            FeatureEditorListWidget* featureEditorlistWidget = new FeatureEditorListWidget(); // jellemzőket megjelenítő lista vezérlő
            featureEditorlistWidget->setFeatures(index.data().toInt()); // a jellemzőket beállítjuk

            QString text = featureEditorlistWidget->getFeaturesString(); // jellemzők szöveges leírásának lekérdezése

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignLeft | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    default:
        QSqlRelationalDelegate::paint(painter, option, index); // különben az alapértelmezett kirajzolást végezze
        break;
    }
}

QWidget *BuildingDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    switch (index.column())
    {
    case 5:
        {
            QComboBox *shoreComboBox = new QComboBox(parent); // a szerkesztőmező nem a szokásos szövegmező, hanem egy legördülő menü lesz
            shoreComboBox->addItems(shoreList()); // felvesszük a lista által tartalmazott elemeket
            return shoreComboBox; // visszaadjuk ezt a szerkesztőmezőt
        }
        break;
    case 6:
        {
            FeatureEditorListWidget* featureEditorlistWidget = new FeatureEditorListWidget(parent); // a szerkesztőmező a jellemzőket megjelenítő lista vezérlő lesz
            return featureEditorlistWidget;
        }
        break;
    default:
        return QSqlRelationalDelegate::createEditor(parent, option, index); // különben a szokványos szerkesztőmezőt használjuk
        break;
    }
}

void BuildingDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    switch (index.column())
    {
    case 5:
        {
            int i = index.data().toInt();
            QComboBox *shoreComboBox = qobject_cast<QComboBox *>(editor); // cast kell, mert alapértelmezetten nem tudja, hogy legördülő menü
            shoreComboBox->setCurrentIndex(i); // szerkesztőmező elemének beállítása
        }
        break;
    case 6:
        {
            FeatureEditorListWidget* featureEditorlistWidget = qobject_cast<FeatureEditorListWidget *>(editor);
            featureEditorlistWidget->setFeatures(index.data().toInt());
        }
        break;
    default:
        QSqlRelationalDelegate::setEditorData(editor, index);
        break;
    }
}

void BuildingDelegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
    switch (index.column())
    {
    case 5:
        {
            QComboBox *shoreComboBox = qobject_cast<QComboBox *>(editor);
            model->setData(index, shoreComboBox->currentIndex()); // adat visszaírása a modellbe
        }
        break;
    case 6:
        {
            FeatureEditorListWidget* featureEditorlistWidget = qobject_cast<FeatureEditorListWidget *>(editor);
            model->setData(index, featureEditorlistWidget->getFeatures()); // adat visszaírása a modellbe
        }
        break;
    default:
        QSqlRelationalDelegate::setModelData(editor, model, index);
        break;
    }
}

QStringList BuildingDelegate::shoreList() const
{
    QStringList list;
    list.append(trUtf8("Homokos"));
    list.append(trUtf8("Sziklás"));
    list.append(trUtf8("Kavicsos"));
    list.append(trUtf8("Apró kavicsos"));

    return list;
}
