#include "buildingeditordialog.h"
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QSqlError>
#include <QSqlRecord>
#include "buildingdelegate.h"

BuildingEditorDialog::BuildingEditorDialog(QWidget *parent)
    : QDialog(parent)
{
    _model = new BuildingTableModel();
    _model->select();
    setupUi();
}

BuildingEditorDialog::~BuildingEditorDialog()
{
    delete _model;
}

void BuildingEditorDialog::addButton_Clicked()
{
    int row;
    if (_tableView->currentIndex().isValid())
    {
        row = _tableView->currentIndex().row();
    }
    else
    {
        row = _model->rowCount();
    }

    _model->insertRow(row);
    _model->setData(_model->index(row, 4), 1); // alapértemezett értékek beírása
    _model->setData(_model->index(row, 5), 1);
    _model->setData(_model->index(row, 6), 0);

    _tableView->setCurrentIndex(_model->index(row, 0));
    _tableView->edit(_model->index(row, 0));
}

void BuildingEditorDialog::removeButton_Clicked()
{
    QModelIndex index = _tableView->currentIndex();

    if (index.isValid())
    {
        _model->removeRow(index.row());
        _tableView->setCurrentIndex(_model->index(index.row()-1, 0));
    }
    else
    {
        QMessageBox::warning(this, trUtf8("Nincs kijelölés!"), trUtf8("Kérem jelölje ki előbb a törlendő sort!"));
    }
}

void BuildingEditorDialog::submitButton_Clicked()
{
    _model->database().transaction();

    if (_model->submitAll())
    {
        _model->database().commit();
        _model->select();
    } else
    {
        _model->database().rollback();
        QMessageBox::warning(this, trUtf8("Hiba történt a mentéskor!"), trUtf8("Az adatbázis a kvetkező hibát jelezte: %1").arg(_model->lastError().text()));
    }
}

void BuildingEditorDialog::tableView_DoubleClicked(QModelIndex index)
{
    if (index.isValid() && index.column() == 2)
    {
        _cityEditorDialog->show();
        // megjelenítjük a városszerkesztőt
    }
}

void BuildingEditorDialog::setupUi()
{
    _addButton = new QPushButton(trUtf8("&Beszúrás"));
    _removeButton = new QPushButton(trUtf8("&Törlés"));
    _submitButton = new QPushButton(trUtf8("&Mentés"));
    _revertButton = new QPushButton(trUtf8("&Visszavonás"));

    _buttonBox = new QDialogButtonBox(Qt::Horizontal);
    _buttonBox->addButton(_addButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_removeButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_submitButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_revertButton, QDialogButtonBox::ActionRole);

    connect(_addButton, SIGNAL(clicked()), this, SLOT(addButton_Clicked()));
    connect(_removeButton, SIGNAL(clicked()), this, SLOT(removeButton_Clicked()));
    connect(_submitButton, SIGNAL(clicked()), this, SLOT(submitButton_Clicked()));
    connect(_revertButton, SIGNAL(clicked()), _model, SLOT(revertAll()));

    _tableView = new QTableView(this);
    _tableView->setModel(_model);
    _tableView->setSelectionBehavior(QAbstractItemView::SelectItems);
    _tableView->resizeColumnsToContents();
    _tableView->setItemDelegate(new BuildingDelegate()); // egyedi delegált használatba vétele
    _tableView->setColumnHidden(0, true);

    connect(_tableView, SIGNAL(doubleClicked(QModelIndex)), this, SLOT(tableView_DoubleClicked(QModelIndex)));
    // dupla kattintás eseménytársítása

    _cityEditorDialog = new CityEditorDialog(this);
    _cityEditorDialog->setModel(_model->relationModel(2)); // lekérjük a városok modelljét, és átadjuk a szerkesztőnek

    QVBoxLayout* mainLayout = new QVBoxLayout;
    mainLayout->addWidget(_tableView);
    mainLayout->addWidget(_buttonBox);
    setLayout(mainLayout);

    setFixedSize(800, 300);
    setWindowTitle(trUtf8("Épületek szerkesztése"));
}
