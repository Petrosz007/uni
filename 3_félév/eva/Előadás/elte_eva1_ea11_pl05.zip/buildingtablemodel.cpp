#include "buildingtablemodel.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlRecord>

BuildingTableModel::BuildingTableModel(QObject *parent) :
    QSqlRelationalTableModel(parent)
{
    setTable("building");
    setSort(1, Qt::AscendingOrder);
    setEditStrategy(QSqlTableModel::OnManualSubmit);
    setHeaderData(0, Qt::Horizontal, trUtf8("Azonosító"));
    setHeaderData(1, Qt::Horizontal, trUtf8("Név"));
    setHeaderData(2, Qt::Horizontal, trUtf8("Város"));
    setHeaderData(3, Qt::Horizontal, trUtf8("Utca"));
    setHeaderData(4, Qt::Horizontal, trUtf8("Tenger távolság"));
    setHeaderData(5, Qt::Horizontal, trUtf8("Tengerpart"));
    setHeaderData(6, Qt::Horizontal, trUtf8("Jellemzők"));
    setHeaderData(7, Qt::Horizontal, trUtf8("Megjegyzés"));
    setHeaderData(8, Qt::Horizontal, trUtf8("Apartmanok"));
    setHeaderData(9, Qt::Horizontal, trUtf8("Minimum ár"));
    setHeaderData(10, Qt::Horizontal, trUtf8("Maximum ár"));
    setRelation(2, QSqlRelation("city", "id", "name"));

    connect(this, SIGNAL(beforeInsert(QSqlRecord&)), this, SLOT(onBeforeInsert(QSqlRecord&)));
    connect(this, SIGNAL(dataChanged(QModelIndex,QModelIndex)), this, SLOT(onDataChanged(QModelIndex,QModelIndex)));
}

void BuildingTableModel::insertRow(int row)
{
    QSqlRelationalTableModel::insertRow(row); // új sor beszúrása

    setData(index(row, 3),1); // alapértelmezett adatok
    setData(index(row, 4),1);
}

QVariant BuildingTableModel::data(const QModelIndex &index, int role) const
{
    if(!index.isValid()) return QVariant(); // ha nem érvényes az index, üres adatot adunk
    if (index.column() >= 8 && index.column() <= 10 && role == Qt::TextAlignmentRole ) // a megjelenítés módját adjuk vissza
    {
        return QVariant(Qt::AlignRight | Qt::AlignVCenter);
    }
    // tartalom számítása:
    if (index.column() == 8 && ( role == Qt::DisplayRole || role == Qt::EditRole)) // apartmanok száma
    {
        QSqlQuery query;
        query.exec("select count(*) from apartment where building_id = " + this->data(this->index(index.row(), 0)).toString());
        if (query.next())
            return QVariant(query.value(0).toInt());
        else
            return QVariant(0);
    }
    if (index.column() == 9 && ( role == Qt::DisplayRole || role == Qt::EditRole)) // minimum ár
    {
        QSqlQuery query;
        query.exec("select min(price) from price where apartment_id in (select id from apartment where building_id = " + this->data(this->index(index.row(), 0)).toString() + ")");
        if (query.next())
            return QVariant(query.value(0).toInt());
        else
            return QVariant("?");
    }
    if (index.column() == 10 && ( role == Qt::DisplayRole || role == Qt::EditRole)) // maximum ár
    {
        QSqlQuery query;
        query.exec("select max(price) from price where apartment_id in (select id from apartment where building_id = " + this->data(this->index(index.row(), 0)).toString() + ")");
        if (query.next())
            return QVariant(query.value(0).toInt());
        else
            return QVariant("?");
    }
    else
    {
        return QSqlRelationalTableModel::data(index, role); // különben az alap adatot adjuk vissza
    }
}

int BuildingTableModel::columnCount(const QModelIndex& parent) const
{
    return QSqlRelationalTableModel::columnCount(parent) + 3; // az oszlopok számát megnöveljük 3-mal
}

void BuildingTableModel::onBeforeInsert(QSqlRecord& record)
{
    record.setValue("comment", trUtf8("új hírdetés"));
}

void BuildingTableModel::onDataChanged(const QModelIndex& topLeft, const QModelIndex& bottomRight)
{
    if (topLeft.isValid() && topLeft.column() == 4) // ha a tengerpart oszlopban vagyunk
    {
        if (!data(topLeft).isNull() && data(topLeft).toInt() <= 0) // ha az érték ki van töltve, de nem pozitív
        {
            QMessageBox::warning(0, trUtf8("Hibás kitöltés"), trUtf8("A tengerpart távolsága csak pozitív szám lehet!"));
            setData(topLeft, 1); // érték módosítása 1-re
        }
    }
}
