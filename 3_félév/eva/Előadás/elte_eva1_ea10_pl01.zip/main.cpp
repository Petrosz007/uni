#include <QApplication>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QTableView>
#include <QMessageBox>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL"); // adatbázis-kapcsolat létrehozása
    db.setHostName("localhost");
    db.setDatabaseName("apartments");
    db.setUserName("root");
    db.setPassword("root");

    if (db.open())
    {
        QSqlQueryModel *model = new QSqlQueryModel;
        model->setQuery("select * from building");
        model->setHeaderData(0, Qt::Horizontal, QObject::trUtf8("Azonosító")); // fejlécek beállítása
        model->setHeaderData(1, Qt::Horizontal, QObject::trUtf8("Név"));
        model->setHeaderData(2, Qt::Horizontal, QObject::trUtf8("Város"));
        model->setHeaderData(3, Qt::Horizontal, QObject::trUtf8("Utca"));
        model->setHeaderData(4, Qt::Horizontal, QObject::trUtf8("Tenger távolság"));
        model->setHeaderData(5, Qt::Horizontal, QObject::trUtf8("Tengerpart"));
        model->setHeaderData(6, Qt::Horizontal, QObject::trUtf8("Jellemzők"));
        model->setHeaderData(7, Qt::Horizontal, QObject::trUtf8("Megjegyzés"));

        QTableView *view = new QTableView;
        view->setModel(model);
        view->setWindowTitle(QObject::trUtf8("Épületek megjelenítése"));
        view->setMinimumSize(800,300);
        view->show();

        db.close(); // kapcsolat bezárása
    }
    else
    {
        QMessageBox::critical(0, QObject::trUtf8("Hiba!"), QObject::trUtf8("Nem sikerült kapcsolódni az adatbázis-szerverhez."));
    }

    return a.exec();
}
