#ifndef MOTIONPICTUREWIDGET_H
#define MOTIONPICTUREWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QTimer>

namespace Ui {
class MotionPictureWidget;
}

class MotionPictureWidget : public QWidget
{
    Q_OBJECT
    
public:
    explicit MotionPictureWidget(QWidget *parent = 0);
    ~MotionPictureWidget();

private slots:
    void loadImages(); // képek betöltése
    void startStopMotion(); // animáció indítása/leállítása
    void changeSpeed(int value); // sebességváltás
    void changeImages(); // képek változtatása (animáció alatt)

private:
    void reloadImages(); // képek újratölése
    void reloadLabels(); // címkék újratöltése

    Ui::MotionPictureWidget *_ui;

    QVector<QLabel*> _smallImageLabels; // kis képek címkéi
    QVector<QPixmap*> _images; // képek

    QTimer* _timer; // időzítő

    int _currentImage;
};

#endif // MOTIONPICTUREWIDGET_H
