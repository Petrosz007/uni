#include "motionpicturewidget.h"
#include "ui_motionpicturewidget.h"

#include <QFileDialog>
#include <QMessageBox>

MotionPictureWidget::MotionPictureWidget(QWidget *parent) :
    QWidget(parent),
    _ui(new Ui::MotionPictureWidget)
{
    _currentImage = 0;

    _ui->setupUi(this);

    connect(_ui->browseButton, SIGNAL(clicked()), this, SLOT(loadImages()));
    connect(_ui->startStopButton, SIGNAL(clicked()), this, SLOT(startStopMotion()));
    connect(_ui->speedSpinBox, SIGNAL(valueChanged(int)), this, SLOT(changeSpeed(int)));

    _timer = new QTimer(this);
    connect(_timer, SIGNAL(timeout()), this, SLOT(changeImages()));
}

MotionPictureWidget::~MotionPictureWidget()
{
    foreach(QPixmap* image, _images) // képek törlése
    {
        delete image;
    }
    foreach(QLabel* label, _smallImageLabels) // címkék törlése
    {
        delete label;
    }
    delete _ui;
}

void MotionPictureWidget::loadImages()
{
    QString dirName = QFileDialog::getExistingDirectory(this, trUtf8("Könyvtár megnyitása"), "", QFileDialog::ShowDirsOnly);
    // könyvtár megnyitó dialógusablak

    if (!dirName.isNull())
    {
        // ha fut az időzítő leállítjuk
        if (_timer->isActive())
            _timer->stop();

        // a könyvtárböngészőből lekérjük a könyvtár nevét
        QDir dir(dirName);
        dir.setFilter(QDir::Files);
        dir.setSorting(QDir::Name);
        QFileInfoList fileInfos = dir.entryInfoList(); // könyvtár tartalmának kiolvasása

        foreach(QPixmap* image, _images) // korábbi képek törlése
        {
            delete image;
        }
        _images.clear();

        foreach(QFileInfo fileInfo, fileInfos)
        {
            QPixmap* image = new QPixmap(fileInfo.absoluteFilePath()); // képek betöltése
            if (!image->isNull()) // amennyiben képfájl
                _images.append(image); // felvesszük a képek közé
            else
                delete image; // különben töröljük
        }

        _currentImage = 0; // az első képpel kezdünk
        if (_images.size() > 0) // számbeállító beállítása
        {
            _ui->speedSpinBox->setMinimum(1);
            _ui->speedSpinBox->setMaximum(_images.size());
            _ui->speedSpinBox->setValue(_images.size());
        }
        else
        {
            _ui->speedSpinBox->setMinimum(0);
            _ui->speedSpinBox->setMaximum(0);
            _ui->speedSpinBox->setValue(0);

            QMessageBox::warning(this, trUtf8("Hiba!"), trUtf8("A könyvtár nem tartalmazott képeket!"));
        }

        reloadLabels();
        reloadImages();
    }
}

void MotionPictureWidget::startStopMotion()
{
    if (!_timer->isActive() && _images.size() > 0) // ha nem fut az időzítő és van kép, elindítjuk
    {
        _timer->start(1000 / _ui->speedSpinBox->value());
    }
    else // ha most fut az időzítő, leállítjuk
    {
        _timer->stop();
    }
}

void MotionPictureWidget::changeSpeed(int value)
{
    if (_images.size() > 0 && _timer->isActive())
    {
        // az időzítőt újra kell indítanunk a megadott sebességgel
        _timer->stop();
        _timer->start(1000 / value);
    }
    reloadLabels();
    reloadImages();
}

void MotionPictureWidget::changeImages()
{
    if (_images.size() > 0)
        _currentImage = (_currentImage + 1) % _images.size(); // index léptetése
    reloadImages();
}

void MotionPictureWidget::reloadImages()
{
    if (_images.size() > 0) // amennyiben van kép
    {
        _ui->mainImageLabel->setPixmap(_images[_currentImage]->scaled(QSize(298, 298))); // nagy kép beállítása
        for (int i = 0; i < _smallImageLabels.size(); i++)
            _smallImageLabels[i]->setPixmap(_images[(_currentImage + i + 1) % _images.size()]->scaled(QSize(18,18))); // kis képek beállítása
    }
}

void MotionPictureWidget::reloadLabels()
{
    foreach(QLabel* label, _smallImageLabels) // korábbi címkék törlése
    {
        _ui->smallImageLayout->removeWidget(label);
        delete label;
    }
    _smallImageLabels.clear();

    for (int i = 0; i < _ui->speedSpinBox->value(); i++) // új címkék felvétele
    {
        QLabel* label = new QLabel();
        label->setFixedSize(18,18); // rögzített méretű lesz a címke
        label->setFrameShape(QFrame::Box); // egyszerű keret
        _ui->smallImageLayout->addWidget(label, i / 12, i % 12);
        _smallImageLabels.append(label);
    }
}
