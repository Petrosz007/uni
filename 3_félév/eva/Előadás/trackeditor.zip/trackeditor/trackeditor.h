#ifndef TRACKEDITOR_H
#define TRACKEDITOR_H

#include <QDialog>
#include <QList>
#include <QTableView>

class QPushButton;
class QTableWidget;
class QTableView;

class Track
{
public:
    Track(const QString &title = "", int duration = 0);

    QString title;
    int duration;
};

class TrackEditor : public QDialog
{
    Q_OBJECT

public:
    TrackEditor(QList<Track> *tracks, QWidget *parent = nullptr);

    void done(int result);

private slots:
    void addTrack();

private:
    QTableWidget *_tableWidget;
    QPushButton *_addTrackButton;
    QPushButton *_okButton;
    QPushButton *_cancelButton;
    QList<Track> *_tracks;
};

#endif
