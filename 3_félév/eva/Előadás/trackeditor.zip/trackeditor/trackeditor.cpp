#include <QtGui>
#include <QTableWidget>
#include <QLayout>
#include <QPushButton>

#include "trackdelegate.h"
#include "trackeditor.h"

Track::Track(const QString &title, int duration)
{
    this->title = title;
    this->duration = duration;
}

TrackEditor::TrackEditor(QList<Track> *tracks, QWidget *parent)
    : QDialog(parent)
{
    _tracks = tracks;

    _tableWidget = new QTableWidget(tracks->count(), 2);
    _tableWidget->setItemDelegate(new TrackDelegate(1));
    _tableWidget->setHorizontalHeaderLabels(
            QStringList() << tr("Track") << tr("Duration"));

    for (int row = 0; row < tracks->count(); ++row) {
        Track track = tracks->at(row);

        QTableWidgetItem *item0 = new QTableWidgetItem(track.title);
        _tableWidget->setItem(row, 0, item0);

        QTableWidgetItem *item1
             = new QTableWidgetItem(QString::number(track.duration));
        item1->setTextAlignment(Qt::AlignRight);
        _tableWidget->setItem(row, 1, item1);
    }

    _tableWidget->resizeColumnToContents(0);

    _addTrackButton = new QPushButton(tr("&Add Track"));

    _okButton = new QPushButton(tr("OK"));
    _okButton->setDefault(true);

    _cancelButton = new QPushButton(tr("Cancel"));

    connect(_addTrackButton, SIGNAL(clicked()), this, SLOT(addTrack()));
    connect(_okButton, SIGNAL(clicked()), this, SLOT(accept()));
    connect(_cancelButton, SIGNAL(clicked()), this, SLOT(reject()));

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addWidget(_addTrackButton);
    buttonLayout->addStretch();
    buttonLayout->addWidget(_okButton);
    buttonLayout->addWidget(_cancelButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(_tableWidget);
    mainLayout->addLayout(buttonLayout);
    setLayout(mainLayout);

    setWindowTitle(tr("Track Editor"));
}

void TrackEditor::done(int result)
{
    if (result == QDialog::Accepted) {
        _tracks->clear();
        for (int row = 0; row < _tableWidget->rowCount(); ++row) {
            QString title = _tableWidget->item(row, 0)->text();
            int duration = _tableWidget->item(row, 1)->text().toInt();
            _tracks->append(Track(title, duration));
        }
    }
    QDialog::done(result);
}

void TrackEditor::addTrack()
{
    _tableWidget->insertRow(_tableWidget->rowCount());
}
