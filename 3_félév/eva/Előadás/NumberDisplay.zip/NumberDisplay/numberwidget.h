#ifndef NUMBERWIDGET_H
#define NUMBERWIDGET_H

#include <QWidget>
#include <QSlider>
#include <QLCDNumber>

class NumberWidget : public QWidget // egyedi ablak osztálya
{
public:
    NumberWidget(QWidget *parent = 0); // a konstruktor megkapja a szülő ablakot
    ~NumberWidget();

private:
    QSlider* _slider; // számbállító csúszka
    QLCDNumber* _lcdNumber; // digitális számmegjelenítő
};

#endif // NUMBERWIDGET_H
