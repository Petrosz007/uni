#include <QApplication>
#include "numberwidget.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    NumberWidget w;
    w.show(); // a főprogram csak példányosítja és megjeleníti az ablakot
    
    return a.exec();
}
