#include "numberwidget.h"

NumberWidget::NumberWidget(QWidget *parent)
    : QWidget(parent) // meghívjuk az ős konstruktorát
{
    setWindowTitle(tr("Number Display")); // ablakcím beállítása
    setFixedSize(300, 175); // rögzített méret beállítása

    _slider = new QSlider(this); // a vezérlő megkapja szülőnek az ablakot
    _slider->setMinimum(0); // számhatárok beállítása
    _slider->setMaximum(1000);
    _slider->setValue(0); // aktuális érték beállítása
    _slider->setOrientation(Qt::Horizontal); // csúszkairány beállítása
    _slider->setGeometry(5, 5, 290, 30); // elheklyezkedés beállítása

    _lcdNumber = new QLCDNumber(4, this); // megadjuk a számjegyek számát is
    _lcdNumber->display(0); // megjelenített érték (egyben eseménykezelő is)
    _lcdNumber->setGeometry(5, 50, 290, 120);

    connect(_slider, SIGNAL(valueChanged(int)), _lcdNumber, SLOT(display(int)));
    // esemény és eseménykezelő összekötése
}

NumberWidget::~NumberWidget()
{
}
