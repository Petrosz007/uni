#ifndef BUILDINGDELEGATE_H
#define BUILDINGDELEGATE_H

#include <QSqlRelationalDelegate>

class BuildingDelegate : public QSqlRelationalDelegate // egyedi megjelenítő osztály
{
    Q_OBJECT
public:
    BuildingDelegate(QObject *parent = 0);
    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
    // felüldefiniáljuk a kirajzoló műveletet
    QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const;
    // szerkesztõmezõ létrehozása
    void setEditorData(QWidget *editor, const QModelIndex &index) const;
    // adatok beállítása
    void setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const;
    // visszaírás az adatbázisba
private:
    QStringList shoreList() const; // a partok listájának betöltése
    QString valueToFeatures(int value) const; // a jellemzők kezelése
};

#endif // BUILDINGDELEGATE_H
