#include "buildingdelegate.h"
#include <QStyleOptionViewItem>
#include <QByteArray>
#include <QVector>
#include <QtGui>

BuildingDelegate::BuildingDelegate(QObject *parent) :
        QSqlRelationalDelegate(parent)
{
}


void BuildingDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option,const QModelIndex &index) const
{
    switch (index.column())
    {
    case 4: // tengerpart távolság oszlop
        {
            QString text;

            int shoreDistance = index.data().toInt(); // adat lekérdezése

            if (shoreDistance == 1)
                text = trUtf8("közvetlen");
            else
                text = QString::number(shoreDistance) + " m";

            QStyleOptionViewItem optionViewItem = option;	// kiírás módjának beállítása
            optionViewItem.displayAlignment = Qt::AlignRight | Qt::AlignVCenter; // jobbra és középre tagolt

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text); // adat kirajzolása
            drawFocus(painter, optionViewItem, optionViewItem.rect); // fókusz kirajzolása
        }
        break;
    case 5: // tengerpart típus oszlop
        {
            QString text = shoreList().at(index.data().toInt()); // a szöveget a listából kérdezzük le

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignLeft | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    case 6: // jellemzők oszlop
        {
            QString text;

            if (index.data().isNull() || index.data().toInt() == 0)
            {
                text = "nincsenek";
            }
            else
            {
                text = valueToFeatures(index.data().toInt()); // az adatokat átképezzük szövegre
            }

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignLeft | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    default:
        QSqlRelationalDelegate::paint(painter, option, index); // különben az alapértelmezett kirajzolást végezze
        break;
    }
}

QWidget *BuildingDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    if (index.column() == 5)  // a tengerpart oszlopnál legördülő menüt jelenítünk meg
    {
        QComboBox *shoreComboBox = new QComboBox(parent); // a szerkesztőmező nem a szokásos szövegmező, hanem egy legördülő menü lesz
        shoreComboBox->addItems(shoreList()); // felvesszük a lista által tartalmazott elemeket
        return shoreComboBox; // visszaadjuk ezt a szerkesztőmezőt
    } else
        return QSqlRelationalDelegate::createEditor(parent, option, index); // különben a szokványos szerkesztőmezőt használjuk
}

void BuildingDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    if (index.column() == 5) {
        int i = index.data().toInt();
        QComboBox *shoreComboBox = qobject_cast<QComboBox *>(editor); // cast kell, mert alapértelmezetten nem tudja, hogy legördülő menü
        shoreComboBox->setCurrentIndex(i); // szerkesztőmező elemének beállítása
    } else {
        QSqlRelationalDelegate::setEditorData(editor, index);
    }
}

void BuildingDelegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
    if (index.column() == 5) {
        QComboBox *shoreComboBox = qobject_cast<QComboBox *>(editor);
        model->setData(index, shoreComboBox->currentIndex ()); // adat visszaírása a modellbe
    } else
        QSqlRelationalDelegate::setModelData(editor, model, index);
}

QStringList BuildingDelegate::shoreList() const
{
    QStringList list;
    list.append(trUtf8("Homokos"));
    list.append(trUtf8("Sziklás"));
    list.append(trUtf8("Kavicsos"));
    list.append(trUtf8("Apró kavicsos"));

    return list;
}

QString BuildingDelegate::valueToFeatures(int value) const
{
    // a jellemzők lekérdezését bitenkénti eltolással oldjuk meg
    QString result;
    if (value % 2 == 1)
        result += trUtf8("főút, ");
    if ((value >> 1) % 2 == 1)
        result += trUtf8("parti szolgálat, ");
    if ((value >> 2) % 2 == 1)
        result += trUtf8("úszómedence, ");
    if ((value >> 3) % 2 == 1)
        result += trUtf8("kert, ");
    if ((value >> 4) % 2 == 1)
        result += trUtf8("saját parkoló, ");

    if (result.size() > 0)
        return result.left(result.size() - 2);
    else
        return result;
}
