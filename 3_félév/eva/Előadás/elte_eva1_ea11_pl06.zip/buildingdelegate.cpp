#include "buildingdelegate.h"
#include <QStyleOptionViewItem>
#include <QByteArray>
#include <QVector>
#include <QtGui>
#include "featureeditorlistwidget.h"

BuildingDelegate::BuildingDelegate(QObject *parent) :
        QSqlRelationalDelegate(parent)
{
}


void BuildingDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option,const QModelIndex &index) const
{
    switch (index.column())
    {
    case 4: // épület állapota
        {
            QString text = "ismeretlen";
            switch (index.data().toInt())
            {
            case 0: text = trUtf8("foglalható"); break;
            case 1: text = trUtf8("felújítás alatt"); break;
            case 2: text = trUtf8("nem foglalható"); break;
            }

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignLeft | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    case 5:
        {
            QString text;

            int shoreDistance = index.data().toInt();

            if (shoreDistance == 1)
                text = trUtf8("közvetlen");
            else
                text = QString::number(shoreDistance) + " m";

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignRight | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    case 6:
        {
            QString text = shoreList().at(index.data().toInt());

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignLeft | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    case 7:
        {
            FeatureEditorListWidget* featureEditorlistWidget = new FeatureEditorListWidget();
            featureEditorlistWidget->setFeatures(index.data().toInt());

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignLeft | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, featureEditorlistWidget->getFeaturesString());
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    case 10:
    case 11:
        {
            QString text = "EUR " + QString::number(index.data().toInt());

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignRight | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    default:
        QSqlRelationalDelegate::paint(painter, option, index);
        break;
    }
}

QWidget *BuildingDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    switch (index.column())
    {
    case 4: // épület állapota
        {
            QComboBox *stateComboBox = new QComboBox(parent);
            stateComboBox->addItem(trUtf8("mind foglalható"));
            stateComboBox->addItem(trUtf8("mind felújás alatt"));
            return stateComboBox;
        }
        break;
    case 6:
        {
            QComboBox *shoreComboBox = new QComboBox(parent);
            shoreComboBox->addItems(shoreList());
            return shoreComboBox;
        }
        break;
    case 7:
        {
            FeatureEditorListWidget* featureEditorlistWidget = new FeatureEditorListWidget(parent);
            return featureEditorlistWidget;
        }
        break;
    default:
        return QSqlRelationalDelegate::createEditor(parent, option, index); // különben a szokványos szerkesztõmezõt használjuk
        break;
    }
}

void BuildingDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    switch (index.column())
    {
    case 4: // épület állapota
        {
            QComboBox *stateComboBox = qobject_cast<QComboBox*>(editor);
            if (index.data().toInt() == 2)
                stateComboBox->setCurrentIndex(1);
            else
                stateComboBox->setCurrentIndex(0);
        }
        break;
    case 6:
        {
            QComboBox *shoreComboBox = qobject_cast<QComboBox*>(editor);
            shoreComboBox->setCurrentIndex(index.data().toInt());
        }
        break;
    case 7:
        {
            FeatureEditorListWidget* featureEditorlistWidget = qobject_cast<FeatureEditorListWidget *>(editor);
            featureEditorlistWidget->setFeatures(index.data().toInt());
        }
        break;
    default:
        QSqlRelationalDelegate::setEditorData(editor, index);
        break;
    }
}

void BuildingDelegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
    switch (index.column())
    {
    case 4: // épület állapota
        {
            QComboBox *stateComboBox = qobject_cast<QComboBox*>(editor);
            if (stateComboBox->currentIndex() == 1)
                model->setData(index, 2);
            else
                model->setData(index, 0);
        }
        break;
    case 6:
        {
            QComboBox *shoreComboBox = qobject_cast<QComboBox*>(editor);
            model->setData(index, shoreComboBox->currentIndex());
        }
        break;
    case 7:
        {
            FeatureEditorListWidget* featureEditorlistWidget = qobject_cast<FeatureEditorListWidget *>(editor);
            model->setData(index, featureEditorlistWidget->getFeatures());
        }
        break;
    default:
        QSqlRelationalDelegate::setModelData(editor, model, index);
        break;
    }
}

QStringList BuildingDelegate::shoreList() const
{
    QStringList list;
    list.append(trUtf8("Homokos"));
    list.append(trUtf8("Sziklás"));
    list.append(trUtf8("Kavicsos"));
    list.append(trUtf8("Apró kavicsos"));

    return list;
}
