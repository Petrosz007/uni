#include "buildingtablemodel.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlRecord>

BuildingTableModel::BuildingTableModel(QObject *parent) :
    QSqlRelationalTableModel(parent)
{
    setTable("building");
    setSort(1, Qt::AscendingOrder);
    setEditStrategy(QSqlTableModel::OnManualSubmit);
    setHeaderData(0, Qt::Horizontal, trUtf8("Azonosító"));
    setHeaderData(1, Qt::Horizontal, trUtf8("Név"));
    setHeaderData(2, Qt::Horizontal, trUtf8("Város"));
    setHeaderData(3, Qt::Horizontal, trUtf8("Utca"));
    setHeaderData(4, Qt::Horizontal, trUtf8("Állapot")); // számított oszlop
    setHeaderData(5, Qt::Horizontal, trUtf8("Tenger távolság"));
    setHeaderData(6, Qt::Horizontal, trUtf8("Tengerpart"));
    setHeaderData(7, Qt::Horizontal, trUtf8("Jellemzők"));
    setHeaderData(8, Qt::Horizontal, trUtf8("Megjegyzés"));
    setHeaderData(9, Qt::Horizontal, trUtf8("Apartmanok")); // számított oszlop
    setHeaderData(10, Qt::Horizontal, trUtf8("Minimum ár")); // számított oszlop
    setHeaderData(11, Qt::Horizontal, trUtf8("Maximum ár")); // számított oszlop
    setRelation(2, QSqlRelation("city", "id", "name"));

    connect(this, SIGNAL(beforeInsert(QSqlRecord&)), this, SLOT(onBeforeInsert(QSqlRecord&)));
    connect(this, SIGNAL(dataChanged(QModelIndex,QModelIndex)), this, SLOT(onDataChanged(QModelIndex,QModelIndex)));
}

void BuildingTableModel::insertRow(int row)
{
    QSqlRelationalTableModel::insertRow(row); // új sor beszúrása

    setData(index(row, 3),1); // alapértelmezett adatok
    setData(index(row, 4),1);
}


QVariant BuildingTableModel::data(const QModelIndex &index, int role) const
{
    if(!index.isValid()) return QVariant();

    // a 4. oszloptól eltoljuk az érétkkeket eggyel:
    if (index.column() >= 5 && index.column() <= 8)
        return QSqlRelationalTableModel::data(this->index(index.row(), index.column() - 1), role);

    if (index.column() >= 9 && index.column() <= 11 && role == Qt::TextAlignmentRole )
    {
        return QVariant(Qt::AlignRight | Qt::AlignVCenter);
    }
    // tartalom számítása:
    if (index.column() == 4 && ( role == Qt::DisplayRole || role == Qt::EditRole)) // épület állapota
    {
        // rekérdezzük a nem renovált apartmanok számát:
        QSqlQuery query;
        query.exec("select count(*) from apartment where renovation = 0 && building_id = " + this->data(this->index(index.row(), 0)).toString());
        if (query.next())
            // összehasonlítunk a másik számított oszloppal:
            if (query.value(0).toInt() == this->data(this->index(index.row(), 9)))
                return QVariant(0); // nincs tatarozás alatt
            else if (query.value(0).toInt() > 0)
                return QVariant(1); // néhány apartman felújítás alatt
            else
                return QVariant(2); // az egész épület felújítás alatt
        else
            return QVariant(-1); // nincs apartman az épületben
    }
    if (index.column() == 9 && ( role == Qt::DisplayRole || role == Qt::EditRole))
    {
        QSqlQuery query;
        query.exec("select count(*) from apartment where building_id = " + this->data(this->index(index.row(), 0)).toString());
        if (query.next())
            return QVariant(query.value(0).toInt());
        else
            return QVariant(0);
    }
    if (index.column() == 10 && ( role == Qt::DisplayRole || role == Qt::EditRole))
    {
        QSqlQuery query;
        query.exec("select min(price) from price where apartment_id in (select id from apartment where building_id = " + this->data(this->index(index.row(), 0)).toString() + ")");
        if (query.next())
            return QVariant(query.value(0).toInt());
        else
            return QVariant("?");
    }
    if (index.column() == 11 && ( role == Qt::DisplayRole || role == Qt::EditRole))
    {
        QSqlQuery query;
        query.exec("select max(price) from price where apartment_id in (select id from apartment where building_id = " + this->data(this->index(index.row(), 0)).toString() + ")");
        if (query.next())
            return QVariant(query.value(0).toInt());
        else
            return QVariant("?");
    }
    else
    {
        return QSqlRelationalTableModel::data(index, role);
    }
}

int BuildingTableModel::columnCount(const QModelIndex& parent) const
{
    return QSqlRelationalTableModel::columnCount(parent) + 4; // az oszlopok számát megnöveljük 3-mal
}

Qt::ItemFlags BuildingTableModel::flags(const QModelIndex& index) const
{
    Qt::ItemFlags flag = QSqlTableModel::flags(index); // lekérdezzük az alap állapotjelzőt
    if (index.column() == 4) // a negyedik oszlop számított
        flag |= Qt::ItemIsSelectable | Qt::ItemIsEditable; // mégis szerkeszthetővé tesszük

    return flag;
}

bool BuildingTableModel::setData(const QModelIndex& index, const QVariant& value, int role)
{
    if (index.column() < 4)
        return QSqlRelationalTableModel::setData(index, value, role);
    if (index.column() == 4) // az apartmanokban kell jeleznünk a felújítást
    {
        if (value.toInt() == 0)
        {
            // az apartment táblát kell módosítanunk
            QSqlQuery query;
            return (query.exec("update apartment set renovation = 0 where building_id = " + this->data(this->index(index.row(), 0)).toString()));
            // visszaadjuk, hogy sikerült-e a módosítás
        }
        else if (value.toInt() == 2)
        {
            QSqlQuery query;
            return (query.exec("update apartment set renovation = 1 where building_id = " + this->data(this->index(index.row(), 0)).toString()));
        }
        else
            return false;
        dataChanged(index, index); // jelezzük, hogy változás történt a modelben
    }
    if (index.column() > 4) // a későbbi oszlopokat csúsztatni kell eggyel
        return QSqlRelationalTableModel::setData(this->index(index.row(), index.column() - 1), value, role);
}

void BuildingTableModel::onBeforeInsert(QSqlRecord& record)
{
    record.setValue("comment", trUtf8("új hírdetés"));
}

void BuildingTableModel::onDataChanged(const QModelIndex& topLeft, const QModelIndex& bottomRight)
{
    if (topLeft.isValid() && topLeft.column() == 4) // ha a tengerpart oszlopban vagyunk
    {
        if (!data(topLeft).isNull() && data(topLeft).toInt() <= 0) // ha az érték ki van töltve, de nem pozitív
        {
            QMessageBox::warning(0, trUtf8("Hibás kitöltés"), trUtf8("A tengerpart távolsága csak pozitív szám lehet!"));
            setData(topLeft, 1); // érték módosítása 1-re
        }
    }
}
