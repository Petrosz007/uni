#ifndef BUILDINGTABLEMODEL_H
#define BUILDINGTABLEMODEL_H

#include <QSqlRelationalTableModel>

class BuildingTableModel : public QSqlRelationalTableModel // egyedi táblamodell osztály
{
    Q_OBJECT
public:
    BuildingTableModel(QObject *parent = 0);

    void insertRow(int row); // sor beszúrásának felüldefiniálása
    Qt::ItemFlags flags(const QModelIndex& index) const; // állapotjelzők lekérdezése
    int columnCount(const QModelIndex & parent = QModelIndex()) const; // oszlopszám felüldefiniálása
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const; // adatlekérdezés felüldefiniálása
    bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole); // adatbeállítás

private slots:
    void onBeforeInsert(QSqlRecord& record);
    void onDataChanged(const QModelIndex& topLeft, const QModelIndex& bottomRight);
};

#endif // APPARTMENTTABLEMODEL_H
