#ifndef BUILDINGEDITORDIALOG_H
#define BUILDINGEDITORDIALOG_H

#include <QDialog>
#include <QTableView>
#include <QDialogButtonBox>
#include <QSqlRelationalTableModel>
#include "cityeditordialog.h"
#include "buildingtablemodel.h"

class BuildingEditorDialog : public QDialog
{
    Q_OBJECT

public:
    BuildingEditorDialog(QWidget *parent = 0);
    ~BuildingEditorDialog();

private slots:
    void addButton_Clicked();
    void removeButton_Clicked();
    void submitButton_Clicked();
    void tableView_DoubleClicked(QModelIndex index); // táblaszerkesztő dupla kattintása

private:
    void setupUi(); // felület inicializálása

    QTableView* _tableView;
    BuildingTableModel* _model;
    QDialogButtonBox* _buttonBox;
    QPushButton* _addButton;
    QPushButton* _removeButton;
    QPushButton* _submitButton;
    QPushButton* _revertButton;
    CityEditorDialog* _cityEditorDialog; // város szerkesztő dialógusablak
};

#endif // BUILDINGEDITORDIALOG_H
