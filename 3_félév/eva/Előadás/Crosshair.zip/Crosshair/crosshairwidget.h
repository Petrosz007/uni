#ifndef CROSSHAIRWIDGET_H
#define CROSSHAIRWIDGET_H

#include <QWidget>

class CrosshairWidget : public QWidget
{
    Q_OBJECT
    
public:
    CrosshairWidget(QWidget *parent = 0);
    ~CrosshairWidget();

protected:
    void paintEvent(QPaintEvent *); // rajzolás eseménykezelője
};

#endif // CROSSHAIRWIDGET_H
