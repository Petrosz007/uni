#include "crosshairwidget.h"

#include <QPainter>

CrosshairWidget::CrosshairWidget(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle(trUtf8("Céllövölde"));
}

CrosshairWidget::~CrosshairWidget()
{
    
}

void CrosshairWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this); // rajzoló objektum
    painter.setRenderHint(QPainter::Antialiasing); // élsimítás használata

    QPen dashDotRedPen(QBrush(QColor(255, 0, 0)), 2, Qt::DashDotLine); // pontozott-szaggatott vonalú piros toll
    QPen solidRedPen(QBrush(QColor(255, 0, 0)), 3); // sima piros toll
    QBrush greenBrush(QColor(0, 255, 0), Qt::Dense1Pattern); // pöttyös zöld ecset

    painter.fillRect(0, 0, width(), height(), greenBrush); // háttér kitöltése
	// vagy: painter.setBackground(greenBrush);

    painter.setPen(dashDotRedPen); // toll beállítása
    painter.setBrush(Qt::NoBrush); // ecset eltávolítása
    painter.drawLine(0, height() / 2, width(), height() / 2); // vonalak kirajzolása
    painter.drawLine(width() / 2, 0, width() / 2, height());

    painter.setPen(solidRedPen); // toll beállítása
    painter.drawEllipse(width() / 2 - 30, height() / 2 - 30, 60, 60); // kör kirajzolása

}
