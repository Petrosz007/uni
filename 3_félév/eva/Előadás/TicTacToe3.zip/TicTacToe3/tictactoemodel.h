#ifndef TICTACTOEMODEL_H
#define TICTACTOEMODEL_H

class TicTacToeModel // a modell típusa
{
public:
    TicTacToeModel();
    ~TicTacToeModel();
    void newGame(); // új játék kezdése
    void stepGame(int x, int y); // játék léptetése
    int stepNumber() { return _stepNumber; } // lépések számának lekérdezése
    int isGameOver(); // játékos végének ellenőrzése
    int getField(int x, int y); // játékmező lekérdezése

private: 
    int _stepNumber; // lépések száma
    int _currentPlayer; // játékos száma
    int** _gameTable; // játéktábla
};

#endif // TICTACTOEGAMELOGIC_H
