﻿
namespace ELTE.Forms.TicTacToeGame.Model
{
    /// <summary>
    /// Játékos felsorolási típusa.
    /// </summary>
    public enum Player
    {
        NoPlayer,
        PlayerX,
        PlayerO
    }
}
