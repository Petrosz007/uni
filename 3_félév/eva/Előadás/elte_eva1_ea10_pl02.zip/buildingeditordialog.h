#ifndef USEREDITORDIALOG_H
#define USEREDITORDIALOG_H

#include <QDialog>
#include <QDialogButtonBox>
#include <QTableView>
#include <QSqlTableModel>

class BuildingEditorDialog : public QDialog
{
    Q_OBJECT
public:
    BuildingEditorDialog(QWidget *parent = 0);
    ~BuildingEditorDialog();

private slots:
    void addButton_Clicked();
    void removeButton_Clicked();
private:
    void setupModel();
    void setupUi();

    QTableView* _tableView;
    QSqlTableModel* _model;
    QDialogButtonBox* _buttonBox;
    QPushButton* _addButton;
    QPushButton* _removeButton;
};

#endif // USEREDITORDIALOG_H
