#ifndef BUILDINGDELEGATE_H
#define BUILDINGDELEGATE_H

#include <QSqlRelationalDelegate>

class BuildingDelegate : public QSqlRelationalDelegate // egyedi megjelenítő osztály
{
    Q_OBJECT
public:
    BuildingDelegate(QObject *parent = 0);
    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
    // felüldefiniáljuk a kirajzoló műveletet

private:
    QString valueToFeatures(int value) const; // a jellemzők kezelése
};

#endif // BUILDINGDELEGATE_H
