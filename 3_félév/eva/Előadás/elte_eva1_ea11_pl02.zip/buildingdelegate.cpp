#include "buildingdelegate.h"
#include <QStyleOptionViewItem>
#include <QByteArray>
#include <QVector>
#include <QtGui>

BuildingDelegate::BuildingDelegate(QObject *parent) :
        QSqlRelationalDelegate(parent)
{
}

void BuildingDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option,const QModelIndex &index) const
{
    switch (index.column())
    {
    case 4: // tengerpart távolság oszlop
        {
            QString text;

            int shoreDistance = index.data().toInt(); // adat lekérdezése

            if (shoreDistance == 1)
                text = trUtf8("közvetlen");
            else
                text = QString::number(shoreDistance) + " m";

            QStyleOptionViewItem optionViewItem = option;	// kiírás módjának beállítása
            optionViewItem.displayAlignment = Qt::AlignRight | Qt::AlignVCenter; // jobbra és középre tagolt

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text); // adat kirajzolása
            drawFocus(painter, optionViewItem, optionViewItem.rect); // fókusz kirajzolása
        }
        break;
    case 6: // jellemzők oszlop
        {
            QString text;

            if (index.data().isNull() || index.data().toInt() == 0)
            {
                text = "nincsenek";
            }
            else
            {
                text = valueToFeatures(index.data().toInt());
            }

            QStyleOptionViewItem optionViewItem = option;
            optionViewItem.displayAlignment = Qt::AlignLeft | Qt::AlignVCenter;

            drawDisplay(painter, optionViewItem, optionViewItem.rect, text);
            drawFocus(painter, optionViewItem, optionViewItem.rect);
        }
        break;
    default:
        QSqlRelationalDelegate::paint(painter, option, index); // különben az alapértelmezett kirajzolást végezze
        break;
    }
}

QString BuildingDelegate::valueToFeatures(int value) const
{
    // a jellemzők lekérdezését bitenkénti eltolással oldjuk meg
    QString result;
    if (value % 2 == 1)
        result += trUtf8("főút, ");
    if ((value >> 1) % 2 == 1)
        result += trUtf8("parti szolgálat, ");
    if ((value >> 2) % 2 == 1)
        result += trUtf8("úszómedence, ");
    if ((value >> 3) % 2 == 1)
        result += trUtf8("kert, ");
    if ((value >> 4) % 2 == 1)
        result += trUtf8("saját parkoló, ");

    if (result.size() > 0)
        return result.left(result.size() - 2);
    else
        return result;
}
