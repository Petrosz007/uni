#include "buildingeditordialog.h"
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QSqlError>
#include <QSqlRecord>
#include "buildingdelegate.h"

BuildingEditorDialog::BuildingEditorDialog(QWidget *parent)
    : QDialog(parent)
{
    setupModel();
    setupUi();
}

BuildingEditorDialog::~BuildingEditorDialog()
{
    delete _model;
}

void BuildingEditorDialog::addButton_Clicked()
{
    int row;
    if (_tableView->currentIndex().isValid())
    {
        row = _tableView->currentIndex().row();
    }
    else
    {
        row = _model->rowCount();
    }

    _model->insertRow(row);
    _model->setData(_model->index(row, 4), 1); // alapértemezett értékek beírása
    _model->setData(_model->index(row, 5), 1);
    _model->setData(_model->index(row, 6), 0);

    _tableView->setCurrentIndex(_model->index(row, 0));
    _tableView->edit(_model->index(row, 0));
}

void BuildingEditorDialog::removeButton_Clicked()
{
    QModelIndex index = _tableView->currentIndex();

    if (index.isValid())
    {
        _model->removeRow(index.row());
        _tableView->setCurrentIndex(_model->index(index.row()-1, 0));
    }
    else
    {
        QMessageBox::warning(this, trUtf8("Nincs kijelölés!"), trUtf8("Kérem jelölje ki előbb a törlendő sort!"));
    }
}

void BuildingEditorDialog::submitButton_Clicked()
{
    _model->database().transaction();

    if (_model->submitAll())
    {
        _model->database().commit();
        _model->select();
    } else
    {
        _model->database().rollback();
        QMessageBox::warning(this, trUtf8("Hiba történt a mentéskor!"), trUtf8("Az adatbázis a kvetkező hibát jelezte: %1").arg(_model->lastError().text()));
    }
}

void BuildingEditorDialog::tableView_DoubleClicked(QModelIndex index)
{
    if (index.isValid() && index.column() == 2)
    {
        _cityEditorDialog->show();
        // megjelenítjük a városszerkesztőt
    }
}

void BuildingEditorDialog::model_BeforeInsert(QSqlRecord& record)
{
    if (record.value("comment").isNull()) // ha a komment oszlop üres
        record.setValue("comment", trUtf8("új hírdetés"));
}

void BuildingEditorDialog::model_DataChanged(const QModelIndex& topLeft, const QModelIndex& bottomRight)
{
    if (topLeft.isValid() && topLeft.column() == 4) // ha a tengerpart oszlopban vagyunk
    {
        if (!_model->data(topLeft).isNull() && _model->data(topLeft).toInt() <= 0) // ha az érték ki van töltve, de nem pozitív
        {
            QMessageBox::warning(this, trUtf8("Hibás kitöltés"), trUtf8("A tengerpart távolsága csak pozitív szám lehet!"));
            _model->setData(topLeft, 1); // érték módosítása 1-re
        }
    }
}

void BuildingEditorDialog::setupModel()
{
    _model = new QSqlRelationalTableModel(this);
    _model->setTable("building");
    _model->setSort(1, Qt::AscendingOrder);
    _model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _model->setHeaderData(0, Qt::Horizontal, trUtf8("Azonosító"));
    _model->setHeaderData(1, Qt::Horizontal, trUtf8("Név"));
    _model->setHeaderData(2, Qt::Horizontal, trUtf8("Város"));
    _model->setHeaderData(3, Qt::Horizontal, trUtf8("Utca"));
    _model->setHeaderData(4, Qt::Horizontal, trUtf8("Tenger távolság"));
    _model->setHeaderData(5, Qt::Horizontal, trUtf8("Tengerpart"));
    _model->setHeaderData(6, Qt::Horizontal, trUtf8("Jellemzők"));
    _model->setHeaderData(7, Qt::Horizontal, trUtf8("Megjegyzés"));
    _model->setRelation(2, QSqlRelation("city", "id", "name"));
    _model->select();

    connect(_model, SIGNAL(beforeInsert(QSqlRecord&)), this, SLOT(model_BeforeInsert(QSqlRecord&)));
    // beszúrás előtti esemény társítása
    connect(_model, SIGNAL(dataChanged(QModelIndex,QModelIndex)), this, SLOT(model_DataChanged(QModelIndex,QModelIndex)));
    // adatváltoztatás esemény társítása
}

void BuildingEditorDialog::setupUi()
{
    _addButton = new QPushButton(trUtf8("&Beszúrás"));
    _removeButton = new QPushButton(trUtf8("&Törlés"));
    _submitButton = new QPushButton(trUtf8("&Mentés"));
    _revertButton = new QPushButton(trUtf8("&Visszavonás"));

    _buttonBox = new QDialogButtonBox(Qt::Horizontal);
    _buttonBox->addButton(_addButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_removeButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_submitButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_revertButton, QDialogButtonBox::ActionRole);

    connect(_addButton, SIGNAL(clicked()), this, SLOT(addButton_Clicked()));
    connect(_removeButton, SIGNAL(clicked()), this, SLOT(removeButton_Clicked()));
    connect(_submitButton, SIGNAL(clicked()), this, SLOT(submitButton_Clicked()));
    connect(_revertButton, SIGNAL(clicked()), _model, SLOT(revertAll()));

    _tableView = new QTableView(this);
    _tableView->setModel(_model);
    _tableView->setSelectionBehavior(QAbstractItemView::SelectItems);
    _tableView->resizeColumnsToContents();
    _tableView->setItemDelegate(new BuildingDelegate()); // egyedi delegált használatba vétele
    _tableView->setColumnHidden(0, true);

    connect(_tableView, SIGNAL(doubleClicked(QModelIndex)), this, SLOT(tableView_DoubleClicked(QModelIndex)));
    // dupla kattintás eseménytársítása

    _cityEditorDialog = new CityEditorDialog(this);
    _cityEditorDialog->setModel(_model->relationModel(2)); // lekérjük a városok modelljét, és átadjuk a szerkesztőnek

    QVBoxLayout* mainLayout = new QVBoxLayout;
    mainLayout->addWidget(_tableView);
    mainLayout->addWidget(_buttonBox);
    setLayout(mainLayout);

    setFixedSize(800, 300);
    setWindowTitle(trUtf8("Épületek szerkesztése"));
}
