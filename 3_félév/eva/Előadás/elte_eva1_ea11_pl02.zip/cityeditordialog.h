#ifndef CITYEDITORDIALOG_H
#define CITYEDITORDIALOG_H

#include <QDialog>
#include <QDialogButtonBox>
#include <QListView>
#include <QSqlTableModel>

class CityEditorDialog : public QDialog
{
    Q_OBJECT
public:
    CityEditorDialog(QWidget *parent = 0);
    ~CityEditorDialog();

    void setModel(QSqlTableModel* model); // modell beállítása

private slots:
    void addButton_Clicked();
    void removeButton_Clicked();

private:
    void setupModel();
    void setupUi();

    QListView* _listView;
    QSqlTableModel* _model;
    QDialogButtonBox* _buttonBox;
    QPushButton* _addButton;
    QPushButton* _removeButton;
};

#endif // CITYEDITORDIALOG_H
