﻿using DLToolkit.Forms.Controls;
using Xamarin.Forms;

namespace ELTE.ColorGrid.View
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            FlowListView.Init();
        }
    }
}
