#ifndef TICTACTOEWIDGET_H
#define TICTACTOEWIDGET_H

#include <QWidget>
#include <QVector>
#include <QPushButton>
#include <QGridLayout>

class TicTacToeWidget : public QWidget // játékot megjelenítő ablak
{
    Q_OBJECT

public:
    TicTacToeWidget(QWidget *parent = 0);

private slots:
    void buttonClicked(); // táblagombra kattintás esménykezelője
    void newGameButtonClicked(); // új játék gombra kattintás eseménykezelője

private:
    void generateTable(); // tábla létrehozása

    // segédműveletek a játékhoz
    void newGame(); // új játék kezdése
    void stepGame(int x, int y); // játék léptetése
    void isGameWon(); // vége van-e a játéknak

    QGridLayout* _tableLayout;
    QVBoxLayout* _mainLayout;
    QPushButton* _newGameButton; // új játék gombja
    QVector<QVector<QPushButton*> > _gameTableButtons; // gombtábla

    // játék értékeinek tárolása
    int _stepNumber; // lépések száma
    int _currentPlayer; // játékos száma
    int** _gameTable; // játéktábla
};

#endif // TICTACTOEWIDGET_H
