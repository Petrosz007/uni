#include "tictactoewidget.h"
#include <QMessageBox>

TicTacToeWidget::TicTacToeWidget(QWidget *parent) : QWidget(parent)
{
    setMinimumSize(400, 400);
    setBaseSize(400,400);
    setWindowTitle(tr("Tic-Tac-Toe"));

    _newGameButton = new QPushButton(trUtf8("Új játék")); // új játék gomb
    connect(_newGameButton, SIGNAL(clicked()), this, SLOT(newGameButtonClicked()));

    _mainLayout = new QVBoxLayout(); // vertikális elhelyezkedés a teljes felületnek
    _mainLayout->addWidget(_newGameButton);

    _tableLayout = new QGridLayout(); // rácsos elhelyezkedés a játékmezőnek
    _mainLayout->addLayout(_tableLayout);
    generateTable();

    setLayout(_mainLayout);

    newGame();
}

void TicTacToeWidget::newGame()
{
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
        {
            _gameTable[i][j] = 0; // a játékosok pozícióit töröljük
            _gameTableButtons[i][j]->setText(""); // a szöveget töröljük
            _gameTableButtons[i][j]->setEnabled(true); // bekapcsoljuk a gombot
        }

    _stepNumber = 0;
    _currentPlayer = 1; // először az X lép
}

void TicTacToeWidget::stepGame(int x, int y)
{
    _gameTable[x][y] = _currentPlayer; // pozíció rögzítése

    if (_currentPlayer == 1)
        _gameTableButtons[x][y]->setText("X"); // megjelenítés a gombon
    else
        _gameTableButtons[x][y]->setText("0");
    _gameTableButtons[x][y]->setEnabled(false);

    _stepNumber++;
    _currentPlayer = _currentPlayer % 2 + 1;

    isGameWon();
}

void TicTacToeWidget::generateTable()
{
    _gameTable = new int*[3];
    _gameTableButtons.resize(3);

    for (int i = 0; i < 3; ++i)
    {
        _gameTable[i] = new int[3];
        _gameTableButtons[i].resize(3);
        for (int j = 0; j < 3; ++j)
        {
            _gameTableButtons[i][j]= new QPushButton(this);
            _gameTableButtons[i][j]->setFont(QFont("Times New Roman", 100, QFont::Bold));
            _gameTableButtons[i][j]->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
            _tableLayout->addWidget(_gameTableButtons[i][j], i, j); // gombok felvétele az elhelyezésbe

            connect(_gameTableButtons[i][j], SIGNAL(clicked()), this, SLOT(buttonClicked()));
        }
    }
}


void TicTacToeWidget::buttonClicked()
{
    QPushButton* senderButton = dynamic_cast <QPushButton*> (QObject::sender());
    int location = _tableLayout->indexOf(senderButton);

    stepGame(location / 3, location % 3);
}

void TicTacToeWidget::newGameButtonClicked()
{
    newGame();
}

void TicTacToeWidget::isGameWon()
{
    int won = 0;

    for(int i = 0; i < 3; ++i) // ellenőrzések végrehajtása
    {
        if (_gameTable[i][0] != 0 && _gameTable[i][0] == _gameTable[i][1] && _gameTable[i][1] == _gameTable[i][2])
            won = _gameTable[i][0];
    }
    for(int i = 0; i < 3; ++i)
    {
        if (_gameTable[0][i] != 0 && _gameTable[0][i] == _gameTable[1][i] && _gameTable[1][i] == _gameTable[2][i])
            won = _gameTable[0][i];
    }
    if (_gameTable[0][0] != 0 && _gameTable[0][0] == _gameTable[1][1] && _gameTable[1][1] == _gameTable[2][2])
        won = _gameTable[0][0];
    if (_gameTable[0][2] != 0 && _gameTable[0][2] == _gameTable[1][1] && _gameTable[1][1] == _gameTable[2][0])
        won = _gameTable[0][2];

    if (won == 1) // az eredmény függvényében jelenítjük meg a győztest
    {
        QMessageBox::information(this, trUtf8("Játék vége!"), trUtf8("Az X nyerte a játékot!"));
        newGame();
    }
    else if (won == 2)
    {
        QMessageBox::information(this, trUtf8("Játék vége!"), trUtf8("A O nyerte a játékot!"));
        newGame();
    }
    else if (_stepNumber == 9)
    {
        QMessageBox::information(this, trUtf8("Játék vége!"), trUtf8("A játék döntetlen lett!"));
        newGame();
    }
}
