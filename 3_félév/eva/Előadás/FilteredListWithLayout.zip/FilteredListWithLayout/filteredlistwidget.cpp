#include "filteredlistwidget.h"

#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QFileDialog>


FilteredListWidget::FilteredListWidget(QWidget *parent)
    : QWidget(parent)
{
    setBaseSize(256, 232); // alapméret beállítása
    setMinimumSize(200,300); // minimális méret beállítása
    setWindowTitle(tr("Szűrés listára")); // ablakcím beállítása

    _queryLabel = new QLabel("Szűrés:"); // az elrendezés miatt a vezérlőknek már nem kell megadni a szülőt
    _queryLabel->setGeometry(2, 2, 50, 20);
    _queryLineEdit = new QLineEdit;

    _resultListWidget = new QListWidget;

    _loadButton = new QPushButton("Fájl megnyitása");

    _upperLayout = new QHBoxLayout;
    _upperLayout->addWidget(_queryLabel); // elem felvétele az elrendezésbe
    _upperLayout->addWidget(_queryLineEdit);

    _mainLayout = new QVBoxLayout;
    _mainLayout->addLayout(_upperLayout); // másik elrendezés felvétele
    _mainLayout->addWidget(_resultListWidget);
    _mainLayout->addWidget(_loadButton);

    setLayout(_mainLayout); // elrendezés beállítása

    connect(_queryLineEdit, SIGNAL(textChanged(QString)), this, SLOT(filterList()));
    connect(_loadButton, SIGNAL(clicked()), this, SLOT(loadFile()));
        // társítás saját eseménykezelőhöz
}

FilteredListWidget::~FilteredListWidget()
{
}

void FilteredListWidget::filterList()
{
    _resultListWidget->clear(); // kitöröljük a korábbi tartalmat

    if (_queryLineEdit->text().isNull()) // ha nem írtunk semmit
    {
        _resultListWidget->addItems(_itemStringList); // mindent megjelenítünk
    }
    else
    {
        foreach(QString item, _itemStringList) // bejáró ciklust használunk
            if (item.contains(_queryLineEdit->text())) // az elemeket egyenként leválogatjuk és ha tartalmazza a megadott szöveget
                _resultListWidget->addItem(item); // akkor felvesszük a listára
    }
}

void FilteredListWidget::loadFile()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Fájl megnyitása", "", "Szöveges fájlok (*.txt)");
        // fájl megnyitó dialógus használata, megadjuk a címét és a szűrési feltételt
    if (!fileName.isNull()) // ha megadtunk valamilyen fájlnevet és OK-val zártuk le az ablakot
        loadItems(fileName);
}

void FilteredListWidget::loadItems(QString fileName)
{
    QFile file(fileName); // logikai fájl létrehozása
    if (file.open(QFile::ReadOnly)) // megnyitás csak olvasásra
    {
        _itemStringList.clear(); // régi elemek törlése

        QTextStream stream(&file); // szövegként olvassuk be a fájl tartalmát
        while (!stream.atEnd()) {  // amíg nem üres
            QString line = stream.readLine();
            _itemStringList << line; // vagy itemStringList.append(line);
        }

        _queryLineEdit->clear(); // töröljük a szövegdoboz tartalmát
        _resultListWidget->clear(); // töröljük a listamegjelenítő tartalmát
        _resultListWidget->addItems(_itemStringList);
    }
    else
        QMessageBox::warning(this, "Hiba!", "A " + fileName + " fájl nem található!");
            // ha nem sikerült megnyitni, elõugró ablakot mutatunk
}
