#ifndef FILTEREDLISTWIDGET_H
#define FILTEREDLISTWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>

class FilteredListWidget : public QWidget
{
    Q_OBJECT
    
public:
    FilteredListWidget(QWidget *parent = 0);
    ~FilteredListWidget();

private slots: // eseménykezelők
    void filterList(); // lista szűrése
    void loadFile(); // fájl megnyitása

private:
    void loadItems(QString fileName); // adatok betöltése fájlból

    QStringList _itemStringList; // szavak listája
    QLabel *_queryLabel; // címke
    QLineEdit *_queryLineEdit; // sorszerkesztő
    QListWidget *_resultListWidget; // listamegjelenítő
    QPushButton *_loadButton; // nyomógomb
    QHBoxLayout *_upperLayout; // vízszintes elrendezés
    QVBoxLayout *_mainLayout; // függõleges elrendezés
};

#endif // FILTEREDLISTWIDGET_H
