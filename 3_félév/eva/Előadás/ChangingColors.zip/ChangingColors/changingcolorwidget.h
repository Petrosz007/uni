#ifndef CHANGINGCOLORWIDGET_H
#define CHANGINGCOLORWIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QTimer>

class ChangingColorWidget : public QWidget
{
    Q_OBJECT
    
public:
    ChangingColorWidget(QWidget *parent = 0);
    ~ChangingColorWidget();

private slots: // eseménykezelők
    void modifyColor(); // színváltoztatás indítása/leállítása
    void timeout(); // időzített eseménykezelő

private:
    QPushButton* _colorButton; // nyomógombok
    QPushButton* _startStopButton;
    QTimer *_timer; // időzítő
};

#endif // CHANGINGCOLORWIDGET_H
