#include "changingcolorwidget.h"

#include <QTime>

ChangingColorWidget::ChangingColorWidget(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle(trUtf8("Változó színű gomb"));
    setFixedSize(270, 300);

    _colorButton = new QPushButton("", this);
    _colorButton->setGeometry(0,0,270,270);
    _colorButton->setEnabled(false); // gomb kikapcsolása
    _startStopButton = new QPushButton(tr("Start"), this);
    _startStopButton->setGeometry(0, 270, 270, 30);

    connect(_startStopButton, SIGNAL(clicked()), this, SLOT(modifyColor()));

    qsrand(QTime::currentTime().msec());
       // véletlenszám generátor inicializálása

    _timer = new QTimer(this); // időzítő
    connect(_timer, SIGNAL(timeout()), this, SLOT(timeout()));
}

ChangingColorWidget::~ChangingColorWidget()
{
    
}

void ChangingColorWidget::timeout() // időzített eseménykezelő
{
    // stílus beállítása véletlenszámok segítségével
    _colorButton->setStyleSheet("QPushButton { background-color: rgb(" +
                               QString::number(qrand() % 256) + "," +
                               QString::number(qrand() % 256) + "," +
                               QString::number(qrand() % 256) + ") }");
}

void ChangingColorWidget::modifyColor()
{
    if (!_timer->isActive()) // ha az időzítő nem fut
    {
        _startStopButton->setText(tr("Stop"));
        _timer->start(1000); // elindítjuk
    }
    else // ha fut
    {
        _startStopButton->setText(tr("Start"));        
        _timer->stop(); // leállítjuk
    }
}

