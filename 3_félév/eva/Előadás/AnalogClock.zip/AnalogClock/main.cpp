#include <QApplication>
#include "analogclockwidget.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    AnalogClockWidget clock;
    clock.show();
    return app.exec();
}
