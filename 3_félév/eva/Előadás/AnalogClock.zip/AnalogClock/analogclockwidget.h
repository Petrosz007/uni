#ifndef ANALOGCLOCKWIDGET_H
#define ANALOGCLOCKWIDGET_H

#include <QWidget>

class AnalogClockWidget : public QWidget
{
    Q_OBJECT
public:
    AnalogClockWidget(QWidget *parent = 0);

protected:
    void paintEvent(QPaintEvent *event); // kifestő esemény
};

#endif
