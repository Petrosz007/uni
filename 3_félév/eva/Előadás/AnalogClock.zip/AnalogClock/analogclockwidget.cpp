#include "analogclockwidget.h"

#include <QTime>
#include <QTimer>
#include <QPainter>

AnalogClockWidget::AnalogClockWidget(QWidget *parent) : QWidget(parent)
//  : QWidget(parent, Qt::FramelessWindowHint) // ha keret nélkül szeretnénk
{
    setWindowTitle(trUtf8("Analóg óra"));
    resize(400, 400);

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    // az időzítő meghívja az update-t, ami a paintEvent-t
    timer->start(1000); // azonnal elindítjuk 1 másodperces késleltetéssel
}

void AnalogClockWidget::paintEvent(QPaintEvent *)
{
    // mutatók geometriája:
    QPoint hourTriangle[3] = { QPoint(7, 8), QPoint(-7, 8), QPoint(0, -40) };
    QPoint minuteTriangle[3] = { QPoint(7, 8), QPoint(-7, 8), QPoint(0, -70) };

    // mutatók és vonások színe:
    QColor hourColor(0, 0, 128); // szín RGB alapjánm
    QColor minuteColor(128, 0, 0, 150); // szín RGB és áttetszőség alapján

    QPainter painter(this); // festő objektum
    painter.setRenderHint(QPainter::Antialiasing); // élsimítást használ
    painter.translate(width() / 2, height() / 2); // transzformációk a rajzolás előtt
    painter.scale(height() / 200.0, height() / 200.0);

    // percjelek:
    painter.setPen(minuteColor);
    for (int j = 0; j < 60; ++j)
    {
        painter.drawLine(92, 0, 96, 0); // vonal kirajzolása
        painter.rotate(6.0); // forgatás 6 fokkal
    }
    // órajelek:
    painter.setPen(hourColor);
    for (int i = 0; i < 12; ++i)
    {
        painter.drawLine(88, 0, 96, 0);
        painter.rotate(30.0);
    }

    QTime time = QTime::currentTime(); // aktuális idõ

    painter.save(); // rajzolási tulajdonságok elmentése
    painter.setPen(Qt::NoPen); // nincs toll
    painter.setBrush(hourColor); // ecset színe
    painter.rotate(30.0 * ((time.hour() + time.minute() / 60.0))); // mutató forgatása
    painter.drawConvexPolygon(hourTriangle, 3); // poligon kirajzolása az adott forgatás mellett
    painter.restore(); // rajzolás visszaállítása

    // ugyanez  percmutatóval:
    painter.save();
    painter.setPen(Qt::NoPen);
    painter.setBrush(minuteColor);
    painter.rotate(6.0 * (time.minute() + time.second() / 60.0));
    painter.drawConvexPolygon(minuteTriangle, 3);
    painter.restore();

    // ugyanez másodpercmutatóval:
    painter.save();
    painter.setPen(QColor(0,0,0));
    painter.setBrush(Qt::NoBrush);
    painter.rotate(6.0 * time.second());
    painter.drawLine(QPoint(0, 10), QPoint(0, -80));
    painter.restore();
}
