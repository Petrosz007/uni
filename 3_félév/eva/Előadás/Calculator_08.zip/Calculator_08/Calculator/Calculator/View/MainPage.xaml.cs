﻿using System;
using ELTE.Calculator.Model;
using Xamarin.Forms;

namespace ELTE.Calculator.View
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }        
    }
}
