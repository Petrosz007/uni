#ifndef GRIDSIZEDIALOG_H
#define GRIDSIZEDIALOG_H

#include <QDialog>
#include <QLabel>
#include <QSpinBox>
#include <QPushButton>

class GridSizeDialog : public QDialog // r�cs m�ret�t be�ll�t� dial�gus
{
    Q_OBJECT
public:
    explicit GridSizeDialog(QWidget *parent = 0);
    int gridSize() { return _spinBox->value(); } // gombok sz�m�nak lek�rdez�se

private:
    QLabel *_label; // c�mke
    QSpinBox *_spinBox; // sz�mbe�ll�t�
    QPushButton *_okButton;
    QPushButton *_cancelButton;
};

#endif // GRIDSIZEDIALOG_H
