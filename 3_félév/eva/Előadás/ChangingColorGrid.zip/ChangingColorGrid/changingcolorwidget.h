#ifndef CHANGINGCOLORWIDGET_H
#define CHANGINGCOLORWIDGET_H

#include <QWidget>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QTimer>
#include "coordinate.h"
#include "gridpushbutton.h"
#include "gridsizedialog.h"

class ChangingColorWidget : public QWidget
{
    Q_OBJECT

public:
    ChangingColorWidget(QWidget *parent = 0);
    ~ChangingColorWidget();

private slots: // eseménykezelők
    void startColorChange(); // időzítő indítása
    void resizeGrid(); // rács méretezése
    void changeColors(); // időzített átszínezés

private:
    GridSizeDialog* _gridSizeDialog; // méretbeállító ablak
    QVector<GridPushButton*> _buttonGrid; // gombrács
    QMap<QTimer*, Coordinate> _timers; // időzítők (koordinátákhoz társítva)
    QPushButton* _sizeButton; // átméretező gomb
    QGridLayout* _gridLayout; // elrendezések
    QVBoxLayout* _vBoxLayout;
};

#endif // CHANGINGCOLORWIDGET_H
