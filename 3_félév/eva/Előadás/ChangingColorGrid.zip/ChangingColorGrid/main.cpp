#include <QApplication>
#include "changingcolorwidget.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ChangingColorWidget w;
    w.show();
    
    return a.exec();
}
