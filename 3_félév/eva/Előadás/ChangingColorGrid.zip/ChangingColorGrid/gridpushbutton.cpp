#include "gridpushbutton.h"

GridPushButton::GridPushButton(Coordinate coordinate, QWidget *parent)
    : _coordinate(coordinate), QPushButton(parent)
{
}
