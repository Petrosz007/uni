#ifndef CROSSHAIRWIDGET_H
#define CROSSHAIRWIDGET_H

#include <QWidget>

class CrosshairWidget : public QWidget
{
    Q_OBJECT
    
public:
    CrosshairWidget(QWidget *parent = 0);
    ~CrosshairWidget();

protected:
    void paintEvent(QPaintEvent *); // festés
    void keyPressEvent(QKeyEvent *); // billentyűzet lenyomása
    void mousePressEvent(QMouseEvent *); // egér lenyomása

private:
    QVector<QPoint> hitPoints; // kattintási pontok
    QTimer* timer; // időzítő
};

#endif // CROSSHAIRWIDGET_H
