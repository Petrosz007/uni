#include <QApplication>
#include "crosshairwidget.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    CrosshairWidget w;
    w.show();
    
    return a.exec();
}
