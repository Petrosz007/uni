﻿using Xamarin.Forms;

namespace ELTE.ExamGenerator.View
{
    public partial class MainPage : TabbedPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
