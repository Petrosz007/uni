﻿using System;
using ELTE.ExamGenerator.Model;
using ELTE.ExamGenerator.View;
using ELTE.ExamGenerator.ViewModel;
using Xamarin.Forms;

namespace ELTE.ExamGenerator
{
    public class App : Application
    {
        public App()
        {
            // model és nézetmodell létrehozása
            IExamGeneratorModel model = new ExamGeneratorModel(10, 0);
            ExamGeneratorViewModel viewModel = new ExamGeneratorViewModel(model);

            MainPage = new MainPage();
            MainPage.BindingContext = viewModel; // nézetmodell befecskendezése
        }
    }
}
