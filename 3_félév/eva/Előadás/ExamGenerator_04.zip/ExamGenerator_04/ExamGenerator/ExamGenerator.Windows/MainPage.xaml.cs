﻿namespace ELTE.ExamGenerator.Windows
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();

            LoadApplication(new ELTE.ExamGenerator.App());
        }
    }
}
