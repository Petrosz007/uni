#include "menu.hpp"

#include <QString>
#include <QVariant>
#include <QSqlError>
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

Menu::Menu()
{
    // paraméteres parancsok legyártása:
    validateQuery.prepare("select user_name, user_password from user where user_name = :name and user_password = :password");
    selectQuery.prepare("select user_name, user_password, full_name, level from user"); // lekérdezés futtatása
    insertQuery.prepare("insert into user values(:userName, :password, :fullName, :level)");
    removeQuery.prepare("delete from user where user_name = :name");
}

void Menu::Run()
{
    if (!validateUser())
    {
        cout << "Az azonosítás sikertelen!" << endl;
        return;
    }

    char choice;
    do {
        cout << "Felhasználók szerkesztése" << endl
             << "-------------------------" << endl
             << "1: Felhasználók listája" << endl
             << "2: Új felhasználó felvitele" << endl
             << "3: Felhasználó törlése" << endl
             << "q: Kilépés" << endl
             << "Választás: ";
        cin >> choice;

        switch (choice)
        {
        case '1':
            ShowAllUsers();
            break;
        case '2':
            ShowCreateUser();
            break;
        case '3':
            ShowRemoveUser();
            break;
        case 'q':
            cout << "Viszlát!" << endl;
            break;
        }
        cout << endl;
    } while (choice != 'q');
}

void Menu::ShowAllUsers()
{
    cout << left << endl;
    cout << setw(22) << "Azonosító" << setw(21) << "Jelszó" << setw(21) << "Név" << setw(20) << "Szint" << endl;
    cout << setw(20) << "---------" << setw(20) << "------" << setw(20) << "---" << setw(20) << "-----" << endl;

    selectQuery.exec(); // lekérdezés futtatása
    while (selectQuery.next()) // amíg van következő sor
    {
        cout << setw(20) << selectQuery.value(0).toString().toStdString()
             << setw(20) << selectQuery.value(1).toString().toStdString()
             << setw(20) << selectQuery.value(2).toString().toStdString()
             << setw(20) << selectQuery.value(3).toInt() << endl;
        // az eredményeket lekérdezzük, majd konvertáljuk
    }
}

void Menu::ShowCreateUser()
{
    cout << endl
         << "Új felhasználó létrehozása" << endl
         << "--------------------------" << endl;

    string userNameString, fullNameString, userPasswordString, levelString;
    int levelInt;
    bool isInt;

    do
    {
        cout << "Azonosító: ";
        getline(cin, userNameString);
    } while (userNameString.length() < 5 && userNameString.length() > 10); // ellenőrizzük, hogy a hossza megfelel-e

    cout << "Név: ";
    getline(cin, fullNameString);
    cout << "Jelszó: ";
    getline(cin, userPasswordString);

    do
    {
        cout << "Szint: ";
        getline(cin, levelString);
        levelInt = QString::fromStdString(levelString).toInt(&isInt); // ellenőrizzük, hogy számot adott-e meg
    } while (!isInt);

    // a paraméteres utasítást felparaméterezzük
    insertQuery.bindValue(":userName", QString::fromStdString(userNameString));
    insertQuery.bindValue(":fullName", QString::fromStdString(fullNameString));
    insertQuery.bindValue(":password", QString::fromStdString(userPasswordString));
    insertQuery.bindValue(":level", QString::fromStdString(levelString));

    if (!insertQuery.exec()) // ha sikertelen a végrehajtás
        cout << "Hiba történt: " << insertQuery.lastError().text().toStdString() << endl; // kiiratjuk a hibaüzenetet
}

void Menu::ShowRemoveUser()
{
    cout << endl
         << "Felhasználó törlése" << endl
         << "-------------------" << endl;

    string userNameString;
    cout << "Azonosító: ";
    getline(cin, userNameString);

    removeQuery.bindValue(":name", QString::fromStdString(userNameString));
    removeQuery.exec();
}

bool Menu::validateUser()
{
    string userName, userPassword; // adatok bekérése
    cout << "Felhasználónév: ";
    getline(cin, userName);
    cout << "Jelszó: ";
    getline(cin, userPassword);

    validateQuery.bindValue(":name", QString::fromStdString(userName));
    validateQuery.bindValue(":password", QString::fromStdString(userPassword));
    // paraméterek behelyettesítése

    validateQuery.exec();
    // lekérdezés futtatása

    return validateQuery.next();
    // ha van eredmény, akkor sikeres a lekérdezés
}
