#ifndef MENU_HPP
#define MENU_HPP

#include <QSqlQuery>

class Menu // menü osztálya
{
public:
    Menu();
    void Run(); // menü futtatása
private:
    void ShowAllUsers();
    void ShowCreateUser();
    void ShowRemoveUser();
    bool validateUser();

    QSqlQuery validateQuery; // ellenőrzés parancs
    QSqlQuery insertQuery; // beszúrás parancs
    QSqlQuery selectQuery; // lekérdezés parancs
    QSqlQuery removeQuery; // törlés parancs
};

#endif // MENU_HPP
