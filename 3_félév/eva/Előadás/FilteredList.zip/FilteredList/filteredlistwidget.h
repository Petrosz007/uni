#ifndef FILTEREDLISTWIDGET_H
#define FILTEREDLISTWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>

class FilteredListWidget : public QWidget
{
    Q_OBJECT    
public:
    FilteredListWidget(QWidget *parent = nullptr);
    ~FilteredListWidget();

private slots: // eseménykezelők
    void filterList(); // lista szűrése

private:
    void loadItems(QString fileName); // adatok betöltése fájlból

    QStringList _itemStringList; // szavak listája
    QLabel *_queryLabel; // címke
    QLineEdit *_queryLineEdit; // sorszerkesztő
    QListWidget *_resultListWidget; // listamegjelenítő
};

#endif // FILTEREDLISTWIDGET_H
