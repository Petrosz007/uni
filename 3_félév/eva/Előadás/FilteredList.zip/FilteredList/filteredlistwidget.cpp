#include "filteredlistwidget.h"

#include <QFile>
#include <QTextStream>
#include <QMessageBox>

FilteredListWidget::FilteredListWidget(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(256, 232); // méret beállítása
    setWindowTitle("Szűrés listára"); // ablakcím beállítása

    _queryLabel = new QLabel("Szűrés:", this);
    _queryLabel->setGeometry(2, 2, 50, 20);
    _queryLineEdit = new QLineEdit(this);
    _queryLineEdit->setGeometry(54, 2, 200, 25);

    _resultListWidget = new QListWidget(this);
    _resultListWidget->setGeometry(2, 30, 252, 200);

    connect(_queryLineEdit, SIGNAL(textChanged(QString)), this, SLOT(filterList()));
        // társítás saját eseménykezelőhöz

    loadItems("fruit.txt");
}

FilteredListWidget::~FilteredListWidget()
{
}

void FilteredListWidget::filterList()
{
    _resultListWidget->clear(); // kitöröljük a korábbi tartalmat

    if (_queryLineEdit->text().isNull()) // ha nem írtunk semmit
    {
        _resultListWidget->addItems(_itemStringList); // mindent megjelenítünk
    }
    else
    {
        for (int i = 0; i < _itemStringList.size(); i++)
            if (_itemStringList[i].contains(_queryLineEdit->text())) // ha tartalmazza a megadott szöveget
                _resultListWidget->addItem(_itemStringList[i]); // akkor felvesszük a listára
    }
}

void FilteredListWidget::loadItems(QString fileName)
{
    QFile file(fileName); // logikai fájl létrehozása
    if (file.open(QFile::ReadOnly)) // megnyitás csak olvasásra
    {
        _itemStringList.clear(); // régi elemek törlése

        QTextStream stream(&file); // szövegként olvassuk be a fájl tartalmát

        while (!stream.atEnd())  // amíg nem érünk a végére, vagy !line.isNull() is lehetne
        {
             QString line = stream.readLine();
             _itemStringList << line; // vagy itemStringList.append(line);
        }

        _queryLineEdit->clear(); // töröljük a szövegdoboz tartalmát
        _resultListWidget->clear(); // töröljük a listamegjelenítő tartalmát
        _resultListWidget->addItems(_itemStringList); // elemek felvétele a megjelenítőre
    }
    else
        QMessageBox::warning(this, "Hiba!", "A " + fileName + " fájl nem található!");
            // ha nem sikerült megnyitni, előugró ablakot mutatunk
}
