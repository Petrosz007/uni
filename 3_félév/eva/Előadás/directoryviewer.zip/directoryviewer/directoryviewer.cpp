#include <QtGui>
#include <QDirModel>
#include <QTreeView>
#include <QHeaderView>
#include <QPushButton>
#include <QLayout>
#include <QInputDialog>
#include <QMessageBox>

#include "directoryviewer.h"

DirectoryViewer::DirectoryViewer(QWidget *parent)
    : QDialog(parent)
{
    _model = new QDirModel;
    _model->setReadOnly(false);
    _model->setSorting(QDir::DirsFirst | QDir::IgnoreCase | QDir::Name);

    _treeView = new QTreeView;
    _treeView->setModel(_model);
    _treeView->header()->setStretchLastSection(true);
    _treeView->header()->setSortIndicator(0, Qt::AscendingOrder);
    _treeView->header()->setSortIndicatorShown(true);
    _treeView->header()->setSectionsClickable(true);

    QModelIndex index = _model->index(QDir::currentPath());
    _treeView->expand(index);
    _treeView->scrollTo(index);
    _treeView->resizeColumnToContents(0);

    _mkdirButton = new QPushButton(tr("&Create Directory..."));
    _removeButton = new QPushButton(tr("&Remove"));
    _quitButton = new QPushButton(tr("&Quit"));

    connect(_mkdirButton, SIGNAL(clicked()),this, SLOT(createDirectory()));
    connect(_removeButton, SIGNAL(clicked()), this, SLOT(remove()));
    connect(_quitButton, SIGNAL(clicked()), this, SLOT(accept()));

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addWidget(_mkdirButton);
    buttonLayout->addWidget(_removeButton);
    buttonLayout->addStretch();
    buttonLayout->addWidget(_quitButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(_treeView);
    mainLayout->addLayout(buttonLayout);
    setLayout(mainLayout);

    setWindowTitle(tr("Directory Viewer"));
}

void DirectoryViewer::createDirectory()
{
    QModelIndex index = _treeView->currentIndex();
    if (!index.isValid())
        return;

    QString dirName = QInputDialog::getText(this, tr("Create Directory"), tr("Directory name"));
    if (!dirName.isEmpty()) {
        if (!_model->mkdir(index, dirName).isValid())
            QMessageBox::information(this, tr("Create Directory"),
                    tr("Failed to create the directory"));
    }
}

void DirectoryViewer::remove()
{
    QModelIndex index = _treeView->currentIndex();
    if (!index.isValid())
        return;

    bool ok;
    if (_model->fileInfo(index).isDir()) {
        ok = _model->rmdir(index);
    } else {
        ok = _model->remove(index);
    }
    if (!ok)
        QMessageBox::information(this, tr("Remove"),
                tr("Failed to remove %1").arg(_model->fileName(index)));
}
