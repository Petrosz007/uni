#ifndef DIRECTORYVIEWER_H
#define DIRECTORYVIEWER_H

#include <QDialog>

class QDirModel;
class QPushButton;
class QTreeView;

class DirectoryViewer : public QDialog
{
    Q_OBJECT

public:
    DirectoryViewer(QWidget *parent = 0);

private slots:
    void createDirectory();
    void remove();

private:
    QTreeView *_treeView;
    QDirModel *_model;
    QPushButton *_mkdirButton;
    QPushButton *_removeButton;
    QPushButton *_quitButton;
};

#endif
