﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace ELTE.Windows.StudentsList.ViewModel
{
    /// <summary>
    /// Hallgatók megjelenítő típusa.
    /// </summary>
    public class StudentsViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// Adatbázis kontextus.
        /// </summary>
        private StudentsContext _context;

        /// <summary>
        /// Új, még nem perzisztált hallgatók.
        /// </summary>
        private List<Student> _newStudents;

        /// <summary>
        /// Hallgatók gyűjteményének lekérdezése.
        /// </summary>
        public ObservableCollection<Student> Students { get; private set; }

        /// <summary>
        /// Új hallgató lekérdezése.
        /// </summary>
        public Student NewStudent { get; private set; }

        /// <summary>
        /// Új hallgató felvétel parancsának lekérdezése.
        /// </summary>
        public StudentAddCommand AddCommand { get; private set; }

        /// <summary>
        /// Hallgatók mentése parancsának lekérdezése.
        /// </summary>
        public StudentSaveCommand SaveCommand { get; private set; }

        /// <summary>
        /// Tulajdonságváltozás eseménye.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        public StudentsViewModel(StudentsContext context)
        {
            _context = context;
            _newStudents = new List<Student>();

            Students = new ObservableCollection<Student>();
            NewStudent = new Student();
            AddCommand = new StudentAddCommand(this); // parancs létrehozása
            SaveCommand = new StudentSaveCommand(this);

            // Hallgatók lekérdezése az adatbázisból.
            foreach (Student student in _context.Students)
            {
                Students.Add(student);
            }

            // Amennyiben üres volt az adatbázis, vegyünk fel néhány minta hallgatót.
            if (Students.Count == 0)
            {
                Students.Add(new Student {Id = 1, LastName = "Kis", FirstName = "János", StudentCode = "KIJSAAI"});
                Students.Add(new Student {Id = 2, LastName = "Nagy", FirstName = "Ferenc", StudentCode = "NAFSAAI"});
                Students.Add(new Student {Id = 3, LastName = "Huba", FirstName = "Hugó", StudentCode = "HUHSAAI"});
                Students.Add(new Student {Id = 4, LastName = "Gem", FirstName = "Géza", StudentCode = "GEGSAAI"});
                // a tulajdonságokat objektuminicializálás segítségével hozzuk létre

                _newStudents.AddRange(Students);
            }
        }

        /// <summary>
        /// Új hallgató felvétele.
        /// </summary>
        public void AddNewStudent()
        {
            Students.Add(NewStudent);
            _newStudents.Add(NewStudent);

            NewStudent = new Student();
            OnPropertyChanged("NewStudent");
        }

        /// <summary>
        /// Hallgatók adatbázisba mentése.
        /// </summary>
        public void PersistStudents()
        {
            _context.Students.AddRange(_newStudents);
            _context.SaveChanges();

            _newStudents.Clear();
        }

        /// <summary>
        /// Tulajdonságváltozás esemény kiváltása.
        /// </summary>
        /// <param name="property">A tulajdonság neve.</param>
        private void OnPropertyChanged(String property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
