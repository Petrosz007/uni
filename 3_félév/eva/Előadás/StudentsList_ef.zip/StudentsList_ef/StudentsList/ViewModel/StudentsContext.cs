﻿using System;
using System.Data.Entity;

namespace ELTE.Windows.StudentsList.ViewModel
{
    /// <summary>
    /// Adatbázis kontextus típusa.
    /// </summary>
    /// <seealso cref="System.Data.Entity.DbContext" />
    public class StudentsContext : DbContext
    {
        public StudentsContext(String connection)
            : base(connection)
        {
        }
        
        // Hallgatók
        public DbSet<Student> Students { get; set; }
    }
}
