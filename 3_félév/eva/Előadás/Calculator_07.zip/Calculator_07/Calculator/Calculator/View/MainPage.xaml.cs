﻿using System;
using ELTE.Calculator.Model;
using Xamarin.Forms;

namespace ELTE.Calculator.View
{
    public partial class MainPage : ContentPage
    {
        private CalculatorModel _model; // számológép modell

        public MainPage()
        {
            InitializeComponent();

            _model = new CalculatorModel();
            _model.CalculationPerformed += new EventHandler<CalculatorEventArgs>(Model_CalculationPerformed); // modell eseményének társítása
            _entryNumber.Text = _model.Result.ToString();

            _entryNumber.Focus();
        }
        
        /// <summary>
        /// Számítás végrehajtásának eseménykezelője.
        /// </summary>
        private void Model_CalculationPerformed(object sender, CalculatorEventArgs e)
        {
            // az eseményargumentokat használjuk fel
            _entryNumber.Text = e.Result.ToString();

            if (e.CalculationString != String.Empty)
                _labelHistory.Text = e.CalculationString + Environment.NewLine + _labelHistory.Text;
        }
        /// <summary>
        /// Gomb kattintásának eseménykezelője.
        /// </summary>
        private void Button_Click(object sender, EventArgs e)
        {
            switch ((sender as Button).Text as String)
            // megvizsgáljuk, milyen az eseményt kiváltó gomb felirata, így eldönthetjük, melyik gombot nyomták le
            {
                case "+":
                    PerformCalculation(Operation.Add);
                    break;
                case "-":
                    PerformCalculation(Operation.Subtract);
                    break;
                case "×":
                    PerformCalculation(Operation.Multiply);
                    break;
                case "÷":
                    PerformCalculation(Operation.Divide);
                    break;
                default:
                    PerformCalculation(Operation.None);
                    break;
            }
        }
        /// <summary>
        /// Számítás végrehajtása
        /// </summary>
        private async void PerformCalculation(Operation operation)
        {
            try
            {
                _model.Calculate(Double.Parse(_entryNumber.Text), operation); // művelet végrehajtása
            }
            catch (OverflowException)
            {
                await DisplayAlert("Calculator error", "Your input has to many digits!", "Correct");
            }
            catch (FormatException)
            {
                await DisplayAlert("Calculator error", "Your input is not a real number!", "Correct");
            }
            catch (NullReferenceException)
            {
                await DisplayAlert("Calculator error", "No number in input!", "Correct");
            }
            finally
            {
                _entryNumber.Focus(); // visszaadjuk a vezérlést a szövegdoboznak
            }
        }

    }
}
