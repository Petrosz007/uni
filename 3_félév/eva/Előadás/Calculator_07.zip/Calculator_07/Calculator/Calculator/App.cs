﻿using ELTE.Calculator.View;
using Xamarin.Forms;

namespace ELTE.Calculator
{
    public class App : Application
    {
        public App()
        {
            MainPage = new MainPage();
        }
    }
}
