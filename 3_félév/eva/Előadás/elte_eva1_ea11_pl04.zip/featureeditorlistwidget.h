#ifndef FEATUREEDITORLISTWIDGET_H
#define FEATUREEDITORLISTWIDGET_H

#include <QListWidget>

class FeatureEditorListWidget : public QListWidget // egyedi szerkesztő a jellemzőkre, egy speciális listamegjelenítő
{
    Q_OBJECT
public:
    FeatureEditorListWidget(QWidget *parent = 0);
    void setFeatures(int features); // jellemzők szerkesztése
    int getFeatures() const; // jellemzők lekérdezése
    QString getFeaturesString() const; // jellemzők szöveges alakja
};

#endif // FEATUREEDITORLISTWIDGET_H
