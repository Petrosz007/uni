#include <QApplication>
#include <QDebug>
#include <QSqlDatabase>
#include "buildingeditordialog.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setDatabaseName("apartments");
    db.setUserName("root");
    db.setPassword("root");

    if (db.open()) // kapcsolat megnyitása
    {
        db.close();

        BuildingEditorDialog *w = new BuildingEditorDialog();
        w->show();
    }
    else
    {
        qDebug() << QString::fromUtf8("Nem sikerült kapcsolódni az adatbázis-szerverhez!") << endl;
    }

    return a.exec();
}
