#include "featureeditorlistwidget.h"
#include <qmath.h>

FeatureEditorListWidget::FeatureEditorListWidget(QWidget *parent) :
    QListWidget(parent)
{
    addItem(trUtf8("főút")); // elemek feltöltése
    addItem(trUtf8("parti szolgálat"));
    addItem(trUtf8("úszómedence"));
    addItem(trUtf8("kert"));
    addItem(trUtf8("saját parkoló"));
}

void FeatureEditorListWidget::setFeatures(int features)
{
    for (int i = 0; i < 5; i++)
    {
        if (((features >> i) % 2 == 1)) // kijelölés beállítása a bit értéke szerint
            item(i)->setCheckState(Qt::Checked);
        else
            item(i)->setCheckState(Qt::Unchecked);
    }
}

int FeatureEditorListWidget::getFeatures() const
{
    int featuresInt = 0;
    for (int i = 0; i < 5; i++)
        if (item(i)->checkState() == Qt::Checked)
            featuresInt += pow(2, i); // megfelelő hatványos a beíráshoz

    return featuresInt;
}

QString FeatureEditorListWidget::getFeaturesString() const
{
    QString result;
    for (int i = 0; i < 5; i++)
        if (item(i)->checkState() == Qt::Checked)
            result += item(i)->data(Qt::DisplayRole).toString() + ", ";

    if (result.size() > 0)
        return result.left(result.size() - 2);
    else
        return "nincsenek";
}
