#include "cityeditordialog.h"
#include <QMessageBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QSqlQuery>

CityEditorDialog::CityEditorDialog(QWidget *parent) :
    QDialog(parent)
{
    setupUi();
}

CityEditorDialog::~CityEditorDialog()
{
}

void CityEditorDialog::setModel(QSqlTableModel* model)
{
    _model = model; // egyszerűen továbbadjuk a modellt
    _listView->setModel(_model); // és társítjuk a nézethez
    _listView->setModelColumn(1); // a lista megjelenítő az egyes oszlopot jeleníti meg
}

void CityEditorDialog::addButton_Clicked()
{
    _model->insertRow(_model->rowCount()); // az utolsó sor után szúrunk be
    QModelIndex newIndex = _model->index(_model->rowCount() - 1, 1); // az egyes oszlopra állítjuk a kijelölést
    _listView->setCurrentIndex(newIndex);
    _listView->edit(newIndex);
}

void CityEditorDialog::removeButton_Clicked()
{
    QModelIndex index = _listView->currentIndex();

    if (index.isValid())
    {
        QSqlQuery query; // lekérdezzük, hogy tartozik-e hozzá sor az épületekben
        query.exec("select * from building where city_id = " + _model->data(_model->index(index.row(), 0)).toString());
        if (query.next())
            QMessageBox::warning(this, trUtf8("Az elem nem tötölhető!"), trUtf8("Van apartman a megadott városban, ezért nem törölhető!"));
        else
        {
            _model->removeRow(index.row());
            _listView->setCurrentIndex(_model->index(index.row()-1, 1));
        }
    }
    else
    {
        QMessageBox::warning(this, trUtf8("Nincs kijelölés!"), trUtf8("Kérem jelölje ki előbb a törlendő sort!"));
    }
}

void CityEditorDialog::setupUi()
{
    _addButton = new QPushButton(trUtf8("&Beszúrás"));
    _removeButton = new QPushButton(trUtf8("&Törlés"));

    _buttonBox = new QDialogButtonBox(Qt::Vertical);
    _buttonBox->addButton(_addButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_removeButton, QDialogButtonBox::ActionRole);

    connect(_addButton, SIGNAL(clicked()), this, SLOT(addButton_Clicked()));
    connect(_removeButton, SIGNAL(clicked()), this, SLOT(removeButton_Clicked()));

    _listView = new QListView(this); // az adatokat egy listamegjelenítőben helyezzük el

    QHBoxLayout* mainLayout = new QHBoxLayout;
    mainLayout->addWidget(_listView);
    mainLayout->addWidget(_buttonBox);
    setLayout(mainLayout);

    setFixedSize(400, 200);
    setWindowTitle(trUtf8("Városok szerkesztése"));
}
