﻿namespace ELTE.Calculator.Windows
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();

            LoadApplication(new ELTE.Calculator.App());
        }
    }
}
