﻿namespace ELTE.Calculator.View
{
    public partial class MainPage : OrientationAwareContentPage
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
    }
}
