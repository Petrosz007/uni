﻿using System.Windows;
using ELTE.Windows.StudentsList.ViewModel;
using ELTE.Windows.StudentsList.View;

namespace ELTE.Windows.StudentsList
{
    public partial class App : Application
    {
        public App()
        {
            Startup += new StartupEventHandler(App_Startup);
        }

        private void App_Startup(object sender, StartupEventArgs e)
        {
            MainWindow window = new MainWindow(); // nézet létrehozása

            StudentsViewModel viewModel = new StudentsViewModel(); // nézetmodell létrehozása

            window.DataContext = viewModel; // nézetmodell és modell társítása

            window.Show();
        }
    }
}
