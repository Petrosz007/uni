﻿using System.Windows;
using ELTE.Windows.StudentsList.ViewModel;

namespace ELTE.Windows.StudentsList.View
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
