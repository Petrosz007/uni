﻿using System.Windows;

namespace ELTE.Windows.SmileyTransformations
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
