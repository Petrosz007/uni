#ifndef CROSSHAIRWIDGET_H
#define CROSSHAIRWIDGET_H

#include <QWidget>

class CrosshairWidget : public QWidget
{
    Q_OBJECT
    
public:
    CrosshairWidget(QWidget *parent = 0);
    ~CrosshairWidget();

protected:
    void paintEvent(QPaintEvent *); // rajzolás eseménykezelője
    void mousePressEvent(QMouseEvent *event); // egér lenyomása
    void mouseMoveEvent(QMouseEvent *event); // egér mozgatása
    void keyPressEvent(QKeyEvent *event); // billentyű lenyomása

private:
    QVector<QPoint> hitPoints; // kattintási pontok
    QPoint mouseLocation; // egér aktuális pozíciója
};

#endif // CROSSHAIRWIDGET_H
