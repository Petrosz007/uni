#include "crosshairwidget.h"

#include <QPainter>
#include <QMouseEvent>

CrosshairWidget::CrosshairWidget(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle(trUtf8("Céllövölde"));
    setMouseTracking(true); // állandóan követjük az egeret
}

CrosshairWidget::~CrosshairWidget()
{
}

void CrosshairWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    QPen dashDotRedPen(QBrush(QColor(255, 0, 0)), 2, Qt::DashDotLine); // pontozott-szaggatott vonalú piros toll
    QPen solidRedPen(QBrush(QColor(255, 0, 0)), 3); // sima piros toll
    QBrush greenBrush(QColor(0, 255, 0), Qt::Dense1Pattern); // pöttyös zöld ecset

    painter.fillRect(0, 0, width(), height(), greenBrush); // háttér kitöltése

    painter.setPen(QPen(Qt::black, 4)); // fekete, 4 vastag toll beállítása
    foreach(QPoint point, hitPoints) // kirajzoljuk a pontokat
    {
        painter.drawLine(point.x() - 10, point.y() - 10, point.x() + 10, point.y() + 10);
        painter.drawLine(point.x() - 10, point.y() + 10, point.x() + 10, point.y() - 10);
    }
    painter.setPen(dashDotRedPen); // előre megadott toll beállítása
    painter.setBrush(Qt::NoBrush); // ecset eltávolítása
    painter.drawLine(0, mouseLocation.y(), width(), mouseLocation.y()); // vonalak kirajzolása
    painter.drawLine(mouseLocation.x(), 0, mouseLocation.x(), height());

    painter.setPen(solidRedPen); // toll beállítása
    painter.drawEllipse(mouseLocation.x() - 30, mouseLocation.y() - 30, 60, 60); // kör kirajzolása
}

void CrosshairWidget::mousePressEvent(QMouseEvent *event) // egér lenyomása
{
    hitPoints.append(event->pos()); // új pont felvétele
    update(); // képernyő frissítése
}

void CrosshairWidget::keyPressEvent(QKeyEvent *event) // billentyű lenyomása
{
    if (event->key() == Qt::Key_Space) // ha szóközt ütöttünk
    {
       hitPoints.append(mouseLocation); // új pont felvétele az aktuális egérpozícióba
       update(); // képernyő frissítése
    }
}

void CrosshairWidget::mouseMoveEvent(QMouseEvent *event) // egér mozgatása
{
    mouseLocation = event->pos();
    update();
}
