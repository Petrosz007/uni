#include <QApplication>
#include <QHeaderView>
#include <QTableView>

#include "citymodel.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QStringList cities;
    cities << "Békéscsaba" << "Budapest" << "Debrecen" << "Eger"
           << "Győr" << "Kaposvár" << "Kecskemét" << "Miskolc"
           << "Nyíregyháza" << "Pécs" << "Salgótarján" << "Szeged"
           << "Szekszárd" << "Székesfehérvár" << "Szolnok" << "Szombathely"
           << "Tatabánya" << "Veszprém" << "Zalaegerszeg";

    CityModel cityModel;
    cityModel.setCities(cities);

    QTableView tableView;
    tableView.setModel(&cityModel);
    tableView.setAlternatingRowColors(true);
    tableView.setWindowTitle(QObject::tr("Városok"));
    tableView.show();

    return app.exec();
}
