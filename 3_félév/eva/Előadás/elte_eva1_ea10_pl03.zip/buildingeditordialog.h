#ifndef BUILDINGEDITORDIALOG_H
#define BUILDINGEDITORDIALOG_H

#include <QDialog>
#include <QTableView>
#include <QDialogButtonBox>
#include <QSqlRelationalTableModel>

class BuildingEditorDialog : public QDialog
{
    Q_OBJECT
public:
    BuildingEditorDialog(QWidget *parent = 0);
    ~BuildingEditorDialog();

private slots:
    void addButton_Clicked();
    void removeButton_Clicked();
    void submitButton_Clicked();

private:
    void setupModel();
    void setupUi();

    QTableView* _tableView;
    QSqlRelationalTableModel* _model;
    QDialogButtonBox* _buttonBox;
    QPushButton* _addButton;
    QPushButton* _removeButton;
    QPushButton* _submitButton;
    QPushButton* _revertButton;
};

#endif // BUILDINGEDITORDIALOG_H
