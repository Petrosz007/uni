#include <QApplication>
#include <QMessageBox>
#include <QSqlDatabase>
#include "buildingeditordialog.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setDatabaseName("apartments");
    db.setUserName("root");
    db.setPassword("root");

    if (db.open())
    {
        db.close();

        BuildingEditorDialog *w = new BuildingEditorDialog();
        w->show();
    }
    else
    {
        QMessageBox::critical(0, QObject::trUtf8("Hiba!"), QObject::trUtf8("Nem sikerült kapcsolódni az adatbázis-szerverhez."));
    }

    return a.exec();
}
