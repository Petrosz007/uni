#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QSqlError>
#include <QSqlRelationalDelegate>
#include "buildingeditordialog.h"

BuildingEditorDialog::BuildingEditorDialog(QWidget *parent) :
        QDialog(parent)
{
    setupModel();
    setupUi();

    setFixedSize(800, 300);
    setWindowTitle(trUtf8("Épületek szerkesztése"));
}

BuildingEditorDialog::~BuildingEditorDialog()
{
    delete _model;
}

void BuildingEditorDialog::addButton_Clicked()
{
    int row;
    if (_tableView->currentIndex().isValid())  // lekérdezzük az aktuális kijelölés indexét, ha érvényes az index
    {
        row = _tableView->currentIndex().row(); // sor beszúrása az aktuális helyre
    }
    else // ha nincs érvényes kijelölés
    {
        row = _model->rowCount(); // sor beszúrása a végére
    }

    _model->insertRow(row);
    QModelIndex newIndex = _model->index(row, 0); // az újonnan beszúrt sor indexe
    _tableView->setCurrentIndex(newIndex); // beállítjuk a táblakijelölést az indexre
    _tableView->edit(newIndex); // szerkesztés alá helyezzük az elemet
}

void BuildingEditorDialog::removeButton_Clicked()
{
    QModelIndex index = _tableView->currentIndex(); // lekérdezzük az aktuális kijelölés indexét

    if (index.isValid()) { // ha érvényes az index
        _model->removeRow(index.row()); // töröljük a kijelölt sort
        _tableView->setCurrentIndex(_model->index(index.row()-1, 0)); // beállítjuk a táblakijelölést az előző sorra
    }
    else // ha nincs érvényes kijelölés
    {
        QMessageBox::warning(this, trUtf8("Nincs kijelölés!"), trUtf8("Kérem jelölje ki előbb a törlendő sort!"));
    }
}

void BuildingEditorDialog::submitButton_Clicked()
{
    _model->database().transaction(); // átváltunk tranzakciós üzemmódba

    if (_model->submitAll()) { // végrehajtjuk a módosításokat, amennyiben sikerül
        _model->database().commit(); // véglegesítünk
    } else {
        _model->database().rollback(); // különben visszavonunk
        QMessageBox::warning(this, trUtf8("Hiba történt a mentéskor!"), trUtf8("Az adatbázis a kvetkező hibát jelezte: %1").arg(_model->lastError().text()));
    }
}

void BuildingEditorDialog::setupModel()
{
    _model = new QSqlRelationalTableModel(this);
    _model->setTable("building");
    _model->setSort(1, Qt::AscendingOrder);
    _model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _model->setHeaderData(0, Qt::Horizontal, trUtf8("Azonosító"));
    _model->setHeaderData(1, Qt::Horizontal, trUtf8("Név"));
    _model->setHeaderData(2, Qt::Horizontal, trUtf8("Város"));
    _model->setHeaderData(3, Qt::Horizontal, trUtf8("Utca"));
    _model->setHeaderData(4, Qt::Horizontal, trUtf8("Tenger távolság"));
    _model->setHeaderData(5, Qt::Horizontal, trUtf8("Tengerpart"));
    _model->setHeaderData(6, Qt::Horizontal, trUtf8("Jellemzők"));
    _model->setHeaderData(7, Qt::Horizontal, trUtf8("Megjegyzés"));
    _model->setRelation(2, QSqlRelation("city", "id", "name")); // reláció beállítása egy oszlophoz
    _model->select();
}

void BuildingEditorDialog::setupUi()
{
    _addButton = new QPushButton(trUtf8("&Beszúrás"));
    _removeButton = new QPushButton(trUtf8("&Törlés"));
    _submitButton = new QPushButton(trUtf8("&Mentés"));
    _revertButton = new QPushButton(trUtf8("&Visszavonás"));

    _buttonBox = new QDialogButtonBox(Qt::Horizontal);
    _buttonBox->addButton(_addButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_removeButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_submitButton, QDialogButtonBox::ActionRole);
    _buttonBox->addButton(_revertButton, QDialogButtonBox::ActionRole);

    connect(_addButton, SIGNAL(clicked()), this, SLOT(addButton_Clicked()));
    connect(_removeButton, SIGNAL(clicked()), this, SLOT(removeButton_Clicked()));
    connect(_submitButton, SIGNAL(clicked()), this, SLOT(submitButton_Clicked()));
    connect(_revertButton, SIGNAL(clicked()), _model, SLOT(revertAll())); // visszavonás a modell segítségével

    _tableView = new QTableView(this);
    _tableView->setModel(_model); // modell hozzákapcsolása a megjelenítőhöz
    _tableView->setSelectionBehavior(QAbstractItemView::SelectItems); // kijelölés módja
    _tableView->resizeColumnsToContents(); // oszlopok automatikus méretezése
    _tableView->setItemDelegate(new QSqlRelationalDelegate()); // megjelenítés módjának definiálása

    QVBoxLayout* mainLayout = new QVBoxLayout;
    mainLayout->addWidget(_tableView);
    mainLayout->addWidget(_buttonBox);
    setLayout(mainLayout);
}
