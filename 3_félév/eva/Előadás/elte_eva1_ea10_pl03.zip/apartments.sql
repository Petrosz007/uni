DROP DATABASE IF EXISTS apartments;
CREATE DATABASE apartments;
USE apartments;

CREATE TABLE city(
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(40)
);

CREATE TABLE building (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(30),
    city_id INTEGER NOT NULL,
    street VARCHAR(30) NOT NULL,
    sea_distance INTEGER,
    shore_id INTEGER,
    features INTEGER,
    comment VARCHAR(100),
    CONSTRAINT buldingtocity 
        FOREIGN KEY (city_id) 
        REFERENCES city (id)
);

CREATE TABLE apartment (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    building_id INTEGER NOT NULL,
    number VARCHAR(20),
    floor INTEGER,
    room INTEGER,
    bed INTEGER,
    spare_bed INTEGER,
    turnday INTEGER,
    features INTEGER,
    renovation INTEGER,
    comment VARCHAR(50),
    CONSTRAINT appartementtobuilding 
        FOREIGN KEY (building_id) 
        REFERENCES building (id)
);

CREATE TABLE season(
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(40),
    start_date Date,
    end_date Date
);

CREATE TABLE price(
    apartment_id INTEGER AUTO_INCREMENT,
    season_id INTEGER,
    price INTEGER, 
    PRIMARY KEY(apartment_id,season_id)
);

insert into city(name) values('Cavallino');
insert into city(name) values('Ca\' di Valle');

insert into building(name, city_id, street, sea_distance, shore_id, features, comment) values ("EuroAppartments", 2, "via Fausta", 80, 2, 8, NULL);
insert into building(name, city_id, street, sea_distance, shore_id, features, comment) values ("Villini Laurin", 1, "via Europa", 100, 2, 5, NULL);
insert into building(name, city_id, street, sea_distance, shore_id, features, comment) values ("Bella Rosa", 2, "corso Italia", 20, 1, NULL, NULL);

insert into apartment(building_id, number, floor, room, bed, spare_bed, turnday, features, renovation, comment) values (1, 1, 0, 1, 4, 0, 1, 0, 0, "");
insert into apartment(building_id, number, floor, room, bed, spare_bed, turnday, features, renovation, comment) values (2, 101, 0, 1, 2, 0, 1, 0, 1, "");
insert into apartment(building_id, number, floor, room, bed, spare_bed, turnday, features, renovation, comment) values (2, 102, 0, 2, 2, 1, 1, 0, 1, "");
insert into apartment(building_id, number, floor, room, bed, spare_bed, turnday, features, renovation, comment) values (2, 103, 1, 1, 3, 0, 7, 0, 0, "");
insert into apartment(building_id, number, floor, room, bed, spare_bed, turnday, features, renovation, comment) values (2, 104, 1, 2, 3, 0, 7, 0, 0, "");
insert into apartment(building_id, number, floor, room, bed, spare_bed, turnday, features, renovation, comment) values (3, 201, 0, 1, 2, 1, 1, 0, 1, "");
insert into apartment(building_id, number, floor, room, bed, spare_bed, turnday, features, renovation, comment) values (3, 202, 0, 2, 2, 0, 2, 0, 1, "");

insert into price(apartment_id, season_id, price) values(1, 1, 50);
insert into price(apartment_id, season_id, price) values(1, 2, 80);
insert into price(apartment_id, season_id, price) values(1, 3, 100);
insert into price(apartment_id, season_id, price) values(2, 1, 60);
insert into price(apartment_id, season_id, price) values(2, 2, 80);
insert into price(apartment_id, season_id, price) values(3, 1, 180);
insert into price(apartment_id, season_id, price) values(3, 2, 200);
insert into price(apartment_id, season_id, price) values(4, 1, 180);
insert into price(apartment_id, season_id, price) values(4, 2, 210);
insert into price(apartment_id, season_id, price) values(4, 3, 250);
insert into price(apartment_id, season_id, price) values(5, 1, 60);
insert into price(apartment_id, season_id, price) values(6, 1, 80);
insert into price(apartment_id, season_id, price) values(7, 1, 100);
