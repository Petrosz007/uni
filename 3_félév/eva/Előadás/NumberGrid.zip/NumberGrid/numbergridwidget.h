#ifndef NUMBERGRIDWIDGET_H
#define NUMBERGRIDWIDGET_H

#include <QWidget>
#include <QLCDNumber>
#include <QGridLayout>
#include <QVBoxLayout>

class NumberGridWidget : public QWidget
{
    Q_OBJECT
    
public:
    NumberGridWidget(QWidget *parent = 0);
    ~NumberGridWidget();

private slots:
    void setNumber(); // szám megjelenítése az LCD kijelzőn

private:
    QLCDNumber *_lcdNumber;
    QGridLayout* _gridLayout;
    QVBoxLayout *_vBoxLayout;
};

#endif // NUMBERGRIDWIDGET_H
