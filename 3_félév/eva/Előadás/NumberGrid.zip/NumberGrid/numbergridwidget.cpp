#include "numbergridwidget.h"

#include <QPushButton>

NumberGridWidget::NumberGridWidget(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle(trUtf8("Számrács"));
    setFixedSize(400,400);

    _lcdNumber = new QLCDNumber();

    _gridLayout = new QGridLayout(); // egy rácsszerű elrendezés a gomboknak
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 10; ++j){
            QPushButton* button = new QPushButton(QString::number(i * 10 + j + 1), this); // gomb létrehozása
            _gridLayout->addWidget(button, i, j); // gomb felvétele az elrendezésre
            QObject::connect(button, SIGNAL(clicked()), this, SLOT(setNumber())); // eseménykezelő kapcsolat
        }
    }

    _vBoxLayout = new QVBoxLayout(); // függőleges elhelyezés
    _vBoxLayout->addWidget(_lcdNumber);
    _vBoxLayout->addLayout(_gridLayout);

    setLayout(_vBoxLayout);
}

NumberGridWidget::~NumberGridWidget()
{
}

void NumberGridWidget::setNumber()
{
    QObject* senderObject = sender(); // küldő objektum lekérdezése
    QPushButton* senderButton = qobject_cast<QPushButton*>(senderObject);
    // a küldő tí­pusát castolnunk kell, hogy lekérdezhessük a text tulajdonságát

    if (senderButton->text() != "X")
        _lcdNumber->display(senderButton->text());

    senderButton->setText("X");
    // a gombra beállí­tunk egy X feliratot
}

