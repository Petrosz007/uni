#ifndef FLOWCHARTSYMBOLPICKER_H
#define FLOWCHARTSYMBOLPICKER_H

#include <QDialog>
#include <QMap>

class QIcon;
class QListWidget;
class QPushButton;

class FlowChartSymbolPicker : public QDialog
{
    Q_OBJECT

public:
    FlowChartSymbolPicker(const QMap<int, QString> &symbolMap,
                          QWidget *parent = nullptr);

    int selectedId() const { return _id; }
    void done(int result);

private:
    QIcon iconForSymbol(const QString &symbolName);

    QListWidget *_listWidget;
    QPushButton *_okButton;
    QPushButton *_cancelButton;
    int _id;
};

#endif
