#include <QtGui>
#include <QListWidget>
#include <QListWidgetItem>
#include <QPushButton>
#include <QLayout>

#include "flowchartsymbolpicker.h"

FlowChartSymbolPicker::FlowChartSymbolPicker(
        const QMap<int, QString> &symbolMap, QWidget *parent)
    : QDialog(parent)
{
    _id = -1;

    _listWidget = new QListWidget;
    _listWidget->setIconSize(QSize(60, 60));

    QMapIterator<int, QString> i(symbolMap);
    while (i.hasNext()) {
        i.next();
        QListWidgetItem *item = new QListWidgetItem(i.value(), _listWidget);
        item->setIcon(iconForSymbol(i.value()));
        item->setData(Qt::UserRole, i.key());
    }

    _okButton = new QPushButton(tr("OK"));
    _okButton->setDefault(true);

    _cancelButton = new QPushButton(tr("Cancel"));

    connect(_okButton, SIGNAL(clicked()), this, SLOT(accept()));
    connect(_cancelButton, SIGNAL(clicked()), this, SLOT(reject()));

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch();
    buttonLayout->addWidget(_okButton);
    buttonLayout->addWidget(_cancelButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(_listWidget);
    mainLayout->addLayout(buttonLayout);
    setLayout(mainLayout);

    setWindowTitle(tr("Flowchart Symbol Picker"));
}

void FlowChartSymbolPicker::done(int result)
{
    _id = -1;
    if (result == QDialog::Accepted) {
        QListWidgetItem *item = _listWidget->currentItem();
        if (item)
            _id = item->data(Qt::UserRole).toInt();
    }
    QDialog::done(result);
}

QIcon FlowChartSymbolPicker::iconForSymbol(const QString &symbolName)
{
    QString fileName = ":/images/" + symbolName.toLower();
    fileName.replace(' ', '-');
    return QIcon(fileName);
}
