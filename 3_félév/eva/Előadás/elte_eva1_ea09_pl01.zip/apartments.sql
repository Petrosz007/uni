DROP DATABASE IF EXISTS apartments;
CREATE DATABASE apartments;
USE apartments;

CREATE TABLE user(
    user_name VARCHAR(10) PRIMARY KEY,
    user_password VARCHAR(40) NOT NULL,
    full_name VARCHAR(40) NOT NULL,
    level INTEGER NOT NULL
);
    
insert into user(user_name, user_password, full_name, level) values('root', 'root', 'adminisztrátor', 0);
insert into user(user_name, user_password, full_name, level) values('roberto', 'roberto', 'Roberto', 1);
