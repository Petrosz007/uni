#include "menu.hpp"

#include <QString>
#include <QVariant>
#include <QSqlQuery>
#include <QSqlError>

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

void Menu::run()
{
    if (!validateUser())
    {
        cout << "Az azonosítás sikertelen!" << endl;
        return;
    }

    char choice;
    do {
        cout << "Felhasználók szerkesztése" << endl
             << "-------------------------" << endl
             << "1: Felhasználók listája" << endl
             << "2: Új felhasználó felvitele" << endl
             << "3: Felhasználó törlése" << endl
             << "q: Kilépés" << endl
             << "Választás: ";
        cin >> choice;

        switch (choice)
        {
        case '1':
            showAllUsers();
            break;
        case '2':
            showCreateUser();
            break;
        case '3':
            showRemoveUser();
            break;
        case 'q':
            cout << "Viszlát!" << endl;
            break;
        }
        cout << endl;
    } while (choice != 'q');
}

void Menu::showAllUsers()
{
    cout << left << endl;
    cout << setw(22) << "Azonosító" << setw(21) << "Jelszó" << setw(21) << "Név" << setw(20) << "Szint" << endl;
    cout << setw(20) << "---------" << setw(20) << "------" << setw(20) << "---" << setw(20) << "-----" << endl;

    QSqlQuery selectQuery;
    selectQuery.exec("select user_name, user_password, full_name, level from user"); // lekérdezés futtatása
    while (selectQuery.next()) // amíg van következő sor
    {
        cout << setw(20) << selectQuery.value(0).toString().toStdString()
             << setw(20) << selectQuery.value(1).toString().toStdString()
             << setw(20) << selectQuery.value(2).toString().toStdString()
             << setw(20) << selectQuery.value(3).toInt() << endl;
        // az eredményeket lekérdezzük, majd konvertáljuk
    }
}

void Menu::showCreateUser()
{
    cout << endl
         << "Új felhasználó létrehozása" << endl
         << "--------------------------" << endl;

    string userNameString, fullNameString, userPasswordString, levelString;
    int levelInt;
    bool isInt;

    do
    {
        cout << "Azonosító: ";
        getline(cin, userNameString);
    } while (userNameString.length() < 5 && userNameString.length() > 10); // ellenőrizzük, hogy a hossza megfelel-e

    cout << "Név: ";
    getline(cin, fullNameString);
    cout << "Jelszó: ";
    getline(cin, userPasswordString);

    do
    {
        cout << "Szint: ";
        cin >> levelString;
        levelInt = QString::fromStdString(levelString).toInt(&isInt); // ellenőrizzük, hogy számot adott-e meg
    } while (!isInt);

    QSqlQuery insertQuery;
    insertQuery.exec("insert into user values(" + QString::fromStdString(userNameString) +
                     ", " + QString::fromStdString(fullNameString) + ", " + QString::fromStdString(userPasswordString) +
                     ", " + QString::fromStdString(levelString) + ")");

    if (!insertQuery.exec()) // ha sikertelen a végrehajtás
        cout << "Hiba történt: " << insertQuery.lastError().text().toStdString() << endl; // kiiratjuk a hibaüzenetet
}

void Menu::showRemoveUser()
{
    cout << endl
         << "Felhasználó törlése" << endl
         << "-------------------" << endl;

    string userNameString;
    cout << "Azonosító: ";
    getline(cin, userNameString);

    QSqlQuery removeQuery;
    removeQuery.exec("delete from user where user_name = '" + QString::fromStdString(userNameString) + "'");
}

bool Menu::validateUser()
{
    string userName, userPassword; // adatok bekérése
    cout << "Felhasználónév: ";
    getline(cin, userName);
    cout << "Jelszó: ";
    getline(cin, userPassword);

    QSqlQuery selectQuery;
    selectQuery.exec("select user_name, user_password from user where user_name = '" +
                     QString::fromStdString(userName) +
                     "' and user_password = '" +
                     QString::fromStdString(userPassword) +
                     "'");
    // lekérdezés futtatása
    return selectQuery.next();
    // ha van eredmény, akkor sikeres a lekérdezés
}
