#ifndef MENU_HPP
#define MENU_HPP

class Menu // menü osztálya
{
public:
    Menu(){} // menü létrehozása
    void run(); // menü futtatása
private:
    void showAllUsers();
    void showCreateUser();
    void showRemoveUser();
    bool validateUser(); // felhasználó azonosítása
};

#endif // MENU_HPP
