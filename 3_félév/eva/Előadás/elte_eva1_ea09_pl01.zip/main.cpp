#include <QCoreApplication>
#include <QSqlDatabase>
#include <iostream>
using namespace std;

#include "menu.hpp"


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL"); // adatbázis-kapcsolat létrehozása
    db.setHostName("localhost");
    db.setDatabaseName("apartments");
    db.setUserName("root");
    db.setPassword("root");

    if (db.open()) // kapcsolat megnyitása
    { // sikeres kapcsolódás
        cout << "Kapcsolatban az adatbázissal." << endl;

        Menu m;
        m.run(); // menü futtatása
        db.close(); // kapcsolat bezárása
    }
    else // sikertelen kapcsolódás
    {
        cout << "Nem sikerült kapcsolódni az adatbázis-szerverhez." << endl;
    }
    return 0;
}
