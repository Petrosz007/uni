﻿using System;

namespace FileExplorer
{
    public class DirectoryExpandedEventArgs : EventArgs
    {
        public string ExpandedDir { get; set; }

        public string SubDirPath { get; set; }

        public string SubDirName { get; set; }

        public DirectoryExpandedEventArgs(string expandedDir, string subDirPath, string subDirName)
        {
            this.ExpandedDir = expandedDir;
            this.SubDirPath = subDirPath;
            this.SubDirName = subDirName;
        }
    }
}
