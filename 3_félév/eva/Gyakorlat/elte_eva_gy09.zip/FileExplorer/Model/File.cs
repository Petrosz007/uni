﻿using System;

namespace FileExplorer
{
    public class File
    {
        public string Name { get; set; }

        public long Size { get; set; }

        public DateTime CreationTime { get; set; }

        public File(string name, long size, DateTime creationTime)
        {
            this.Name = name;
            this.Size = size;
            this.CreationTime = creationTime;
        }
    }
}
