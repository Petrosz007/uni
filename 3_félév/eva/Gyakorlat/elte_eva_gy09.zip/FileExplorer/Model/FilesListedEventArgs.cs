﻿using System;
using System.Collections.Generic;

namespace FileExplorer
{
    public class FilesListedEventArgs : EventArgs
    {
        public List<File> Files { get; set; }

        public FilesListedEventArgs(List<File> files)
        {
            this.Files = files;
        }
    }
}
