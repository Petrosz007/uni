﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace FileExplorer
{
    public class FileExplorerModel
    {
        private readonly Dictionary<string, DirectoryInfo> listedDirectories;

        private readonly List<FileInfo> listedFiles;

        public FileExplorerModel()
        {
            this.listedDirectories = new Dictionary<string, DirectoryInfo>();
            this.listedFiles = new List<FileInfo>();
        }

        public event EventHandler<DirectoryExpandedEventArgs> DirectoryExpanded;

        public event EventHandler<FilesListedEventArgs> FilesListed;

        public void ListDrives()
        {
            var drives = DriveInfo.GetDrives();
            foreach (var drive in drives)
            {
                var rootPath = drive.RootDirectory.FullName;
                this.listedDirectories.Add(rootPath, drive.RootDirectory);
                this.OnDirectoryExpanded("/", rootPath, drive.RootDirectory.Name);
            }
        }

        public void ExpandDir(string fullPath)
        {
            var dir = this.listedDirectories[fullPath];
            var subdirs = dir.GetDirectories();

            foreach (var subdir in subdirs)
            {
                if (!this.listedDirectories.ContainsKey(subdir.FullName))
                {
                    this.listedDirectories.Add(subdir.FullName, subdir);
                }
                this.OnDirectoryExpanded(fullPath, subdir.FullName, subdir.Name);
            }
        }

        public void ListFiles(string fullPath)
        {
            var dir = this.listedDirectories[fullPath];

            var files = dir.GetFiles();
            var addedFilesList = new List<File>();

            foreach (var file in files)
            {
                this.listedFiles.Add(file);

                var name = file.Name;
                var size = file.Length;
                var time = file.CreationTime;

                addedFilesList.Add(new File(name, size, time));
            }

            this.OnFilesListed(addedFilesList);
        }

        public void Execute(string name)
        {
            var fileInfo = this.listedFiles.Find(f => f.Name == name);
            var path = fileInfo.FullName;
            Process.Start(path);
        }

        private void OnDirectoryExpanded(string expandedDir, string subDirPath, string subDirName)
        {
            if (this.DirectoryExpanded != null)
            {
                this.DirectoryExpanded(this, new DirectoryExpandedEventArgs(expandedDir, subDirPath, subDirName));
            }
        }

        private void OnFilesListed(List<File> files)
        {
            if (this.FilesListed != null)
            {
                this.FilesListed(this, new FilesListedEventArgs(files));
            }
        }
    }
}
