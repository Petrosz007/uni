﻿using System;
using System.Windows.Forms;
using System.IO;

namespace FileExplorer
{
    public partial class FileExplorerForm : Form
    {
        private readonly FileExplorerModel model;

        public FileExplorerForm()
        {
            InitializeComponent();

            this.model = new FileExplorerModel();
            this.model.DirectoryExpanded += this.DirectoryExpanded;
            this.model.FilesListed += this.FilesListed;
        }
        
        private void FileExplorerForm_Load(object sender, EventArgs e)
        {
            dirTreeView.Nodes.Clear();
            this.model.ListDrives();
        }

        private void dirTreeView_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            try
            {
                e.Node.Nodes.Clear();   // clear placeholder
                this.model.ExpandDir(e.Node.Name);
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Nincs jogosultságod!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (IOException)
            {
                MessageBox.Show("Nem várt hiba!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dirTreeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                this.fileListView.Items.Clear();
                this.model.ListFiles(e.Node.Name);
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Nincs jogosultságod!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (IOException)
            {
                MessageBox.Show("Nem várt hiba!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fileListView_DoubleClick(object sender, EventArgs e)
        {
            var item = this.fileListView.SelectedItems[0];
            this.model.Execute(item.Text);
        }

        private void DirectoryExpanded(object sender, DirectoryExpandedEventArgs e)
        {
            var expandedNode = this.dirTreeView.Nodes.Find(e.ExpandedDir, true);

            TreeNode subNode;
            if (expandedNode.Length == 0) // root
            {
                subNode = this.dirTreeView.Nodes.Add(e.SubDirPath, e.SubDirName);
            }
            else
            {
                subNode = expandedNode[0].Nodes.Add(e.SubDirPath, e.SubDirName);
            }
            subNode.Nodes.Add(string.Empty);    // placeholder
        }

        private void FilesListed(object sender, FilesListedEventArgs e)
        {
            foreach (var file in e.Files)
            {
                var item = new ListViewItem(new string[] { file.Name, this.FileSizeToString(file.Size), file.CreationTime.ToString() });
                this.fileListView.Items.Add(item);
            }
            
            this.fileListView.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
        }

        private string FileSizeToString(long bytes)
        {
            string[] suffixes = { "B", "KB", "MB", "GB", "TB" };
            const int Unit = 1024;

            var counter = 0;
            double size = bytes;
            while (Math.Round((double)size / Unit) >= 1)
            {
                size = size / Unit;
                counter++;
            }
            return $"{size:n1} {suffixes[counter]}";
        }
    }
}
