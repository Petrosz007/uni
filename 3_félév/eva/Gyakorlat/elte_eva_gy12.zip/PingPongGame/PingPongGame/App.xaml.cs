﻿using System.Windows;

namespace ELTE.Windows.PingPong
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
