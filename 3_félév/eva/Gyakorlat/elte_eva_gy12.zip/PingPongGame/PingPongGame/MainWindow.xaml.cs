﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace ELTE.Windows.PingPong
{
    public partial class MainWindow : Window
    {
        private readonly Thickness ballStartPosition; // pozíciók, pontosabban határoló téglalapok
        private Thickness ballCurrentPosition;
        private Thickness ballNextPosition;
        private readonly Thickness padStartPosition;
        private Thickness padCurrentPosition;

        private ThicknessAnimation ballAnimation; // animációk
        private ThicknessAnimation padAnimation;

        private DateTime startTime; // játék kezdőideje
        private Boolean isStarted; // tart-e a játék
        private Double speedFactor; // játék sebessége

        public MainWindow()
        {
            InitializeComponent();

            ballStartPosition = ellipseBall.Margin;
            ballCurrentPosition = ballStartPosition;
            ballNextPosition = new Thickness();
            padStartPosition = rectanglePad.Margin;
            padCurrentPosition = padStartPosition;
            isStarted = false;

            KeyDown += new KeyEventHandler(Navigate);
            ellipseBall.LayoutUpdated += new EventHandler(BallLayoutUpdated);
        }

        private void NewGame(Object sender, RoutedEventArgs e)
        {
            StartGame();
        }

        private void Exit(Object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Navigate(Object sender, KeyEventArgs e)
        {
            padCurrentPosition = rectanglePad.Margin;
            Int32 movement = 0;
            if (e.Key == Key.Left) // megállapítjuk, milyen gombot ütött le
                if (rectanglePad.Margin.Left > 0) // csak akkor mozgunk, ha még van hova
                    movement = -100;
            if (e.Key == Key.Right)
                if (rectanglePad.Margin.Right > 0)
                    movement = 100;

            AnimatePad(movement);
        }

        private void BallLayoutUpdated(Object sender, EventArgs e)
        {
            if (isStarted) // csak akkor, ha tart a játék
            {
                ballCurrentPosition = ellipseBall.Margin;

                // ütőnek ütközik balról:
                if (ellipseBall.Margin.Top + ellipseBall.Height >= rectanglePad.Margin.Top &&
                    ellipseBall.Margin.Left >= rectanglePad.Margin.Left - 30 &&
                    ellipseBall.Margin.Left <= rectanglePad.Margin.Left + 30)
                {
                    speedFactor *= 1.05; // sebességnövelés
                    ballNextPosition.Top = 0; // új cél a tető
                    ballNextPosition.Left = ballCurrentPosition.Left - 200; // és balra haladás
                    AnimateBall();
                }
                // ütőnek ütközik jobbról: 
                else if (ellipseBall.Margin.Top + ellipseBall.Height >= rectanglePad.Margin.Top &&
                         ellipseBall.Margin.Left >= rectanglePad.Margin.Left + 30 &&
                         ellipseBall.Margin.Left <= rectanglePad.Margin.Left + 110)
                {
                    speedFactor *= 1.05;
                    ballNextPosition.Top = 0;
                    ballNextPosition.Left = ballCurrentPosition.Left + 200;
                    AnimateBall();
                }
                else if (ellipseBall.Margin.Top <= 25) // tetőnek ütközik
                {
                    ballNextPosition.Top = Height;
                    AnimateBall();
                }
                else if (ellipseBall.Margin.Left <= 0) // bal falnak ütközik
                {
                    ballNextPosition.Left = Width;
                    AnimateBall();
                }
                else if (ellipseBall.Margin.Left >= Width - 40) // jobb falnak ütközik
                {
                    ballNextPosition.Left = 0;
                    AnimateBall();
                }
                else if (ellipseBall.Margin.Top > rectanglePad.Margin.Top) // túlment az ütőn
                {
                    MessageBox.Show(
                        "Összesen " + (DateTime.Now - startTime).Seconds + " másodpercig tartott a játék.",
                        "Vége a játéknak!");
                    StopGame();
                }
            }
        }

        /// <summary>
        /// Játék indítása.
        /// </summary>
        private void StartGame()
        {
            var random = new Random();

            startTime = DateTime.Now;
            ballCurrentPosition = ballStartPosition; // a labdát a kezdőpontra helyezzük
            ballNextPosition.Left = random.Next(-1, 1) * Width; // a kezdőirány véletlenszerű
            ballNextPosition.Top = random.Next(-1, 1) * Height;
            speedFactor = 1;
            isStarted = true;

            AnimateBall();
        }

        /// <summary>
        /// Játék leállítása.
        /// </summary>
        private void StopGame()
        {
            isStarted = false;
        }

        /// <summary>
        /// Labda animálása.
        /// </summary>
        private void AnimateBall()
        {
            ballAnimation = new ThicknessAnimation // új animáció létrehozása
            {
                From = ballCurrentPosition, // a labda jelenlegi pozíciójából
                To = ballNextPosition, // az új pozícióba
                Duration = new Duration(TimeSpan.FromMilliseconds(5)), // animáció ideje
                SpeedRatio =
                    speedFactor /
                    BallTravelDistance() // az animáció sebessége függ a játék sebességétől, illetve a labda utazási távolságától
            };

            ellipseBall.BeginAnimation(Ellipse.MarginProperty, ballAnimation, HandoffBehavior.SnapshotAndReplace);
            // animáció lejátszása az adott objektumon és tulajdonságon
            // ha már fut animáció, akkor annak leállítása
        }

        /// <summary>
        /// Ütő animálása.
        /// </summary>
        /// <param name="x">A mozgatás mértéke pontban.</param>
        private void AnimatePad(Int32 x)
        {
            padAnimation = new ThicknessAnimation
            {
                From = padCurrentPosition,
                To =
                    new Thickness(rectanglePad.Margin.Left + x, 
                        rectanglePad.Margin.Top, 
                        rectanglePad.Margin.Right - x,
                        rectanglePad.Margin.Bottom),
                Duration = new Duration(TimeSpan.FromMilliseconds(100))
            };

            rectanglePad.BeginAnimation(Rectangle.MarginProperty, padAnimation, HandoffBehavior.SnapshotAndReplace);
        }

        /// <summary>
        /// Labda utazási távolságának kiszámítása.
        /// </summary>
        /// <returns></returns>
        private Double BallTravelDistance()
        {
            return Math.Sqrt(Math.Pow(ballNextPosition.Left - ballCurrentPosition.Left, 2) +
                             Math.Pow(ballNextPosition.Top - ballCurrentPosition.Top, 2));
        }
    }
}
