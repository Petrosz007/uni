#include "digiclock.h"
#include "ui_digiclock.h"


DigiClock::DigiClock(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::DigiClock)
{
    ui->setupUi(this);
    QTimer *timer = new QTimer(this); //időzítő létrehozása
    connect(timer,SIGNAL(timeout()),this,SLOT(showTime())); //a szignál és az eseménykezelő összekapcsolása
    timer->start(); // az időzítő elindítása
}

DigiClock::~DigiClock()
{
    delete ui;
}

void DigiClock::showTime()
{
    QTime time = QTime::currentTime(); //aktuális idő
    QString text = time.toString("hh:mm"); //sztringgé alakítás
    if ((time.second() % 2) == 0) text[2] = ' '; // villogő elválasztó
    ui->lcdNumber->display(text); // megjelenítés
}
