#ifndef DIGICLOCK_H
#define DIGICLOCK_H

#include <QMainWindow>
#include <QTimer>
#include <QDateTime>

namespace Ui {
class DigiClock;
}

class DigiClock : public QMainWindow
{
    Q_OBJECT

public:
    explicit DigiClock(QWidget *parent = nullptr);
    ~DigiClock();

private:
    Ui::DigiClock *ui;

private slots:
    void showTime();
};

#endif // DIGICLOCK_H
