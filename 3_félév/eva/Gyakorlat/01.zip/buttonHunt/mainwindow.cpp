#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "stdlib.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    srand(time(NULL));
    ui->pushButton->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    int w=ui->pushButton->width();
    int h=ui->pushButton->height();
    int x=ui->centralWidget->width()-w;
    int y=ui->centralWidget->height()-h;
    ui->pushButton->setGeometry(rand()%x,rand()%y,w,h);
    ui->label->setNum(ui->label->text().toInt()+1);
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    int millisec = _time.elapsed();

    QMessageBox msgBox;
    if (millisec>0)
        msgBox.setText("Pushes per seconds: "+QString::number((ui->label->text().toDouble()+1)*1000/millisec,'f',2));
    else
        msgBox.setText("The game has not started yet!");
    msgBox.exec();
}

void MainWindow::on_btnStart_clicked()
{
    ui->btnStart->setVisible(false);
    ui->pushButton->setVisible(true);
    _time.start();

}
