#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
    ui->lcdTokyo->setTimeZone(8);
    ui->lcdBudapest->setTimeZone(0);
    ui->lcdLondon->setTimeZone(1);
    ui->lcdNewZealand->setTimeZone(11);
}

Form::~Form()
{
    delete ui;
}
