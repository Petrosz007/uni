#include "digiclock2.h"

digiClock2::digiClock2(QWidget *parent)
    : QLCDNumber(parent)
{
    QTimer *timer = new QTimer(this); //időzítő létrehozása
    connect(timer,SIGNAL(timeout()),this,SLOT(showTime())); //a szignál és az eseménykezelő összekapcsolása
    timer->start(); // az időzítő elindítása
    setWindowTitle(tr("Digital Clock"));
    resize(150, 60);
}

void digiClock2::showTime()
{
    QTime time = QTime::currentTime(); //aktuális idő
    QString text = time.addSecs(3600*_timeZone).toString("hh:mm"); //sztringgé alakítás
    if ((time.second() % 2) == 0) text[2] = ' '; // villogő elválasztó
    display(text); // megjelenítés
}
