#ifndef DIGICLOCK2_H
#define DIGICLOCK2_H

#include <QLCDNumber>
#include <QTimer>
#include <QDateTime>

class digiClock2 : public QLCDNumber
{
    Q_OBJECT

public:
    digiClock2(QWidget *parent = nullptr);
    void setTimeZone(int timeZone) { _timeZone = timeZone; }

private:
    int _timeZone;

private slots:
    void showTime();
};

#endif // DIGICLOCK2_H
