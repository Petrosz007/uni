﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat2
{
    class Program
    {
        static int[] array;
        static int[,] matrix;

        static void Main(string[] args)
        {
            FillArrayAsReference(out array, "data1.txt");
            DisplayArray(array);
            matrix = FillMatrix(5, 6, "data2.txt");
            DisplayMatrix(matrix);

            Console.ReadKey();
        }

        private static void DisplayMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write("{0,4}", matrix[i, j]); // formázott kiíratás 4 karakter hosszan 
                }

                Console.WriteLine();
            }
        }

        private static void DisplayArray(int[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                Console.Write("{0},", array[i]);
            }

            Console.WriteLine(array[array.Length - 1]);
        }

        private static void FillArrayAsReference(out int[] array, string filename)
        {
            TextReader reader = new StreamReader(filename);
            var line = reader.ReadLine();
            var size = Int32.Parse(line);
            array = new int[size];
            for (int i = 0; i < size; i++)
            {
                line = reader.ReadLine();
                array[i] = Int32.Parse(line);
            }

            reader.Close();
        }

        private static int[,] FillMatrix(int width, int height, string filename)
        {
            var matrix = new int[width, height];
            TextReader reader = new StreamReader(filename);
            string line;
            for (int i = 0; i < width; i++)
            {
                line = reader.ReadLine();
                for (int j = 0; j < height; j++)
                {
                    matrix[i, j] = Int32.Parse(line.Split(',')[j]);
                }
            }

            reader.Close();
            return matrix;
        }
    }
}
