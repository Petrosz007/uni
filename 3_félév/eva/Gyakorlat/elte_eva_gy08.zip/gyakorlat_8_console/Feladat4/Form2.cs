﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Feladat4
{
    public partial class Form2 : Form
    {
        public Product NewProduct { get; private set; }

        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(textBox1.Text)
                && !String.IsNullOrWhiteSpace(textBox2.Text)
                && !String.IsNullOrWhiteSpace(textBox3.Text))
            {
                try
                {
                    NewProduct =
                        new Product
                        {
                            Name = textBox1.Text,
                            Code = Convert.ToInt32(textBox2.Text),
                            Price = Convert.ToDouble(textBox3.Text)
                        };
                    DialogResult = DialogResult.OK;
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Mindegyik mezőnek értéket kell adni", "Hibás kitöltés");
            }
        }
    }
}
