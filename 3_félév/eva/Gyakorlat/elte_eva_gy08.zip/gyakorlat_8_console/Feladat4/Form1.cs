﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Feladat4
{
    public partial class Form1 : Form
    {
        private List<Product> products = new List<Product>();

        public Form1()
        {
            InitializeComponent();
            comboBox1.DisplayMember = "Név";
            
        }
        
        private void FillComboBox()
        {
            comboBox1.Items.Clear();
            foreach (var item in products)
            {
                comboBox1.Items.Add(item);
            }
            comboBox1.SelectedIndex = -1; //nincs kiválasztva egy elem sem
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            Form2 newForm = new Form2();
            //newForm.Show()
            if (newForm.ShowDialog() == DialogResult.OK)
            {
                products.Add(newForm.NewProduct);
            }
            FillComboBox();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = comboBox1.SelectedIndex.ToString();
            textBox2.Text = comboBox1.SelectedItem.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex>-1)
            {
                listBox1.Items.Add(comboBox1.SelectedItem);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double sum;

            //LINQ -s megoldás
            //var prices = from a in listBox1.Items.Cast<Product>()
            //           select a.Price;
            //sum = prices.Sum();

            //LINQ és Lambda kifejezés használata
            sum = listBox1.Items.Cast<Product>().Select(a => a.Price).Sum();

            //Összegzés tétele Felsorolóra
            //sum = 0;
            //foreach (var item in listBox1.Items)
            //{
            //    sum += ((Product)item).Price;
            //}
            textBox3.Text = sum.ToString();
        }
    }
}
