﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Feladat3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                List<int> numbers = ParseNumberList(textBox1.Text);
                if (numbers.Count > 0)
                {
                    int maxValue = numbers.Max();
                    textBox2.Text = maxValue.ToString();
                }
            }
            
        }

        private List<int> ParseNumberList(string text)
        {
            List<int> numberList = new List<int>();
            foreach (var number in text.Split(new char[] {' ',',' }))
            {
                try
                {
                    numberList.Add(Convert.ToInt32(number));
                }
                catch (Exception)
                {

                    MessageBox.Show("Nem egész szám");
                }
               
            }
            return numberList;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                List<int> numbers = ParseNumberList(textBox1.Text);
                if (numbers.Count > 0)
                {
                    double avgValue = numbers.Average();
                    textBox3.Text = avgValue.ToString();
                }
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (var number in textBox1.Text.Split(new char[] { ' ', ',' }))
            {
                try
                {
                    listBox1.Items.Add(Convert.ToInt32(number));
                }
                catch (Exception)
                {

                    MessageBox.Show("Nem egész szám");
                }
            }
        }
    }
}
