﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat1
{
    class Program
    {
        static void Main(string[] args)
        {
            Rational a = new Rational(1, 2);
            Rational b = Rational.Parse("3/2");
            Console.WriteLine("{0} plusz {1} egyenlő {2}", a, b, a + b);
            Console.ReadKey();
        }
    }
}
