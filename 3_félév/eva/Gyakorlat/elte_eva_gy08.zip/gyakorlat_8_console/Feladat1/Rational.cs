﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat1
{
    class Rational
    {
        private int p;
        private int q;

        public int Nominator
        {
            get { return p; }
            set { p = value; }
        }

        public int Denominator
        {
            get { return q; }
            set
            {
                if (value == 0)
                {
                    throw new DivideByZeroException("A nevező nem lehet nulla");
                }

                q = value;
            }
        }

        public Rational()
        {
            p = 0;
            q = 1;
        }

        public Rational(int nom, int denom)
        {
            p = nom;
            if (denom == 0)
            {
                throw new DivideByZeroException("A nevező nem lehet nulla");
            }

            q = denom;
        }

        public override string ToString()
        {
            return p + "/" + q;
        }

        public static Rational operator +(Rational a, Rational b)
        {
            return new Rational
            {
                p = a.p * b.q + b.p * a.q,
                q = a.q * b.q
            };
        }

        public static Rational operator -(Rational a, Rational b)
        {
            return new Rational
            {
                p = a.p * b.q - b.p * a.q,
                q = a.q * b.q
            };
        }

        public static Rational operator *(Rational a, Rational b)
        {
            return new Rational
            {
                p = a.p * b.p,
                q = a.q * b.q
            };
        }

        public static Rational operator /(Rational a, Rational b)
        {
            return new Rational
            {
                p = a.p * b.q,
                q = a.q * b.p
            };
        }

        public static Rational Parse(string number)
        {
            int poz = number.IndexOf('/');
            if (poz == -1)
            {
                return new Rational(Int32.Parse(number), 1);
            }
            else if (poz == 0)
            {
                return new Rational(1, Int32.Parse(number.Substring(1)));
            }
            else if (number.EndsWith("/"))
            {
                return new Rational(Int32.Parse(number.TrimEnd('/')), 1);
            }
            else
            {
                return new Rational(Int32.Parse(number.Split('/')[0]), Int32.Parse(number.Split('/')[1]));
            }
        }
    }
}
