﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PrimeNumberGenerator.Model;

namespace PrimeNumberGeneratorTest
{
    [TestClass]
    public class PrimeGeneratorTest
    {
        private PrimeGenerator generator;

        [TestInitialize]
        public void Initialize()
        {
            generator = new PrimeGenerator();
        }
        
        [TestMethod]
        public void IsPrimeNegativeTest()
        {
            generator.CalculationResult += delegate (object sender, CalcResultEventArgs e)
            {
                Assert.IsFalse(e.IsPrime);
            };

            this.generator.CalculateIsPrime(189999);
            this.generator.CalculateIsPrime(2);
            this.generator.CalculateIsPrime(42);
            this.generator.CalculateIsPrime(98765432);
        }

        [TestMethod]
        public void IsPrimePositiveTest()
        {
            generator.CalculationResult += delegate (object sender, CalcResultEventArgs e)
            {
                Assert.IsTrue(e.IsPrime);
            };

            this.generator.CalculateIsPrime(19);
            this.generator.CalculateIsPrime(30703);
            this.generator.CalculateIsPrime(56207);
        }
    }
}
