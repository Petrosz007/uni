﻿namespace PrimeNumberGenerator.View
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.generateResults = new System.Windows.Forms.ListBox();
            this.generateButton = new System.Windows.Forms.Button();
            this.primesToGenerate = new System.Windows.Forms.NumericUpDown();
            this.isPrimeButton = new System.Windows.Forms.Button();
            this.isPrimeInput = new System.Windows.Forms.NumericUpDown();
            this.isPrimeResult = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.primesToGenerate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.isPrimeInput)).BeginInit();
            this.SuspendLayout();
            // 
            // generateResults
            // 
            this.generateResults.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.generateResults.FormattingEnabled = true;
            this.generateResults.ItemHeight = 16;
            this.generateResults.Location = new System.Drawing.Point(0, 46);
            this.generateResults.Margin = new System.Windows.Forms.Padding(4);
            this.generateResults.Name = "generateResults";
            this.generateResults.Size = new System.Drawing.Size(912, 276);
            this.generateResults.TabIndex = 2;
            // 
            // generateButton
            // 
            this.generateButton.Location = new System.Drawing.Point(108, 6);
            this.generateButton.Margin = new System.Windows.Forms.Padding(4);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(131, 28);
            this.generateButton.TabIndex = 1;
            this.generateButton.Text = "Számol";
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.GenerationStartStop);
            // 
            // primesToGenerate
            // 
            this.primesToGenerate.Location = new System.Drawing.Point(16, 10);
            this.primesToGenerate.Margin = new System.Windows.Forms.Padding(4);
            this.primesToGenerate.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.primesToGenerate.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.primesToGenerate.Name = "primesToGenerate";
            this.primesToGenerate.Size = new System.Drawing.Size(84, 22);
            this.primesToGenerate.TabIndex = 0;
            this.primesToGenerate.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // isPrimeButton
            // 
            this.isPrimeButton.Location = new System.Drawing.Point(649, 10);
            this.isPrimeButton.Margin = new System.Windows.Forms.Padding(4);
            this.isPrimeButton.Name = "isPrimeButton";
            this.isPrimeButton.Size = new System.Drawing.Size(100, 28);
            this.isPrimeButton.TabIndex = 3;
            this.isPrimeButton.Text = "Prím-e";
            this.isPrimeButton.UseVisualStyleBackColor = true;
            this.isPrimeButton.Click += new System.EventHandler(this.isPrimeButton_Click);
            // 
            // isPrimeInput
            // 
            this.isPrimeInput.Location = new System.Drawing.Point(532, 12);
            this.isPrimeInput.Margin = new System.Windows.Forms.Padding(4);
            this.isPrimeInput.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.isPrimeInput.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.isPrimeInput.Name = "isPrimeInput";
            this.isPrimeInput.Size = new System.Drawing.Size(109, 22);
            this.isPrimeInput.TabIndex = 4;
            this.isPrimeInput.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // isPrimeResult
            // 
            this.isPrimeResult.AutoSize = true;
            this.isPrimeResult.Location = new System.Drawing.Point(769, 16);
            this.isPrimeResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.isPrimeResult.Name = "isPrimeResult";
            this.isPrimeResult.Size = new System.Drawing.Size(0, 17);
            this.isPrimeResult.TabIndex = 5;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 322);
            this.Controls.Add(this.isPrimeResult);
            this.Controls.Add(this.isPrimeInput);
            this.Controls.Add(this.isPrimeButton);
            this.Controls.Add(this.primesToGenerate);
            this.Controls.Add(this.generateButton);
            this.Controls.Add(this.generateResults);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Prime Generator";
            ((System.ComponentModel.ISupportInitialize)(this.primesToGenerate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.isPrimeInput)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox generateResults;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.NumericUpDown primesToGenerate;
        private System.Windows.Forms.Button isPrimeButton;
        private System.Windows.Forms.NumericUpDown isPrimeInput;
        private System.Windows.Forms.Label isPrimeResult;
    }
}

