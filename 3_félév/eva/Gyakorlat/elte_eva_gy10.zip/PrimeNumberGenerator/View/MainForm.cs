﻿using System;
using System.Windows.Forms;
using PrimeNumberGenerator.Model;

namespace PrimeNumberGenerator.View
{
    public partial class MainForm : Form
    {
        private PrimeGenerator generator;

        private Boolean isGenerationRunning = false;

        private Boolean isCalculationRunning = false;

        public MainForm()
        {
            InitializeComponent();

            this.generator = new PrimeGenerator();
            this.generator.NewGenResult += this.GotNewGenResult;
            this.generator.GenerationReady += GenerationReady;

            this.generator.CalculationResult += GotCalculationResult;
            this.generator.CalculationReady += CalculationReady;
        }

        private void GenerationStartStop(object sender, EventArgs e)
        {
            if (!this.isGenerationRunning)
            {
                this.generateResults.Items.Clear();
                this.generateButton.Text = "Leállít";
                this.isGenerationRunning = true;

                this.generator.GeneratePrimes(Convert.ToInt32(this.primesToGenerate.Value));
            }
            else
                this.generator.CancelPrimeGenerating();
        }

        private void isPrimeButton_Click(object sender, EventArgs e)
        {
            if (!this.isCalculationRunning)
            {
                this.isPrimeResult.Text = "";
                this.isPrimeButton.Text = "Leállít";
                this.isCalculationRunning = true;

                this.generator.CalculateIsPrime(Convert.ToInt32(this.isPrimeInput.Value));
            }
            else
                this.generator.CancelPrimeCalculation();
        }

        private void GotNewGenResult(object sender, GenResultEventArgs e)
        {
            if (this.generateResults.InvokeRequired)
            {
                BeginInvoke(new EventHandler<GenResultEventArgs>(this.GotNewGenResult), sender, e);
                return;
            }
            // Ezután már szabad a generateResults ListBox-ba beszúrni...
            this.generateResults.Items.Insert(0, e.N + ": " + e.Result);
            this.generateResults.Update();
        }

        private void GenerationReady(object sender, EventArgs e)
        {
            if (this.generateButton.InvokeRequired)
            {
                BeginInvoke(new EventHandler(this.GenerationReady), sender, e);
                return;
            }
            this.generateButton.Text = "Számol";
            this.isGenerationRunning = false;
        }

        private void GotCalculationResult(object sender, CalcResultEventArgs e)
        {
            if (isPrimeResult.InvokeRequired)
            {
                BeginInvoke(new EventHandler<CalcResultEventArgs>(GotCalculationResult), sender, e);
                return;
            }
            isPrimeResult.Text = e.IsPrime ? "Prímszám" : "Nem prímszám";
            isPrimeButton.Text = "Prim-e";
            isCalculationRunning = false;
        }

        private void CalculationReady(object sender, EventArgs e)
        {
            if (this.isPrimeButton.InvokeRequired)
            {
                BeginInvoke(new EventHandler(this.CalculationReady), sender, e);
                return;
            }
            this.isPrimeButton.Text = "Prim-e";
            this.isCalculationRunning = false;
        }
    }
}
