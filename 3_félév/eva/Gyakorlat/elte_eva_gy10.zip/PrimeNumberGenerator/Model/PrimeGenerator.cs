﻿using System;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace PrimeNumberGenerator.Model
{
    public class PrimeGenerator
    {
        public event EventHandler<GenResultEventArgs> NewGenResult;
        public event EventHandler GenerationReady;

        public event EventHandler<CalcResultEventArgs> CalculationResult;
        public event EventHandler CalculationReady;

        private CancellationTokenSource genCancelSource;
        private CancellationToken genCancelToken;

        private CancellationTokenSource calcCancelSource;
        private CancellationToken calcCancelToken;

        private List<Int64> cache = new List<Int64>();

        public void GeneratePrimes(Int32 n)
        {
            this.genCancelSource = new CancellationTokenSource();
            this.genCancelToken = this.genCancelSource.Token;

            var task = new Task(() => Generate(n), this.genCancelToken);
            task.ContinueWith(t => OnGenerationReady());
            task.Start();
        }

        public void CancelPrimeGenerating()
        {
            this.genCancelSource.Cancel();
        }

        public void CalculateIsPrime(Int32 n)
        {
            this.calcCancelSource = new CancellationTokenSource();
            this.calcCancelToken = this.calcCancelSource.Token;

            var task = new Task(() => this.Calculate(n), this.calcCancelToken);
            task.Start();
        }

        private void Calculate(int number)
        {
            if (this.cache.Contains(number))
            {
                OnCalculationResult(number, true);
            }

            var isPrime = IsPrime(number);
            if (!calcCancelToken.IsCancellationRequested)
            {
                OnCalculationResult(number, isPrime);
            }
            this.OnCalculationReady();
        }

        public void CancelPrimeCalculation()
        {
            this.calcCancelSource.Cancel();
        }

        private void Generate(Int32 n)
        {
            Int64 primeCandidate = 1;

            for (var cachedIdx = 0; cachedIdx < Math.Min(this.cache.Count, n); ++cachedIdx)
            {
                primeCandidate = this.cache[cachedIdx];
                this.OnNewGenResult(cachedIdx + 1, primeCandidate);
            }

            var i = this.cache.Count;
            ++primeCandidate;
            while (i < n)
            { 
                if (this.genCancelToken.IsCancellationRequested)
                    break;
                
                if (IsPrime(primeCandidate))
                {
                    this.cache.Add(primeCandidate);
                    ++i;
                    this.OnNewGenResult(i, primeCandidate);
                }
                Thread.Sleep(10); // Szándékos lassítás
                ++primeCandidate;
            }
        }

        private bool IsPrime(Int64 primeCandidate)
        {
            for (var i = 2; i <= Math.Sqrt(primeCandidate); ++i)
            {
                if (calcCancelToken.IsCancellationRequested)
                    break;

                if (primeCandidate % i == 0)
                {
                    return false;
                }
            }
            return true;
        }

        private void OnNewGenResult(Int32 n, Int64 result)
        {
            if (this.NewGenResult != null)
                this.NewGenResult(this, new GenResultEventArgs(n, result));
        }

        private void OnGenerationReady()
        {
            if (this.GenerationReady != null)
                this.GenerationReady(this, EventArgs.Empty);
        }

        private void OnCalculationResult(Int64 number, Boolean isPrime)
        {
            if (this.CalculationResult != null)
                this.CalculationResult(this, new CalcResultEventArgs(number, isPrime));
        }

        private void OnCalculationReady()
        {
            if (this.CalculationReady != null)
                this.CalculationReady(this, EventArgs.Empty);
        }
    }
}
