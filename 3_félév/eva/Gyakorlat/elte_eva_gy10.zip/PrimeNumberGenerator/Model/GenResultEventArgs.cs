﻿using System;
using System.Numerics;

namespace PrimeNumberGenerator.Model
{
    public class GenResultEventArgs : EventArgs
    {
        public Int32 N { get; set; }
        public Int64 Result { get; set; }

        public GenResultEventArgs(int n, Int64 result)
        {
            N = n;
            Result = result;
        }
    }
}
