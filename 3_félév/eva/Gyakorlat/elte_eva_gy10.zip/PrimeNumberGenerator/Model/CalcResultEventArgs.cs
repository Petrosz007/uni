﻿using System;
using System.Numerics;

namespace PrimeNumberGenerator.Model
{
    public class CalcResultEventArgs : EventArgs
    {
        public Int64 Number { get; set; }
        public Boolean IsPrime { get; set; }
        
        public CalcResultEventArgs(Int64 number, Boolean isPrime)
        {
            Number = number;
            IsPrime = isPrime;
        }
    }
}
