﻿using Microsoft.Win32;
using SourceEditor.Models;
using SourceEditor.Persistence;
using SourceEditor.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace SourceEditor
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		private EditorViewModel _viewModel;
		private MainWindow _window;
		private EditorModel _model;
		private FilePersistence _persistence;
		private SaveFileDialog _saveDialog;
		private OpenFileDialog _openDialog;
		
		private void On_Window_Closing(object sender, CancelEventArgs args)
		{
			var allSafe = _viewModel.Tabs.All(x => !x.IsDirty);
			if (!allSafe)
			{
				var msgBox = MessageBox.Show("You will lose all unsaved changes. Sure to proceed?", "Are you sure? -- Source Editor", MessageBoxButton.YesNo, MessageBoxImage.Warning);
				args.Cancel = msgBox == MessageBoxResult.No;
			}
		}

		private async void On_ViewModel_SaveFile(object sender, FileOperationEventArgs args)
		{
			string path = null;
			if (!_model.HasPath(args.Id))
			{
				if (_saveDialog == null)
				{
					_saveDialog = new SaveFileDialog();
					_saveDialog.Title = "Source Editor - Save ";
				}
				if (_saveDialog.ShowDialog() == true)
				{
					path = _saveDialog.FileName;
				}
				else
				{
					return;
				}
			}
			try
			{
				await _model.SaveFile(args.Id, args.Content, path);
			}
			catch (FileOperationException e)
			{
				MessageBox.Show(e.Message, "Source Editor", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private async void On_ViewModel_OpenFile(object sender, EventArgs args)
		{
			if (_openDialog == null)
			{
				_openDialog = new OpenFileDialog();
				_openDialog.Title = "Source Editor - Open";
			}
			if (_openDialog.ShowDialog() == true)
			{
				try
				{
					await _model.OpenFile(_openDialog.FileName);
				}
				catch (FileOperationException e)
				{
					MessageBox.Show(e.Message, "Source Editor", MessageBoxButton.OK, MessageBoxImage.Error);
				}
			}
		}

		private void On_ViewModel_NewFile(object sender, EventArgs args)
		{
			_model.CreateFile();
		}

		private void On_ViewModel_CloseFile(object sender, FileOperationEventArgs args)
		{
			if (!args.IsDirty)
			{
				_model.CloseFile(args.Id);
				return;
			}
			var msg = "The file \"" + args.Name + "\" contains unsaved changes. Are you sure to cloase it?";
			var msgBox = MessageBox.Show(msg, "Are you sure? -- Source Editor", MessageBoxButton.YesNo, MessageBoxImage.Warning);
			if (msgBox == MessageBoxResult.Yes)
			{
				_model.CloseFile(args.Id);
			}
		}

		App()
		{
			Startup += new StartupEventHandler(App_Startup);
		}

		void App_Startup(object sender, StartupEventArgs eventArgs)
		{
			_persistence = new FilePersistence();
			_model = new EditorModel(_persistence);
			_viewModel = new EditorViewModel();
			

			_viewModel.NewFile += On_ViewModel_NewFile;
			_viewModel.OpenFile += On_ViewModel_OpenFile;
			_viewModel.SaveFile += On_ViewModel_SaveFile;
			_viewModel.CloseFile += On_ViewModel_CloseFile;

			_model.FileClosed += _viewModel.On_FileClosed;
			_model.FileOpened += _viewModel.On_FileOpened;
			_model.FileSaved += _viewModel.On_FileSaved;

			_window = new MainWindow
			{
				DataContext = _viewModel
			};

			_window.Closing += On_Window_Closing;

			_window.Show();
		}
	}
}
