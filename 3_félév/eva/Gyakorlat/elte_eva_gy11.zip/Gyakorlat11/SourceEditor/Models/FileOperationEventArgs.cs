﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SourceEditor.Models
{
    public class FileOperationEventArgs: EventArgs
    {
		public Guid Id { get; set; }
		public String Name { get; set; }
		public String Content { get; set; }
		public Boolean IsDirty { get; set; }
    }
}
