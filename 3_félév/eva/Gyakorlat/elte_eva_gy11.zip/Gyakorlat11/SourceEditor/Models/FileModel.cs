﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SourceEditor.Models
{
    public class FileModel
    {
		private readonly Guid _id;

		public Guid Id => _id;
		public String Name { get; set; }
		public String Path { get; set; }
		public String Content { get; set; }

		public FileModel(Guid? id = null) => _id = id.HasValue ? id.Value : Guid.NewGuid();
	}
}
