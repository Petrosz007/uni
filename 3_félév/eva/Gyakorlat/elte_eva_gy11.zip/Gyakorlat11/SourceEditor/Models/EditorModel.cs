﻿using SourceEditor.Persistence;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SourceEditor.Models
{
    public class EditorModel
    {
		private Dictionary<Guid, FileModel> _openFiles;
		private readonly FilePersistence _persistence;

		public Dictionary<Guid, FileModel> OpenFiles => _openFiles;

		public event EventHandler<FileOperationEventArgs> FileOpened;
		public event EventHandler<FileOperationEventArgs> FileSaved;
		public event EventHandler<FileOperationEventArgs> FileClosed;

		public EditorModel(FilePersistence persistence)
		{
			_openFiles = new Dictionary<Guid, FileModel>();
			_persistence = persistence;
		}

		public Boolean HasPath(Guid fileId) => !String.IsNullOrEmpty(_openFiles[fileId].Path);

		public async Task SaveFile(Guid fileId, String content, String path = null)
		{
			var file = _openFiles[fileId];
			file.Path = String.IsNullOrEmpty(path) ? file.Path : path;
			file.Content = content;
			file.Name = Path.GetFileName(file.Path);
			await _persistence.SaveFile(file.Path, file.Content);
			On_FileSaved(file);
		}


		public async Task OpenFile(String path)
		{
			var content = await _persistence.LoadFile(path);
			var file = new FileModel
			{
				Name = Path.GetFileName(path),
				Content = content,
				Path = path
			};
			_openFiles.Add(file.Id, file);
			On_FileOpened(file);
		}

		public void CreateFile()
		{
			var file = new FileModel
			{
				Name = "New File"
			};
			_openFiles.Add(file.Id, file);
			On_FileOpened(file);
		}

		public void CloseFile(Guid fileId)
		{
			_openFiles.Remove(fileId);
			On_FileClosed(fileId);
		}

		private void On_FileClosed(Guid fileId)
		{
			if (FileClosed != null)
			{
				FileClosed(this, new FileOperationEventArgs{ Id = fileId });
			}
		}

		private void On_FileSaved(FileModel file)
		{
			if (FileSaved != null)
			{
				FileSaved(this, new FileOperationEventArgs
				{
					Id = file.Id,
					Content = file.Content,
					Name = file.Name
				});
			}
		}

		private void On_FileOpened(FileModel file)
		{
			if (FileOpened != null)
			{
				FileOpened(this, new FileOperationEventArgs {
					Id = file.Id,
					Content = file.Content,
					Name = file.Name
				});
			}
		}
		
	}
}
