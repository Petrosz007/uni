﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SourceEditor.Persistence
{
    public class FilePersistence
    {
		public async Task<String> LoadFile(String path)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			try
			{
				using (StreamReader reader = new StreamReader(path))
				{
					return await reader.ReadToEndAsync();
				}
			}
			catch (Exception e)
			{
				throw new FileOperationException("Error while reading file.", e);
			}
		}

		public async Task SaveFile(String path, String content)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (content == null)
			{
				throw new ArgumentNullException("content");
			}
			try
			{
				using (StreamWriter writer = new StreamWriter(path))
				{
					await writer.WriteAsync(content);
				}
			}
			catch (Exception e)
			{
				throw new FileOperationException("Error while writing file.", e);
			}
		}
    }
}
