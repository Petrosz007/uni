﻿using SourceEditor.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace SourceEditor.ViewModels
{
	public class EditorViewModel : ViewModelBase
	{
		#region Private variables

		private String _windowTitle = "Source Editor";
		private double _fontSize = 10;
		private Visibility _toolBarVisibility = Visibility.Visible;
		private TabViewModel _activeTab;
		#endregion

		#region Events

		public event EventHandler NewFile;
		public event EventHandler OpenFile;
		public event EventHandler<FileOperationEventArgs> CloseFile;
		public event EventHandler<FileOperationEventArgs> SaveFile;
		#endregion

		#region Comands

		public DelegateCommand NewFileCommand { get; private set; }
		public DelegateCommand OpenFileCommand { get; private set; }
		public DelegateCommand SaveFileCommand { get; private set; }
		public DelegateCommand CloseFileCommand { get; private set; }

		public DelegateCommand ZoomInCommand { get; private set; }
		public DelegateCommand ZoomOutCommand { get; private set; }
		public DelegateCommand ToggleToolbarCommand { get; private set; }
		#endregion

		#region Public properties

		public String WindowTitle
		{
			get => _windowTitle + " - Source Editor";
			set
			{
				_windowTitle = value;
				OnPropertyChanged();
			}
		}

		public Visibility ToolBarVisibility { get => _toolBarVisibility;
			private set {
				_toolBarVisibility = value;
				OnPropertyChanged();
			}
		}

		public double FontSize { get => _fontSize;
			set {
				if (value > 0)
				{
					_fontSize = value;
					foreach(var tab in Tabs)
					{
						tab.FontSize = FontSize;
					}
				}
			}
		}

		public ObservableCollection<TabViewModel> Tabs { get; private set; }

		public TabViewModel ActiveTab { get => _activeTab;
			set
			{
				_activeTab = value;
				WindowTitle = _activeTab != null ? _activeTab.Name : "Empty";
				OnPropertyChanged();
			}
		}
		#endregion

		#region Constructors

		public EditorViewModel()
		{
			Tabs = new ObservableCollection<TabViewModel>();

			NewFileCommand = new DelegateCommand((_) => NewFile?.Invoke(this, EventArgs.Empty));
			OpenFileCommand = new DelegateCommand((_) => OpenFile?.Invoke(this, EventArgs.Empty));
			SaveFileCommand = new DelegateCommand((_) => {
				SaveFile?.Invoke(this, new FileOperationEventArgs {
					Id = ActiveTab.FileId,
					Content = ActiveTab.CurrentText
				});
			}, (_) => {
				if (ActiveTab == null)
				{
					return false;
				}
				return ActiveTab.IsDirty;
			});

			CloseFileCommand = new DelegateCommand(
				(_) => {
					CloseFile?.Invoke(this, new FileOperationEventArgs
					{
						Id = ActiveTab.FileId,
						IsDirty = ActiveTab.IsDirty,
						Name = ActiveTab.Name
					});
					ActiveTab = Tabs.Count > 0 ? Tabs.Last() : null;
				}
			);

			ZoomInCommand = new DelegateCommand(
				(_) => {
					FontSize += 1;
				}
			);
			ZoomOutCommand = new DelegateCommand(
				(_) => {
					FontSize -= 1;
				}
				, (_) => FontSize > 1
			);
			ToggleToolbarCommand = new DelegateCommand(
				(_) => {
					ToolBarVisibility = ToolBarVisibility == Visibility.Collapsed
						? Visibility.Visible : Visibility.Collapsed;
				}
			);
		}
		#endregion
		
		#region Public methods

		public void On_FileOpened(object sender, FileOperationEventArgs args)
		{
			var tab = new TabViewModel();
			tab.FontSize = FontSize;
			tab.On_FileOpened(sender, args);
			Tabs.Add(tab);
			ActiveTab = tab;
		}

		public void On_FileSaved(object sender, FileOperationEventArgs args)
		{
			var tab = Tabs.First(x => x.FileId == args.Id);
			tab.On_FileSaved(sender, args);
		}

		public void On_FileClosed(object sender, FileOperationEventArgs args)
		{
			var tab = Tabs.First(x => x.FileId == args.Id);
			Tabs.Remove(tab);
		}
		#endregion
	}
}
