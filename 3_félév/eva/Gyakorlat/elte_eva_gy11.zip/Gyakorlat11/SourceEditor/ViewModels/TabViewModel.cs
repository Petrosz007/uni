﻿using SourceEditor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace SourceEditor.ViewModels
{
    public class TabViewModel : ViewModelBase
    {
		private String _name = "New File";
		private String _path = null;
		private Boolean _isDirty = false;
		private String _currentText = "";
		private String _lineNumbers = "";
		private double _fontSize = 10;

		public Guid FileId { get; set; }

		public String Name { get => _name;
			set
			{
				_name = value;
				OnPropertyChanged();
			}
		}

		public double FontSize
		{
			get => _fontSize;
			set
			{
				_fontSize = value;
				OnPropertyChanged();
			}
		}

		public string Path { get => _path; set => _path = value; }

		public Boolean IsDirty { get => _isDirty;
			set
			{
				_isDirty = value;
				OnPropertyChanged();
			}
		}

		public String CurrentText
		{
			get => _currentText;
			set
			{
				_currentText = String.IsNullOrEmpty(value)? "": value;
				int lineCount = _currentText.Count(c => c == '\n') + 1;
				var numbers = Enumerable.Range(1, lineCount);
				LineNumbers = String.Join("\n", numbers.Select(x => x.ToString()));
				IsDirty = true;
				OnPropertyChanged();
			}
		}

		public String LineNumbers
		{
			get => _lineNumbers;
			private set
			{
				_lineNumbers = value;
				OnPropertyChanged();
			}
		}
		
		public void On_FileOpened(object sender, FileOperationEventArgs args)
		{
			FileId = args.Id;
			CurrentText = args.Content;
			Name = args.Name;
			IsDirty = false;
		}

		public void On_FileSaved(object sender, FileOperationEventArgs args)
		{
			IsDirty = CurrentText != args.Content;
			Name = args.Name;
		}
		
	}
}
