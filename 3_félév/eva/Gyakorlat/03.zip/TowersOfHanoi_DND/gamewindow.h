#ifndef GAMEWINDOW_H
#define GAMEWINDOW_H

#include <QWidget>
#include "gamemanager.h"

class TowerWidget;
class QSpinBox;

class GameWindow : public QWidget {
  Q_OBJECT

 public:
  GameWindow(QWidget* parent = nullptr);

 private:
  GameManager gameManager;
  QVector<TowerWidget*> towers;

  QSpinBox* diskCountSpinBox;

 public slots:
  void NewGame();
  void GameOver();
};

#endif  // GAMEWINDOW_H
