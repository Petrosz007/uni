#include "gamewindow.h"

#include "diskwidget.h"
#include "towerwidget.h"

#include <QBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QSpinBox>

static const int MinimumDiskCount = 3;
static const int MaximumDiskCount = 10;
static const int DefaultDiskCount = 4;

GameWindow::GameWindow(QWidget* parent) : QWidget(parent) {
  setWindowTitle("Towers of Hanoi");
  setMinimumWidth((DiskWidget::MaxDiskWidth + 20) * GameManager::TowerCount);

  QGridLayout* layout = new QGridLayout(this);

  for (int i = 0; i < GameManager::TowerCount; ++i) {
    layout->setColumnStretch(i, 1);
    TowerWidget* tower = new TowerWidget(&gameManager, i, this);
    layout->addWidget(tower, 0, i);
    towers.push_back(tower);
    connect(&gameManager, SIGNAL(Update()), tower, SLOT(UpdateDisks()));
  }

  connect(&gameManager, SIGNAL(GameOver()), this, SLOT(GameOver()));

  QLabel* diskCountLabel = new QLabel("Number of disks: ");
  layout->addWidget(diskCountLabel, 1, 0);

  diskCountSpinBox = new QSpinBox();
  diskCountSpinBox->setRange(MinimumDiskCount, MaximumDiskCount);
  diskCountSpinBox->setValue(DefaultDiskCount);
  layout->addWidget(diskCountSpinBox, 1, 1);

  QPushButton* newGameButton = new QPushButton("New Game");
  connect(newGameButton, SIGNAL(clicked()), this, SLOT(NewGame()));
  layout->addWidget(newGameButton, 1, 2);

  gameManager.StartGame(DefaultDiskCount);
}

void GameWindow::NewGame() {
  gameManager.StartGame(diskCountSpinBox->value());
}

void GameWindow::GameOver() {
  QMessageBox::information(this, "Game over!",
                           QString("Congratulations! You won!"));
}
