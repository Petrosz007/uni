#include "diskwidget.h"

#include <QDrag>
#include <QMimeData>

DiskWidget::DiskWidget(int diskSize, int totalDiskCount, QWidget* parent)
    : QWidget(parent) {
  setFixedSize(MaxDiskWidth * diskSize / totalDiskCount, DiskHeight);
  QPalette pal = palette();
  const int colorValue =
      255 * (totalDiskCount - diskSize) / (totalDiskCount - 1);
  pal.setColor(QPalette::Background, QColor(colorValue, 0, 0));
  setAutoFillBackground(true);
  setPalette(pal);
  show();
}

void DiskWidget::mousePressEvent(QMouseEvent*) {
  QDrag* drag = new QDrag(parentWidget());
  QMimeData* mimeData = new QMimeData();

  mimeData->setParent(parentWidget());
  drag->setMimeData(mimeData);

  drag->exec();
}
