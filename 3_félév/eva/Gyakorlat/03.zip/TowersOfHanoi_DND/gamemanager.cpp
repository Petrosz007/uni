#include "gamemanager.h"

GameManager::GameManager() : QObject(nullptr) {}

void GameManager::StartGame(int diskCount) {
  this->diskCount = diskCount;
  for (Disks& tower : towers) {
    tower.clear();
  }

  for (int diskSize = diskCount; diskSize > 0; --diskSize) {
    towers[0].push_back(diskSize);
  }

  Update();
}

const Disks& GameManager::GetDisksOnTower(int towerIndex) {
  return towers[towerIndex];
}

bool GameManager::CanMoveDisk(int sourceIndex, int targetIndex) const {
  const Disks& source = towers[sourceIndex];
  const Disks& target = towers[targetIndex];

  return !source.empty() && (target.empty() || source.back() < target.back());
}

bool GameManager::MoveDisk(int sourceIndex, int targetIndex) {
  if (!CanMoveDisk(sourceIndex, targetIndex)) {
    return false;
  }

  Disks& source = towers[sourceIndex];
  Disks& target = towers[targetIndex];

  const int diskToMove = source.back();

  target.push_back(diskToMove);
  source.pop_back();

  Update();

  if (towers[TowerCount - 1].size() == diskCount) {
    GameOver();
  }

  return true;
}

int GameManager::GetDiskCount() const {
  return diskCount;
}
