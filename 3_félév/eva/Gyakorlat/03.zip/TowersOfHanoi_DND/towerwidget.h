#ifndef TOWERWIDGET_H
#define TOWERWIDGET_H

#include <QWidget>
#include "diskwidget.h"

class GameManager;
class QBoxLayout;

class TowerWidget : public QWidget {
  Q_OBJECT

 private:
  GameManager* gameManager;
  const int id;

  QBoxLayout* layout;

 public:
  explicit TowerWidget(GameManager* gm, int id, QWidget* parent);

  int GetId() const;

  virtual void dragEnterEvent(QDragEnterEvent* event) override;
  virtual void dropEvent(QDropEvent* event) override;

 public slots:
  void UpdateDisks();
};

#endif  // TOWERWIDGET_H
