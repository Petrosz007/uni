#include "towerwidget.h"

#include "diskwidget.h"
#include "gamemanager.h"

#include <QBoxLayout>
#include <QDropEvent>
#include <QMimeData>

static int GetSourceTowerFromEvent(QDropEvent* event) {
  const TowerWidget* sourceTower =
      qobject_cast<TowerWidget*>(event->mimeData()->parent());
  return sourceTower->GetId();
}

TowerWidget::TowerWidget(GameManager* gm, int id, QWidget* parent)
    : QWidget(parent), gameManager(gm), id(id) {
  layout = new QBoxLayout(QBoxLayout::BottomToTop, this);
  layout->setSpacing(0);
  setAcceptDrops(true);
}

int TowerWidget::GetId() const {
  return id;
}

void TowerWidget::dragEnterEvent(QDragEnterEvent* event) {
  const TowerWidget* parentTower =
      qobject_cast<TowerWidget*>(event->mimeData()->parent());
  if (parentTower != nullptr) {
    event->acceptProposedAction();
  }
}

void TowerWidget::dropEvent(QDropEvent* event) {
  const int sourceTowerIndex = GetSourceTowerFromEvent(event);

  if (gameManager->MoveDisk(sourceTowerIndex, GetId())) {
    event->accept();
  } else {
    event->ignore();
  }
}

void TowerWidget::UpdateDisks() {
  while (layout->count() != 0) {
    QLayoutItem* disk = layout->takeAt(0);
    if (disk->widget() != nullptr) {
      disk->widget()->deleteLater();
    }
    delete disk;
  }

  const Disks& disks = gameManager->GetDisksOnTower(GetId());

  for (unsigned int i = 0; i < disks.size(); ++i) {
    DiskWidget* disk =
        new DiskWidget(disks[i], gameManager->GetDiskCount(), this);
    layout->addWidget(disk, 1, Qt::AlignHCenter | Qt::AlignBottom);
    disk->setEnabled(i == disks.size() - 1);
  }
  layout->addStretch(gameManager->GetDiskCount() - disks.size());
}
