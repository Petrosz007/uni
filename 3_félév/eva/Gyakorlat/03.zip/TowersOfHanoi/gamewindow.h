#ifndef GAMEWINDOW_H
#define GAMEWINDOW_H

#include <QWidget>
#include "gamemanager.h"

class QBoxLayout;
class QButtonGroup;
class QPushButton;
class QSpinBox;

class GameWindow : public QWidget {
  Q_OBJECT

 public:
  GameWindow(QWidget* parent = nullptr);
  ~GameWindow();

 private:
  GameManager gameManager;
  QVector<QBoxLayout*> towers;

  QButtonGroup* sourceGroup;
  QButtonGroup* targetGroup;

  QPushButton* moveButton;
  QSpinBox* diskCountSpinBox;

 public slots:
  void UpdateTowers();
  void UpdateMoveButton();
  void MoveDisk();
  void NewGame();
  void GameOver();
};

#endif  // GAMEWINDOW_H
