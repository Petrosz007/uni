#include "diskwidget.h"

DiskWidget::DiskWidget(int diskSize, int totalDiskCount) : QWidget(nullptr) {
  this->setFixedSize(MaxDiskWidth * diskSize / totalDiskCount, DiskHeight);

  QPalette pal = this->palette();
  const int colorValue =
      255 * (totalDiskCount - diskSize) / (totalDiskCount - 1);
  pal.setColor(QPalette::Background, QColor(colorValue, 0, 0));
  this->setAutoFillBackground(true);
  this->setPalette(pal);
  this->show();
}
