#include "gamemanager.h"

GameManager::GameManager(QObject* parent) : QObject(parent) {}

void GameManager::StartGame(int diskCount) {
  this->diskCount = diskCount;
  for (Tower& tower : towers) {
    tower.clear();
  }

  for (int diskSize = diskCount; diskSize > 0; --diskSize) {
    towers[0].push_back(diskSize);
  }

  Update();
}

const Tower& GameManager::GetDisksOnTower(int towerIndex) {
  return towers[towerIndex];
}

bool GameManager::CanMoveDisk(int sourceIndex, int targetIndex) const {
  const Tower& source = towers[sourceIndex];
  const Tower& target = towers[targetIndex];

  return !source.empty() && (target.empty() || source.back() < target.back());
}

bool GameManager::MoveDisk(int sourceIndex, int targetIndex) {
  if (!CanMoveDisk(sourceIndex, targetIndex)) {
    return false;
  }

  Tower& source = towers[sourceIndex];
  Tower& target = towers[targetIndex];

  const int diskToMove = source.back();

  target.push_back(diskToMove);
  source.pop_back();

  Update();

  if (towers[TowerCount - 1].size() == diskCount) {
    GameOver();
  }

  return true;
}

int GameManager::GetDiskCount() const {
  return diskCount;
}
