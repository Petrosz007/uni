#include "gamewindow.h"

#include "diskwidget.h"

#include <QBoxLayout>
#include <QButtonGroup>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QRadioButton>
#include <QSpinBox>

static void CreateTowerSelectionRadioBtn(QButtonGroup* btnGroup,
                                         QGridLayout* layout,
                                         GameWindow* gameWindow,
                                         const int row,
                                         const int col) {
  QRadioButton* btn = new QRadioButton();
  layout->addWidget(btn, row, col, Qt::AlignCenter);
  btnGroup->addButton(btn, col);
  gameWindow->connect(btn, SIGNAL(clicked()), gameWindow,
                      SLOT(UpdateMoveButton()));
  btn->setChecked(col == 0);
}

GameWindow::GameWindow(QWidget* parent) : QWidget(parent) {
  setWindowTitle("Towers of Hanoi");
  setMinimumWidth((DiskWidget::MaxDiskWidth + 10) * GameManager::TowerCount);

  QGridLayout* layout = new QGridLayout(this);

  sourceGroup = new QButtonGroup(this);
  targetGroup = new QButtonGroup(this);

  moveButton = new QPushButton("Move");

  layout->addWidget(moveButton, 3, 0, 1, 3);

  for (int i = 0; i < GameManager::TowerCount; ++i) {
    layout->setColumnStretch(i, 1);

    QBoxLayout* tower = new QBoxLayout(QBoxLayout::BottomToTop);
    layout->addLayout(tower, 0, i, Qt::AlignBottom | Qt::AlignHCenter);
    tower->setSpacing(0);
    towers.push_back(tower);

    CreateTowerSelectionRadioBtn(sourceGroup, layout, this, 1, i);
    CreateTowerSelectionRadioBtn(targetGroup, layout, this, 2, i);
  }

  connect(&gameManager, SIGNAL(Update()), this, SLOT(UpdateTowers()));
  connect(&gameManager, SIGNAL(Update()), this, SLOT(UpdateMoveButton()));
  connect(moveButton, SIGNAL(clicked()), this, SLOT(MoveDisk()));
  connect(&gameManager, SIGNAL(GameOver()), this, SLOT(GameOver()));

  QLabel* diskCountLabel = new QLabel("Number of disks: ");
  layout->addWidget(diskCountLabel, 4, 0);

  diskCountSpinBox = new QSpinBox();
  diskCountSpinBox->setMinimum(3);
  diskCountSpinBox->setMaximum(10);
  layout->addWidget(diskCountSpinBox, 4, 1);

  QPushButton* newGameButton = new QPushButton("New Game");
  connect(newGameButton, SIGNAL(clicked()), this, SLOT(NewGame()));
  layout->addWidget(newGameButton, 4, 2);

  gameManager.StartGame(3);
}

GameWindow::~GameWindow() {}

static void UpdateTower(QBoxLayout* tower,
                        const Tower& disks,
                        int totalDiskCount) {
  while (tower->count() != 0) {
    QLayoutItem* disk = tower->takeAt(0);
    delete disk->widget();
    delete disk;
  }
  for (auto diskSize : disks) {
    DiskWidget* disk = new DiskWidget(diskSize, totalDiskCount);
    tower->addWidget(disk, 1, Qt::AlignHCenter);
  }
}

void GameWindow::UpdateTowers() {
  for (int i = 0; i < GameManager::TowerCount; ++i) {
    UpdateTower(towers[i], gameManager.GetDisksOnTower(i),
                gameManager.GetDiskCount());
  }
}

void GameWindow::UpdateMoveButton() {
  moveButton->setEnabled(gameManager.CanMoveDisk(sourceGroup->checkedId(),
                                                 targetGroup->checkedId()));
}

void GameWindow::MoveDisk() {
  gameManager.MoveDisk(sourceGroup->checkedId(), targetGroup->checkedId());
}

void GameWindow::NewGame() {
  gameManager.StartGame(diskCountSpinBox->value());
}

void GameWindow::GameOver() {
  QMessageBox::information(this, "Game over!",
                           QString("Congratulations! You won!"));
}
