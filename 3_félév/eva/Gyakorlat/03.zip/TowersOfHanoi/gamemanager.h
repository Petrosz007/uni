#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H

#include <QObject>
#include <array>
#include <vector>

using Tower = std::vector<int>;

class GameManager : public QObject {
  Q_OBJECT
 public:
  static constexpr int TowerCount = 3;

  explicit GameManager(QObject* parent = nullptr);

  void StartGame(int diskCount);
  const Tower& GetDisksOnTower(int towerIndex);

  bool CanMoveDisk(int sourceIndex, int targetIndex) const;
  bool MoveDisk(int sourceIndex, int targetIndex);
  int GetDiskCount() const;

 private:
  std::array<Tower, TowerCount> towers;
  int diskCount;

 signals:
  void GameOver();
  void Update();
};

#endif  // GAMEMANAGER_H
