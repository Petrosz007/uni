#ifndef GAMEWINDOWDND_H
#define GAMEWINDOWDND_H

#include <QWidget>
#include "gamemanager.h"

class QBoxLayout;
class QSpinBox;

class GameWindowDnD : public QWidget
{
    Q_OBJECT

public:
    GameWindowDnD(QWidget *parent = nullptr);
    ~GameWindowDnD();

private:
    GameManager gameManager;
    QVector<QBoxLayout *> towers;

    QSpinBox *diskCountSpinBox;

public slots:
    void UpdateTowers();
    void UpdateMoveButton();
    void MoveDisk();
    void NewGame();
};
#endif // GAMEWINDOWDND_H
