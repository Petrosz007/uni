#include "gamewindowdnd.h"

#include "diskwidget.h"

#include <QBoxLayout>
#include <QButtonGroup>
#include <QPushButton>
#include <QRadioButton>
#include <QSpinBox>
#include <QMessageBox>
#include <QLabel>

GameWindowDnD::GameWindowDnD(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle("Towers of Hanoi");
    setMinimumWidth((DiskWidget::MaxDiskWidth + 10) * GameManager::TowerCount);

    QGridLayout *layout = new QGridLayout(this);

    for (int i = 0; i < GameManager::TowerCount; ++i)
    {
        layout->setColumnStretch(i, 1);

        QBoxLayout *tower = new QBoxLayout(QBoxLayout::BottomToTop);
        layout->addLayout(tower, 0, i, Qt::AlignBottom | Qt::AlignHCenter);
        towers.push_back(tower);
    }

    connect(&gameManager, &GameManager::Update, this, &GameWindowDnD::UpdateTowers);
    connect(&gameManager, &GameManager::GameOver, this, [this] { QMessageBox::information(this, "Game over!", QString("Congratulations! You won!")); });

    QLabel *diskCountLabel = new QLabel("Number of disks: ");
    layout->addWidget(diskCountLabel, 4, 0);

    diskCountSpinBox = new QSpinBox();
    diskCountSpinBox->setMinimum(3);
    diskCountSpinBox->setMaximum(10);
    layout->addWidget(diskCountSpinBox, 4, 1);

    QPushButton *newGameButton = new QPushButton("New Game");
    connect(newGameButton, &QAbstractButton::clicked, this, &GameWindowDnD::NewGame);
    layout->addWidget(newGameButton, 4, 2);

    gameManager.StartGame(3);
}

GameWindowDnD::~GameWindowDnD()
{

}

static void UpdateTower(QBoxLayout *tower, const Tower &disks, int totalDiskCount)
{
    while (tower->count() != 0)
    {
        QLayoutItem *disk = tower->takeAt(0);
        delete disk->widget();
        delete disk;
    }
    for (auto diskSize : disks)
    {
        DiskWidget *disk = new DiskWidget(diskSize, totalDiskCount);
        tower->addWidget(disk, 1, Qt::AlignHCenter);
    }
}

void GameWindowDnD::UpdateTowers()
{
    for (int i = 0; i < GameManager::TowerCount; ++i)
    {
        UpdateTower(towers[i], gameManager.GetDisksOnTower(i), gameManager.GetDiskCount());
    }
}

void GameWindowDnD::MoveDisk()
{
    gameManager.MoveDisk(0, 1);
}

void GameWindowDnD::NewGame()
{
    gameManager.StartGame(diskCountSpinBox->value());
}
