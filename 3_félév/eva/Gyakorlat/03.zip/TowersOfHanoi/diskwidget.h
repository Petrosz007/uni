#ifndef DISKWIDGET_H
#define DISKWIDGET_H

#include <QWidget>

class DiskWidget : public QWidget {
  Q_OBJECT
 public:
  DiskWidget(int diskSize, int totalDiskCount);

  static const int MaxDiskWidth = 300;
  static const int DiskHeight = 50;
};

#endif  // DISKWIDGET_H
