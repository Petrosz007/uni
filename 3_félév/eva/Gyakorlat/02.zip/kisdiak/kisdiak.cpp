#include "kisdiak.h"
#include "ui_kisdiak.h"

kisdiak::kisdiak(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::kisdiak)
{
    ui->setupUi(this);
    srand(time(NULL));
    connect(ui->lineEditRes,SIGNAL(returnPressed()),this,SLOT(on_pushButton_clicked()));
}

kisdiak::~kisdiak()
{
    delete ui;
}

void kisdiak::on_pushButton_clicked()
{
    if(ui->pushButton->text()=="Generál")
    {
        ui->lineEditNum1->setText(QString::number(rand()%101));
        ui->lineEditNum2->setText(QString::number(rand()%101));
        ui->rdbOsszeadas->setEnabled(false);
        ui->rdbKivonas->setEnabled(false);
        ui->rdbSzorzas->setEnabled(false);
        ui->rdbOsztas->setEnabled(false);
        ui->pushButton->setText("Értékel");
        ui->lineEditRes->clear();
        ui->lineEditRes->setReadOnly(false);
    }
    else
    {
        bool ok;
        int c = ui->lineEditRes->text().toInt(&ok);
        if (ok)
        {
            int a = ui->lineEditNum1->text().toInt();
            int b = ui->lineEditNum2->text().toInt();
            QString line="";
            if (ui->labelMuvelet->text()=="+")
            {
                if (ok && a+b==c) line="JÓ: ";
                else line="ROSSZ: ";
            }
            else if (ui->labelMuvelet->text()=="-")
            {
                if (ok && a-b==c) line="JÓ: ";
                else line="ROSSZ: ";
            }
            else if (ui->labelMuvelet->text()=="*")
            {
                if (ok && a*b==c) line="JÓ: ";
                else line="ROSSZ: ";
            }
            else
            {
                if (ok && a/b==c) line="JÓ: ";
                else line="ROSSZ: ";
            }
            line +=ui->lineEditNum1->text()+ui->labelMuvelet->text()+ui->lineEditNum2->text()+"="+ui->lineEditRes->text();
            ui->listWidget->addItem(line);
            ui->rdbOsszeadas->setEnabled(true);
            ui->rdbKivonas->setEnabled(true);
            ui->rdbSzorzas->setEnabled(true);
            ui->rdbOsztas->setEnabled(true);
            ui->pushButton->setText("Generál");
            ui->lineEditRes->setReadOnly(true);
        }
        else
        {
            QMessageBox error;
            error.setText("Hibás formátumú bemenet!");
            error.exec();
        }
    }
}

void kisdiak::on_rdbOsszeadas_clicked()
{
    ui->labelMuvelet->setText("+");
}

void kisdiak::on_rdbKivonas_clicked()
{
    ui->labelMuvelet->setText("-");
}


void kisdiak::on_rdbSzorzas_clicked()
{
    ui->labelMuvelet->setText("*");
}

void kisdiak::on_rdbOsztas_clicked()
{
    ui->labelMuvelet->setText("/");
}
