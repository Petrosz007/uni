#ifndef KISDIAK_H
#define KISDIAK_H

#include <QMainWindow>
#include <stdlib.h>
#include <QMessageBox>

namespace Ui {
class kisdiak;
}

class kisdiak : public QMainWindow
{
    Q_OBJECT

public:
    explicit kisdiak(QWidget *parent = nullptr);
    ~kisdiak();

private slots:
    void on_pushButton_clicked();

    void on_rdbOsszeadas_clicked();

    void on_rdbKivonas_clicked();

    void on_rdbSzorzas_clicked();

    void on_rdbOsztas_clicked();

private:
    Ui::kisdiak *ui;
};

#endif // KISDIAK_H
