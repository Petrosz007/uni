#include "kisdiak.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    kisdiak w;
    w.show();

    return a.exec();
}
