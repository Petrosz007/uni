#ifndef SORSOLAS_H
#define SORSOLAS_H

#include <QMainWindow>
#include <QTimer>
#include <stdlib.h>
#include <QMessageBox>
#include <vector>

namespace Ui {
class Sorsolas;
}

class Sorsolas : public QMainWindow
{
    Q_OBJECT

public:
    explicit Sorsolas(QWidget *parent = nullptr);
    ~Sorsolas();

private:
    Ui::Sorsolas *ui;
    QTimer *timer;
    int _max;
    int _gap;
    std::vector<int> _gaps;
    std::vector<int> _nums;

    void reduce();
    int search(int n);

private slots:
    void changeNumber();
    void on_pushButton_START_clicked();
    void on_pushButton_set_clicked();
};

#endif // SORSOLAS_H
