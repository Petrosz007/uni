#include "sorsolas.h"
#include "ui_sorsolas.h"

Sorsolas::Sorsolas(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Sorsolas)
{
    ui->setupUi(this);
    srand(time(nullptr));
    _max=ui->lineEdit_max->text().toInt();
    _gap=ui->lineEdit_gap->text().toInt();;
    _gaps.resize(_max,0);
    _nums.resize(_max);
    for (int i=0;i<_max;i++)
        _nums[i]=i+1;

    timer=new QTimer(this);
    timer->setInterval(50);
    connect(timer,SIGNAL(timeout()),this,SLOT(changeNumber()));

    ui->label->hide();
    ui->label_2->hide();
    ui->lineEdit_max->hide();
    ui->lineEdit_gap->hide();
}

void Sorsolas::changeNumber()
{
    ui->lineEdit_no->setText(QString::number(_nums[rand()%_nums.size()]));
}

Sorsolas::~Sorsolas()
{
    delete ui;
}

void Sorsolas::on_pushButton_START_clicked()
{
    if (ui->pushButton_START->text()=="START")
    {
        ui->pushButton_START->setText("STOP");
        ui->pushButton_set->setEnabled(false);
        timer->start();
    }
    else
    {
        timer->stop();
        if (_gap > 0)
        {
            int n = ui->lineEdit_no->text().toInt();
            reduce();
            _gaps[n-1] = _gap;
            int i = search(n);
            _nums.erase(_nums.begin()+i);
        }
        ui->pushButton_START->setText("START");
        ui->pushButton_set->setEnabled(true);
    }
}

int Sorsolas::search(int n)
{
    for (int i=0;i<_nums.size();i++)
        if (_nums[i]==n) return i;
}

void Sorsolas::reduce()
{
    for (unsigned int i=0;i<_gaps.size();i++)
    {
        if (_gaps[i]>1) _gaps[i]--;
        else if (_gaps[i]>0)
        {
            _gaps[i]=0;
            _nums.push_back(i+1);
        }
    }
}

void Sorsolas::on_pushButton_set_clicked()
{
    if (ui->pushButton_set->text()=="beállít")
    {
        ui->label->show();
        ui->label_2->show();
        ui->lineEdit_gap->show();
        ui->lineEdit_max->show();
        ui->pushButton_set->setText("Mehet");
        ui->pushButton_START->setEnabled(false);
    }
    else
    {
        bool ok,ok2;
        int m = ui->lineEdit_max->text().toInt(&ok);
        int m2 = ui->lineEdit_gap->text().toInt(&ok2);
        if (ok && m > 1 && ok2 && m2 >=0 && m2 < m)
        {
            _max = m;
            _gaps.clear();
            _gaps.resize(_max,0);
            _nums.resize(_max);
            for (int i=0;i<_max;i++)
                _nums[i]=i+1;
            _gap = m2;

            ui->pushButton_START->setEnabled(true);
            ui->label->hide();
            ui->label_2->hide();
            ui->lineEdit_gap->hide();
            ui->lineEdit_max->hide();
            ui->pushButton_set->setText("beállít");
        }
        else
        {
            QString text;
            if (!ok) text = "Hiba: A tételek száma nem numerikus!";
            else if (!ok2) text = "Hiba: A kihagyás mértéke nem numerikus!";
            else if (m < 2) text = "Hiba: Legalább két tétel legyen!";
            else if (m2 < 0) text = "Hiba: A kihagyás mértéke nem lehet negatív!";
            else text = "Hiba: A kihagyás mértéke kisebb kell legyen, mint a tételek száma!";
            QMessageBox mb(this);
            mb.setText(text);
            mb.exec();
        }
    }

}

