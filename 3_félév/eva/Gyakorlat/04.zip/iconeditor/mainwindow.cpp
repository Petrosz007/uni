#include "mainwindow.h"

#include <QFileDialog>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle("Icon editor");

    changeColor = new SelectColorButton(&iconEditor, this);
    changeColor->setText("Change color");

    scrollArea = new QScrollArea(this);
    scrollArea->setWidget(&iconEditor);
    scrollArea->viewport()->setBackgroundRole(QPalette::Dark);
    scrollArea->viewport()->setAutoFillBackground(true);
    scrollArea->setWidgetResizable(true);

    layout = new QVBoxLayout(this);
    layout->addWidget(changeColor, 1, Qt::AlignRight);
    layout->addWidget(scrollArea);

    menubar = new QMenuBar(this);

    file = new QMenu(tr("File"), menubar);
    menubar->addMenu(file);

    load = new QAction(tr("Load image"), menubar);
    connect(load, SIGNAL(triggered()), this, SLOT(loadImage()));
    file->addAction(load);

    save = new QAction(tr("Save image"), menubar);
    connect(save, SIGNAL(triggered()), this, SLOT(saveImage()));
    file->addAction(save);
    save->setEnabled(false);
}

void MainWindow::saveImage()
{
    if (!iconEditor.getFileName().isEmpty())
    {
        iconEditor.saveImage();
    }
    else
    {
        QMessageBox::information(this, "No image",
                                 "No image is loaded!");
    }
}

void MainWindow::loadImage()
{
    QString filePath = QFileDialog::getOpenFileName(this,
                                                    tr("Open image"),
                                                    "",
                                                    tr("PNG (*.png)"));

    if (!filePath.isNull()
            && iconEditor.loadImage(filePath))
    {
        save->setEnabled(true);
    }
}
