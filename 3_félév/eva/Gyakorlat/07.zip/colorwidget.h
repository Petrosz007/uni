#ifndef COLORWIDGET_H
#define COLORWIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QString>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QVector>
#include <QMessageBox>
#include <QInputDialog>
#include <QLabel>

#include "colormodel.h"


class ColorWidget : public QWidget
{
    Q_OBJECT

public:
    ColorWidget(QWidget *parent = 0);
    ~ColorWidget();

private slots:
    void smallButtonClicked() { newGame(4); }
    void mediumButtonClicked() { newGame(8); }
    void bigButtonClicked() { newGame(12); }

    void buttonClicked();
    void refreshTime(int time);

private:
    ColorModel* cm;

    int size;

    QGridLayout* grid;
    QHBoxLayout* hor;
    QVBoxLayout* vert;

    QPushButton* smallTableButton;
    QPushButton* mediumTableButton;
    QPushButton* bigTableButton;

    QLabel* timeLabel;


    QVector<QVector<QPushButton*>> buttonGrid;

    void setupWindow();
    void setupTable();
    void refreshTable();
    void deleteCurrent();
    void newGame(int n);
};

#endif // COLORWIDGET_H
