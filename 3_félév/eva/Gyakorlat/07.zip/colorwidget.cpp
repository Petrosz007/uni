#include "colorwidget.h"

ColorWidget::ColorWidget(QWidget *parent)
    : QWidget(parent)
{
    this->setWindowTitle("Color");
    size = 0;
    cm = new ColorModel();
    setupWindow();
    connect(cm, SIGNAL(timerRefresh(int)), this, SLOT(refreshTime(int)));
}

ColorWidget::~ColorWidget(){}

void ColorWidget::newGame(int n)
{
    QString textOfInputDialog = "Add meg a nehézséget! (1-könnyű, 2-közepes, 3-nehéz)";

    bool ok;
    int diff = QInputDialog::getInt(this, "Nehézség beállítása", textOfInputDialog,
                                   0, 1, 3, 1, &ok); //egy lehetséges módja az adatbekérésnek

    if (ok)
    {
        deleteCurrent();
        cm->newGame(n, diff);
        setupTable();
    }
}

void ColorWidget::refreshTable()
{
    for (int i = 0; i < size; ++i)
    {
        for (int j = 0; j < size; ++j)
        {
            QPalette pal = buttonGrid[i][j]->palette();
            switch (cm->getTable()[i][j])
            {
                case 1:
                    pal.setColor(QPalette::Button, QColor(Qt::red));
                    break;
                case 2:
                    pal.setColor(QPalette::Button, QColor(Qt::yellow));
                    break;
                case 3:
                    pal.setColor(QPalette::Button, QColor(Qt::green));
                    break;
                case 4:
                    pal.setColor(QPalette::Button, QColor(Qt::blue));
            }
            buttonGrid[i][j]->setAutoFillBackground(true);
            buttonGrid[i][j]->setPalette(pal);
            buttonGrid[i][j]->update();
        }
    }
}

void ColorWidget::buttonClicked()
{
    QPushButton* senderButton = dynamic_cast <QPushButton*> (QObject::sender());
    int location = grid->indexOf(senderButton);
    int x = location / size;
    int y = location % size;

    cm->oneStep(x,y);
    refreshTable();

    if (cm->isGameOver())
    {
        QMessageBox::about(this,"Vége a játéknak!","A játékot megnyerted! Játékidőd: "
                           + QString::number(cm->getTimeGone()));
        newGame(cm->getTableSize());
    }
}

void ColorWidget::setupTable()
{
    size = cm->getTableSize();
    int buttonSize = 50;
    setFixedSize(qRound(buttonSize * 1.2) * size, (qRound(buttonSize * 1.2)) * size + 55);
    buttonGrid.resize(size);

    for (int i = 0; i < size; ++i)
    {
        buttonGrid[i].resize(size);
        for (int j = 0; j < size; ++j)
        {
            QPushButton* button = new QPushButton("",this);
            buttonGrid[i][j] = button;
            button->setFixedSize(buttonSize,buttonSize);
            grid->addWidget(buttonGrid[i][j], i, j);
            connect(buttonGrid[i][j], SIGNAL(clicked()), this, SLOT(buttonClicked()));
        }
    }
    refreshTable();
}

void ColorWidget::refreshTime(int time){

    timeLabel->setText(QString::number(time) + "s");
}

void ColorWidget::setupWindow()
{
    hor = new QHBoxLayout();

    smallTableButton = new QPushButton("4x4", this);
    mediumTableButton = new QPushButton("8x8", this);
    bigTableButton = new QPushButton("12x12", this);

    connect(smallTableButton,SIGNAL(clicked()),this,SLOT(smallButtonClicked()));
    connect(mediumTableButton,SIGNAL(clicked()),this,SLOT(mediumButtonClicked()));
    connect(bigTableButton,SIGNAL(clicked()),this,SLOT(bigButtonClicked()));

    hor->addWidget(smallTableButton);
    hor->addWidget(mediumTableButton);
    hor->addWidget(bigTableButton);

    grid = new QGridLayout();

    timeLabel = new QLabel("0s");
    QFont timeLabelFont = QFont("timeLabel", 14);
    timeLabel->setFont(timeLabelFont);

    vert = new QVBoxLayout();
    vert->addLayout(hor);
    vert->addLayout(grid);
    vert->addWidget(timeLabel);
    setLayout(vert);
}

void ColorWidget::deleteCurrent()
{
    for (int i = 0; i < size; ++i)
    {
        for (int j = 0; j < size; ++j)
        {
            grid->removeWidget(buttonGrid[i][j]);
            delete buttonGrid[i][j];
        }
    }
}




































