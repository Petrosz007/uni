#include "colormodel.h"
#include <QDebug>

ColorModel::ColorModel()
{
    qsrand(QTime::currentTime().msec());
    timer = new QTimer();
    timer->setInterval(1000);
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(tick()));
}

void ColorModel::tick()
{
    ++timeGone;
    timerRefresh(timeGone);
}

bool ColorModel::isGameOver()
{
    bool isOver = true;
    int color = table[0][0];
    int i = 0;
    while (i < tableSize && isOver)
    {
        int j = 0;
        while (j < tableSize && isOver)
        {
            if (table[i][j] != color)
            {
                isOver = false;
            }
            ++j;
        }
        ++i;
    }

    if (isOver)
    {
        timer->stop();
    }
    return isOver;
}

void ColorModel::randomStep()
{
    int x = qrand() % tableSize;
    int y = qrand() % tableSize;
    oneStep(x,y,true);
}

void ColorModel::oneStep(int x, int y, bool isRandom)
{
    for (int i = std::max(0, x - 1); i < std::min(tableSize, x + 2); ++i)
    {
        for (int j = std::max(0, y - 1); j < std::min(tableSize, y + 2); ++j)
        {
            table[i][j] = nextColor(table[i][j]);
        }
    }

    if (!isRandom)
    {
        ++clicks;
        timeGone += 10;
        timerRefresh(timeGone);
    }

    if (!isRandom &&
        ((difficulty == 2 && clicks % 10 == 0) ||
         (difficulty == 3 && clicks % 4 == 0)))
    {
        randomStep();
    }
}

void ColorModel::newGame(int n, int d)
{
    tableSize = n;
    difficulty = d;
    clicks = 0;
    table.resize(tableSize);

    for (int i = 0; i < tableSize; ++i)
    {
        table[i].resize(tableSize);
        for (int j = 0; j < tableSize; ++j)
        {
            table[i][j] = 1;
        }
    }

    for (int i = 0; i < tableSize; ++i)
    {
        randomStep();
    }

    timeGone = 0;
    emit timerRefresh(timeGone);
    timer->start();
}

int ColorModel::nextColor(int n) //1,2,3,4,1,2,...
{
    return n % 4 + 1;
}
