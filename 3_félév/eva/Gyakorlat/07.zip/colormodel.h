#ifndef COLORMODEL_H
#define COLORMODEL_H

#include <QWidget>
#include <QVector>
#include <QString>
#include <QTime>
#include <QTimer>
#include <QObject>

class ColorModel : public QObject
{
    Q_OBJECT
public:
    ColorModel();
    int getTableSize() { return tableSize; }
    QVector<QVector<int>> getTable() { return table; }
    int getTimeGone() { return timeGone; }

    void newGame(int n, int d);
    void oneStep(int x, int y, bool isRandom = false);

    bool isGameOver();

signals:
    void timerRefresh(int);

private slots:
    void tick();

private:
    QTimer* timer;

    int tableSize;
    QVector<QVector<int>> table; //1-piros, 2-sárga, 3-zöld, 4-kék
    int timeGone;
    int difficulty;
    int clicks;

    int nextColor(int n);
    void randomStep();
};

#endif // COLORMODEL_H
