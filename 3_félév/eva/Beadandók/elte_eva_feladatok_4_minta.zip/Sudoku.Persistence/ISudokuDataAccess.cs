﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ELTE.Windows.Sudoku.Persistence
{
    /// <summary>
    /// Sudoku perzisztencia kezelő felülete.
    /// </summary>
    public interface ISudokuDataAccess
    {
        /// <summary>
        /// Játékállapot betöltése.
        /// </summary>
        /// <param name="name">Név vagy elérési útvonal.</param>
        /// <returns>A beolvasott játéktábla.</returns>
        Task<SudokuTable> LoadAsync(String name);

        /// <summary>
        /// Játékállapot mentése.
        /// </summary>
        /// <param name="name">Név vagy elérési útvonal.</param>
        /// <param name="table">A kiírandó játéktábla.</param>
        Task SaveAsync(String name, SudokuTable table);

        /// <summary>
        /// Játékállapot mentések lekérdezése.
        /// </summary>
	    Task<ICollection<SaveEntry>> ListAsync();
    }
}