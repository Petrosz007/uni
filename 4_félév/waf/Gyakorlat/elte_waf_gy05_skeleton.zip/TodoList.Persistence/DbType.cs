using System;

namespace TodoList.Persistence
{
	public enum DbType
	{
		SqlServer,
		Sqlite
	}
}
