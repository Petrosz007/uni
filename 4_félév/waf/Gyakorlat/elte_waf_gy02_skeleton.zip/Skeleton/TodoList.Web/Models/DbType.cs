using System;

namespace TodoList.Web.Models
{
	public enum DbType
	{
		SqlServer,
		Sqlite
	}
}
