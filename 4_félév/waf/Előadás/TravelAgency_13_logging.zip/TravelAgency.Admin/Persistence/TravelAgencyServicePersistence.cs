﻿using ELTE.TravelAgency.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NLog;

namespace ELTE.TravelAgency.Admin.Persistence
{
    /// <summary>
    /// Szolgáltatás alapú perzisztencia.
    /// </summary>
    public class TravelAgencyServicePersistence : ITravelAgencyPersistence
    {
        private HttpClient _client;
        private ILogger _log;

        /// <summary>
        /// Szolgáltatás alkapú perszisztencia példányosítása.
        /// </summary>
        /// <param name="baseAddress">A szolgáltatás címe.</param>
        public TravelAgencyServicePersistence(String baseAddress)
        {
            _client = new HttpClient(); // a szolgáltatás kliense
            _client.BaseAddress = new Uri(baseAddress); // megadjuk neki a címet

            _log = LogManager.GetLogger("service"); // lekérjük az eseménynaplót
        }

        /// <summary>
        /// Szolgáltatás alkapú perszisztencia példányosítása.
        /// </summary>
        /// <remarks>Integrációs teszteléshez.</remarks>
        /// <param name="client">A HTTP kliens objektum.</param>
        public TravelAgencyServicePersistence(HttpClient client)
        {
            _client = client;
        }

        /// <summary>
        /// Épületek betöltése.
        /// </summary>
        public async Task<IEnumerable<BuildingDTO>> ReadBuildingsAsync()
        {
            try
            {
                _log.Info("GET query on service " + _client.BaseAddress + ", path: api/buildings/"); // információ kiírása az eseményaplóba

                // a kéréseket a kliensen keresztül végezzük
                HttpResponseMessage response = await _client.GetAsync("api/buildings/");
                if (response.IsSuccessStatusCode) // amennyiben sikeres a művelet
                {
                    IEnumerable<BuildingDTO> buildings = await response.Content.ReadAsAsync<IEnumerable<BuildingDTO>>();
                    // a tartalmat JSON formátumból objektumokká alakítjuk

                    // képek lekérdezése:
                    foreach (BuildingDTO building in buildings)
                    {
                        response = await _client.GetAsync("api/images/" + building.Id);
                        if (response.IsSuccessStatusCode)
                        {
                            building.Images = (await response.Content.ReadAsAsync<IEnumerable<ImageDTO>>()).ToList();
                        }
                    }

                    return buildings;
                }
                else
                {
                    _log.Warn("GET query returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase); // figyelmeztetés kiírása az eseménynaplóba

                    throw new PersistenceUnavailableException("Service returned response: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "GET query aborted with exception."); // hiba kiírása az eseménynaplóba a kivétel tartalmával
                throw new PersistenceUnavailableException(ex);
            }

        }

        /// <summary>
        /// Városok betöltése.
        /// </summary>
        public async Task<IEnumerable<CityDTO>> ReadCitiesAsync()
        {
            try
            {
                _log.Info("GET query on service " + _client.BaseAddress + ", path: api/cities/");

                HttpResponseMessage response = await _client.GetAsync("api/cities/");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsAsync<IEnumerable<CityDTO>>();
                }
                else
                {
                    _log.Warn("GET query returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase);

                    throw new PersistenceUnavailableException("Service returned response: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "GET query aborted with exception.");
                throw new PersistenceUnavailableException(ex);
            }
        }

        /// <summary>
        /// Épület létrehozása.
        /// </summary>
        /// <param name="building">Épület.</param>
        public async Task<Boolean> CreateBuildingAsync(BuildingDTO building)
        {
            try
            {
                _log.Info("POST query on service " + _client.BaseAddress + ", path: api/buildings/");
                _log.Trace("POST query content: " + JsonConvert.SerializeObject(building, Formatting.None)); // nyomkövetéshez szükséges adatok kiírása a naplóba

                HttpResponseMessage response = await _client.PostAsJsonAsync("api/buildings/", building); // az értékeket azonnal JSON formátumra alakítjuk
                building.Id = (await response.Content.ReadAsAsync<BuildingDTO>()).Id; // a válaszüzenetben megkapjuk a végleges azonosítót

                if (!response.IsSuccessStatusCode)
                    _log.Warn("POST query returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase);

                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "POST query aborted with exception.");
                throw new PersistenceUnavailableException(ex);
            }
        }

        /// <summary>
        /// Épület módosítása.
        /// </summary>
        /// <param name="building">Épület.</param>
        public async Task<Boolean> UpdateBuildingAsync(BuildingDTO building)
        {
            try
            {
                _log.Info("PUT query on service " + _client.BaseAddress + ", path: api/buildings/");
                _log.Trace("PUT query content: " + JsonConvert.SerializeObject(building, Formatting.None));

                HttpResponseMessage response = await _client.PutAsJsonAsync("api/buildings/", building);

                if (!response.IsSuccessStatusCode)
                    _log.Warn("PUT query returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase);

                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "PUT query aborted with exception.");
                throw new PersistenceUnavailableException(ex);
            }
        }

        /// <summary>
        /// Épület törlése.
        /// </summary>
        /// <param name="building">Épület.</param>
        public async Task<Boolean> DeleteBuildingAsync(BuildingDTO building)
        {
            try
            {
                _log.Info("DELETE query on service " + _client.BaseAddress + ", path: api/buildings/");
                _log.Trace("DELETE query content: " + JsonConvert.SerializeObject(building, Formatting.None));

                HttpResponseMessage response = await _client.DeleteAsync("api/buildings/" + building.Id);

                if (!response.IsSuccessStatusCode)
                    _log.Warn("DELETE query returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "DELETE query aborted with exception.");

                throw new PersistenceUnavailableException(ex);
            }
        }

        /// <summary>
        /// Épületkép létrehozása.
        /// </summary>
        /// <param name="image">Épületkép.</param>
        public async Task<Boolean> CreateBuildingImageAsync(ImageDTO image)
        {
            try
            {
                _log.Info("POST query on service " + _client.BaseAddress + ", path: api/images/");
                _log.Trace("POST query imageID: " + image.Id + ", buildingID: " + image.BuildingId);

                HttpResponseMessage response = await _client.PostAsJsonAsync("api/images/", image); // elküldjük a képet
                if (response.IsSuccessStatusCode)
                {
                    image.Id = await response.Content.ReadAsAsync<Int32>(); // a válaszüzenetben megkapjuk az azonosítót
                }
                else
                {
                    _log.Warn("POST query returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase);
                }

                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "POST query aborted with exception.");
                throw new PersistenceUnavailableException(ex);
            }
        }

        /// <summary>
        /// Épületkép törlése.
        /// </summary>
        /// <param name="image">Épületkép.</param>
        public async Task<Boolean> DeleteBuildingImageAsync(ImageDTO image)
        {
            try
            {
                _log.Info("DELETE query on service " + _client.BaseAddress + ", path: api/images/");
                _log.Trace("DELETE query imageID: " + image.Id + ", buildingID: " + image.BuildingId);

                HttpResponseMessage response = await _client.DeleteAsync("api/images/" + image.Id);

                if (!response.IsSuccessStatusCode)
                    _log.Warn("DELETE query returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase);

                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "DELETE query aborted with exception.");
                throw new PersistenceUnavailableException(ex);
            }
        }


        /// <summary>
        /// Bejelentkezés.
        /// </summary>
        /// <param name="userName">Felhasználónév.</param>
        /// <param name="userPassword">Jelszó.</param>
        public async Task<Boolean> LoginAsync(String userName, String userPassword)
        {
            try
            {
                _log.Info("LOGIN on service {0}, path: api/account/login/, user name: {1}", _client.BaseAddress, userName);

                HttpResponseMessage response = await _client.GetAsync("api/account/login/" + userName + "/" + userPassword);

                if (!response.IsSuccessStatusCode)
                    _log.Warn("LOGIN returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase);

                return response.IsSuccessStatusCode; // a művelet eredménye megadja a bejelentkezés sikerességét
            }
            catch (Exception ex)
            {
                _log.Error(ex, "LOGIN aborted with exception.");
                throw new PersistenceUnavailableException(ex);
            }
        }

        /// <summary>
        /// Kijelentkezés.
        /// </summary>
        public async Task<Boolean> LogoutAsync()
        {
            try
            {
                _log.Info("LOGOUT on service " + _client.BaseAddress + ", path: api/account/logout/");

                HttpResponseMessage response = await _client.GetAsync("api/account/logout");

                if (!response.IsSuccessStatusCode)
                    _log.Warn("LOGOUT returned response {0} with reason: {1}", response.StatusCode, response.ReasonPhrase);

                return !response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "LOGOUT aborted with exception.");
                throw new PersistenceUnavailableException(ex);
            }
        }
    }
}
