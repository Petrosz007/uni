﻿using ELTE.TravelAgency.Data;
using ELTE.TravelAgency.Model;
using System;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NLog;

namespace ELTE.TravelAgency.Service.Controllers
{
    /// <summary>
    /// Városok lekérdezését biztosító vezérlő.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [ApiConventionType(typeof(DefaultApiConventions))]
    public class CitiesController : ControllerBase
    {
		private readonly TravelAgencyContext _context;

        /// <summary>
        /// Naplózó szolgáltatás.
        /// </summary>
        private readonly Logger _log;

        /// <summary>
        /// Vezérlő példányosítása.
        /// </summary>
        public CitiesController(TravelAgencyContext context)
	    {
		    if (context == null)
			    throw new ArgumentNullException(nameof(context));

		    _context = context;
            _log = LogManager.GetLogger("service");
        }

        /// <summary>
        /// Városok lekérdezése.
        /// </summary>
        [HttpGet]
        public IActionResult GetCities()
        {
            try
            {
                return Ok(_context.Cities.ToList().Select(city => new CityDTO
                {
                    Id = city.Id,
                    Name = city.Name
                }));
            }
            catch (Exception ex)
            {
                _log.Error(ex, "CITY GET query failed from address {0}",
                    HttpContext.Connection.RemoteIpAddress);

                // Internal Server Error
                return StatusCode(StatusCodes.Status500InternalServerError);
			}
        }
    }
}
