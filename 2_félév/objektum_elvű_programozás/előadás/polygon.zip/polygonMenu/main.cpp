//Author:   Gregorics Tibor
//Date:     2017.12.15.
//Title:    Moving polygons and computing their center (menu-driven object-oriented version)

#include "menu.h"

using namespace std;

int main()
{
    Menu a;
    a.run();
    return 0;
}

