//Author:   Gregorics Tibor
//Date:     2017.12.15.
//Title:    Moving polygons and computing their center (obcect-oriented version)

#include <iostream>
#include <fstream>
#include "application.h"

using namespace std;

int main()
{
    Application a;
    a.run();
    return 0;
}
