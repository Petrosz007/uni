#ifndef HEADER_H
#define HEADER_H

void f();
void f();
void f();

#endif

