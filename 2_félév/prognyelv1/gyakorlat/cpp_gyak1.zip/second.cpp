#include <iostream>
#include "header.h"

void f()
{
    std::cout << "f()" << std::endl;
}

