#include <iostream>
#include "header.h"

//
int h = 35;

int main()
{
    f();
    return 0;
}

